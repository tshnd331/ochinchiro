import test from 'node:test';
import assert from 'node:assert/strict';

import { applyAction, createInitialGameState, getCurrentPlayerId } from '../game/stateMachine.mjs';

function fixedRoll(dice) {
  return () => dice;
}

test('state machine: rejects action when not your turn', () => {
  const s = createInitialGameState(['p1', 'p2'], { roundsTotal: 1 });
  const r = applyAction(s, { type: 'ROLL', playerId: 'p2' }, fixedRoll([1, 1, 1]));
  assert.equal(r.ok, false);
  assert.equal(r.error, 'not_your_turn');
});

test('state machine: roll then keep advances turn', () => {
  const s = createInitialGameState(['p1', 'p2'], { roundsTotal: 1, rerollsMax: 0 });

  let r = applyAction(s, { type: 'ROLL', playerId: 'p1' }, fixedRoll([2, 2, 2]));
  assert.equal(r.ok, true);

  r = applyAction(s, { type: 'KEEP', playerId: 'p1' }, fixedRoll([2, 2, 2]));
  assert.equal(r.ok, true);
  assert.equal(getCurrentPlayerId(s), 'p2');
});

test('state machine: reroll decrements rerollsLeft', () => {
  const s = createInitialGameState(['p1'], { roundsTotal: 1, rerollsMax: 1 });

  let r = applyAction(s, { type: 'ROLL', playerId: 'p1' }, fixedRoll([1, 4, 6]));
  assert.equal(r.ok, true);

  r = applyAction(s, { type: 'REROLL', playerId: 'p1' }, fixedRoll([4, 5, 6]));
  assert.equal(r.ok, true);
  assert.equal(s.currentTurn.rerollsLeft, 0);
});

test('state machine: cannot reroll on hifumi (1-2-3)', () => {
  const s = createInitialGameState(['p1'], { roundsTotal: 1, rerollsMax: 1 });

  let r = applyAction(s, { type: 'ROLL', playerId: 'p1' }, fixedRoll([1, 2, 3]));
  assert.equal(r.ok, true);
  assert.equal(s.currentTurn.lastHand.kind, '123');
  assert.equal(s.currentTurn.rerollsLeft, 1);

  r = applyAction(s, { type: 'REROLL', playerId: 'p1' }, fixedRoll([4, 5, 6]));
  assert.equal(r.ok, false);
  assert.equal(r.error, 'hifumi_no_reroll');
  // Should not consume rerolls.
  assert.equal(s.currentTurn.rerollsLeft, 1);
});

test('state machine: last reroll + none does not auto-keep (server may)', () => {
  const s = createInitialGameState(['p1', 'p2'], { roundsTotal: 1, rerollsMax: 1 });

  let r = applyAction(s, { type: 'ROLL', playerId: 'p1' }, fixedRoll([4, 5, 6]));
  assert.equal(r.ok, true);
  assert.equal(getCurrentPlayerId(s), 'p1');

  // last reroll -> rerollsLeft becomes 0, result is 'none' (e.g. 1-4-6)
  r = applyAction(s, { type: 'REROLL', playerId: 'p1' }, fixedRoll([1, 4, 6]));
  assert.equal(r.ok, true);

  // Pure state machine does not auto-keep; turn stays on p1.
  assert.equal(getCurrentPlayerId(s), 'p1');
  assert.equal(s.scores.p1, 0);
});

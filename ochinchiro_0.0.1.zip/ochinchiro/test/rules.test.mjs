import test from 'node:test';
import assert from 'node:assert/strict';

import { evaluateHand } from '../game/rules.mjs';

test('evaluateHand: triple', () => {
  const h = evaluateHand([2, 2, 2]);
  assert.equal(h.kind, 'triple');
  assert.equal(h.score, 110);
});

test('evaluateHand: pinzoro is strongest triple', () => {
  const h = evaluateHand([1, 1, 1]);
  assert.equal(h.kind, 'triple');
  assert.equal(h.label, 'ピンゾロ');
  assert.ok(h.score > evaluateHand([6, 6, 6]).score);
  assert.ok(h.rank > evaluateHand([6, 6, 6]).rank);
});

test('evaluateHand: 4-5-6', () => {
  const h = evaluateHand([6, 4, 5]);
  assert.equal(h.kind, '456');
  assert.equal(h.label, 'シゴロ');
  assert.equal(h.score, 90);
});

test('evaluateHand: 1-2-3', () => {
  const h = evaluateHand([1, 3, 2]);
  assert.equal(h.kind, '123');
  assert.equal(h.label, 'ヒフミ');
  assert.equal(h.score, -100);
});

test('evaluateHand: pair + point', () => {
  const h = evaluateHand([2, 2, 5]);
  assert.equal(h.kind, 'pair');
  assert.equal(h.point, 5);
  assert.equal(h.score, 25);
});

test('evaluateHand: none', () => {
  const h = evaluateHand([1, 4, 6]);
  assert.equal(h.kind, 'none');
  assert.equal(h.score, 0);
});

test('evaluateHand: non-pinzoro triples are equal strength', () => {
  const h2 = evaluateHand([2, 2, 2]);
  const h6 = evaluateHand([6, 6, 6]);
  assert.equal(h2.rank, h6.rank);
  assert.equal(h2.score, h6.score);
});




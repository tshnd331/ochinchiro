import test from 'node:test';
import assert from 'node:assert/strict';

import { EXPECTED_SCORE_FRESH_ROLL, decideBotAction } from '../game/bot/strategies.mjs';
import { evaluateHand } from '../game/rules.mjs';

test('expected score of fresh roll is within a reasonable range', () => {
  assert.ok(EXPECTED_SCORE_FRESH_ROLL > 10);
  assert.ok(EXPECTED_SCORE_FRESH_ROLL < 50);
});

test('easy rerolls on none when possible', () => {
  const hand = evaluateHand([1, 4, 6]);
  assert.equal(decideBotAction({ difficulty: 'easy', hand, rerollsLeft: 1 }), 'reroll');
});

test('normal tends to reroll below expected score', () => {
  const hand = evaluateHand([1, 2, 3]);
  assert.ok(hand.score < EXPECTED_SCORE_FRESH_ROLL);
  assert.equal(decideBotAction({ difficulty: 'normal', hand, rerollsLeft: 1 }), 'keep');
});

test('bots keep on hifumi (no reroll allowed)', () => {
  const hand = evaluateHand([1, 2, 3]);
  assert.equal(decideBotAction({ difficulty: 'easy', hand, rerollsLeft: 1 }), 'keep');
  assert.equal(decideBotAction({ difficulty: 'normal', hand, rerollsLeft: 1 }), 'keep');
  assert.equal(decideBotAction({ difficulty: 'hard', hand, rerollsLeft: 1 }), 'keep');
});

test('hard increases reroll tendency when behind on last round', () => {
  const hand = evaluateHand([3, 3, 1]); // 21
  assert.equal(
    decideBotAction({
      difficulty: 'hard',
      hand,
      rerollsLeft: 1,
      situation: { roundIndex: 4, roundsTotal: 5, myScore: 0, topScore: 60 },
    }),
    'reroll',
  );
});

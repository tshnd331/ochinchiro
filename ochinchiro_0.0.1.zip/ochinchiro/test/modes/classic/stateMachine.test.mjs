import test from 'node:test';
import assert from 'node:assert/strict';

import { applyAction, applyBet, createInitialGameState, getCurrentPlayerId } from '../../../game/stateMachine.mjs';

function fixedRoll(dice) {
  return () => dice;
}

test('state machine: classic mode scores vs dealer (win/loss)', () => {
  const s = createInitialGameState(['p1', 'p2'], { roundsTotal: 1, rerollsMax: 0, ruleMode: 'classic' });

  // Dealer acts last; initial dealer is p1.
  let r = applyAction(s, { type: 'ROLL', playerId: 'p2' }, fixedRoll([1, 1, 1]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p2' }, fixedRoll([1, 1, 1]));
  assert.equal(r.ok, true);
  assert.equal(s.scores.p1, 0);
  assert.equal(s.scores.p2, 0);

  r = applyAction(s, { type: 'ROLL', playerId: 'p1' }, fixedRoll([4, 5, 6]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p1' }, fixedRoll([4, 5, 6]));
  assert.equal(r.ok, true);

  // Dealer (p1) loses to p2: p2 +1, p1 +0
  assert.equal(s.scores.p2, 1);
  assert.equal(s.scores.p1, 0);
});

test('state machine: classic mode dealer gains point on opponent loss', () => {
  const s = createInitialGameState(['p1', 'p2'], { roundsTotal: 1, rerollsMax: 0, ruleMode: 'classic' });

  // Dealer acts last; initial dealer is p1.
  let r = applyAction(s, { type: 'ROLL', playerId: 'p2' }, fixedRoll([1, 2, 3]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p2' }, fixedRoll([1, 2, 3]));
  assert.equal(r.ok, true);

  r = applyAction(s, { type: 'ROLL', playerId: 'p1' }, fixedRoll([4, 5, 6]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p1' }, fixedRoll([4, 5, 6]));
  assert.equal(r.ok, true);

  // Dealer (p1) beats p2: p1 +1, p2 +0
  assert.equal(s.scores.p1, 1);
  assert.equal(s.scores.p2, 0);
});

test('state machine: classic mode rotates dealer each round', () => {
  const s = createInitialGameState(['p1', 'p2'], { roundsTotal: 2, rerollsMax: 0, ruleMode: 'classic' });

  // Round 0 dealer is p1 (acts last)
  assert.equal(s.round.dealerId, 'p1');
  // First turn is challenger p2
  let r = applyAction(s, { type: 'ROLL', playerId: 'p2' }, fixedRoll([1, 2, 3]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p2' }, fixedRoll([1, 2, 3]));
  assert.equal(r.ok, true);

  // Dealer p1 ends the round
  r = applyAction(s, { type: 'ROLL', playerId: 'p1' }, fixedRoll([4, 5, 6]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p1' }, fixedRoll([4, 5, 6]));
  assert.equal(r.ok, true);

  // Round 1 starts, dealer rotates to p2
  assert.equal(s.roundIndex, 1);
  assert.equal(s.round.dealerId, 'p2');
  assert.equal(s.round.dealerHand, null);
  // Dealer acts last, so challenger p1 goes first in round 1
  assert.equal(getCurrentPlayerId(s), 'p1');
});

test('state machine: classic mode derives roundsTotal from setsTotal', () => {
  const s = createInitialGameState(['p1', 'p2', 'p3'], { ruleMode: 'classic', setsTotal: 3 });
  assert.equal(s.config.roundsTotal, 9);
});

test('state machine: classic mode ROUND_STARTED includes correct dealerId', () => {
  const s = createInitialGameState(['p1', 'p2'], { ruleMode: 'classic', setsTotal: 2, rerollsMax: 0 });

  // Dealer acts last; initial dealer is p1.
  let r = applyAction(s, { type: 'ROLL', playerId: 'p2' }, fixedRoll([1, 2, 3]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p2' }, fixedRoll([1, 2, 3]));
  assert.equal(r.ok, true);

  // Dealer p1 keeps, ending round 0 and starting round 1.
  r = applyAction(s, { type: 'ROLL', playerId: 'p1' }, fixedRoll([4, 5, 6]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p1' }, fixedRoll([4, 5, 6]));
  assert.equal(r.ok, true);

  const roundStarted = r.events.find((e) => e.type === 'ROUND_STARTED');
  assert.ok(roundStarted);
  assert.equal(roundStarted.payload.roundIndex, 1);
  // Dealer rotates each round; round 1 dealer should be p2.
  assert.equal(roundStarted.payload.dealerId, 'p2');
});

test('state machine: classic mode ROUND_RESULT includes winnerIds and dealerId', () => {
  const s = createInitialGameState(['p1', 'p2', 'p3'], { ruleMode: 'classic', setsTotal: 1, rerollsMax: 0 });

  // Dealer acts last; initial dealer is p1.
  // p2 beats dealer (456), p3 loses to dealer (123), dealer keeps a pair.
  let r = applyAction(s, { type: 'ROLL', playerId: 'p2' }, fixedRoll([4, 5, 6]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p2' }, fixedRoll([4, 5, 6]));
  assert.equal(r.ok, true);

  r = applyAction(s, { type: 'ROLL', playerId: 'p3' }, fixedRoll([1, 2, 3]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p3' }, fixedRoll([1, 2, 3]));
  assert.equal(r.ok, true);

  r = applyAction(s, { type: 'ROLL', playerId: 'p1' }, fixedRoll([2, 2, 5]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p1' }, fixedRoll([2, 2, 5]));
  assert.equal(r.ok, true);

  const roundResult = r.events.find((e) => e.type === 'ROUND_RESULT');
  assert.ok(roundResult);
  assert.equal(roundResult.payload.roundIndex, 0);
  assert.equal(roundResult.payload.dealerId, 'p1');
  assert.deepEqual(roundResult.payload.winnerIds, ['p2', 'p1']);
});

test('state machine: classic mode dealer acts last each round', () => {
  const s = createInitialGameState(['p1', 'p2', 'p3'], { ruleMode: 'classic', setsTotal: 1, rerollsMax: 0 });
  // Dealer is p1, but first turn should be p2.
  assert.equal(s.round.dealerId, 'p1');
  assert.equal(getCurrentPlayerId(s), 'p2');
});

test('state machine: classic mode starts with 100 chips each', () => {
  const s = createInitialGameState(['p1', 'p2'], { ruleMode: 'classic', setsTotal: 1 });
  assert.equal(s.scores.p1, 100);
  assert.equal(s.scores.p2, 100);
});

test('state machine: classic bets require minimum 10 and dealer cannot bet', () => {
  const s = createInitialGameState(['p1', 'p2'], { ruleMode: 'classic', setsTotal: 1 });
  assert.equal(applyBet(s, 'p2', 0).ok, false);
  assert.equal(applyBet(s, 'p2', 5).ok, false);
  assert.equal(applyBet(s, 'p1', 10).ok, false);
  assert.equal(applyBet(s, 'p2', 10).ok, true);
  assert.equal(s.scores.p2, 90);
});

test('state machine: dealer first roll with any hand locks rerolls', () => {
  const s = createInitialGameState(['p1', 'p2'], { ruleMode: 'classic', setsTotal: 1, rerollsMax: 2 });
  let r = applyAction(s, { type: 'ROLL', playerId: 'p1' }, fixedRoll([2, 2, 5]));
  assert.equal(r.ok, true);
  assert.equal(s.currentTurn.rerollsLeft, 0);
});

test('state machine: dealer instant lose on hifumi pays each child (bet return + bonus)', () => {
  const s = createInitialGameState(['p1', 'p2'], { ruleMode: 'classic', setsTotal: 1, rerollsMax: 1 });
  assert.equal(applyBet(s, 'p2', 10).ok, true);

  const r = applyAction(s, { type: 'ROLL', playerId: 'p1' }, fixedRoll([1, 2, 3]));
  assert.equal(r.ok, true);
  // Child gets pot back + bonus from dealer.
  assert.equal(s.scores.p2, 110);
  assert.equal(s.scores.p1, 90);
  // Round should advance immediately.
  assert.equal(s.roundIndex, 1);
  assert.ok(r.events.find((e) => e.type === 'ROUND_ENDED'));
  assert.ok(r.events.find((e) => e.type === 'ROUND_RESULT'));
});

test('state machine: dealer instant win on 4-5-6 takes pot + 1x bonus', () => {
  const s = createInitialGameState(['p1', 'p2'], { ruleMode: 'classic', setsTotal: 1, rerollsMax: 1 });
  assert.equal(applyBet(s, 'p2', 10).ok, true);

  const r = applyAction(s, { type: 'ROLL', playerId: 'p1' }, fixedRoll([4, 5, 6]));
  assert.equal(r.ok, true);
  // Dealer gets pot + bonus.
  assert.equal(s.scores.p1, 120);
  assert.equal(s.scores.p2, 80);
  assert.equal(s.roundIndex, 1);
  assert.ok(r.events.find((e) => e.type === 'ROUND_RESULT'));
});

test('state machine: dealer instant win on 6-point pair takes pot only (no bonus)', () => {
  const s = createInitialGameState(['p1', 'p2'], { ruleMode: 'classic', setsTotal: 1, rerollsMax: 1 });
  assert.equal(applyBet(s, 'p2', 10).ok, true);

  const r = applyAction(s, { type: 'ROLL', playerId: 'p1' }, fixedRoll([6, 6, 2]));
  assert.equal(r.ok, true);
  // Dealer gets pot only.
  assert.equal(s.scores.p1, 110);
  assert.equal(s.scores.p2, 90);
  assert.equal(s.roundIndex, 1);
  assert.ok(r.events.find((e) => e.type === 'ROUND_RESULT'));
});

test('state machine: dealer instant win on arashi (triple) takes pot + 2x bonus', () => {
  const s = createInitialGameState(['p1', 'p2'], { ruleMode: 'classic', setsTotal: 1, rerollsMax: 1 });
  assert.equal(applyBet(s, 'p2', 10).ok, true);

  const r = applyAction(s, { type: 'ROLL', playerId: 'p1' }, fixedRoll([2, 2, 2]));
  assert.equal(r.ok, true);
  assert.equal(s.scores.p1, 130);
  assert.equal(s.scores.p2, 70);
  assert.equal(s.roundIndex, 1);
});

test('state machine: dealer instant win on pinzoro takes pot + 4x bonus', () => {
  const s = createInitialGameState(['p1', 'p2'], { ruleMode: 'classic', setsTotal: 1, rerollsMax: 1 });
  assert.equal(applyBet(s, 'p2', 10).ok, true);

  const r = applyAction(s, { type: 'ROLL', playerId: 'p1' }, fixedRoll([1, 1, 1]));
  assert.equal(r.ok, true);
  assert.equal(s.scores.p1, 150);
  assert.equal(s.scores.p2, 50);
  assert.equal(s.roundIndex, 1);
});

test('state machine: hifumi loss bonus transfers from loser to winner', () => {
  const s = createInitialGameState(['p1', 'p2'], { ruleMode: 'classic', setsTotal: 1, rerollsMax: 0 });
  assert.equal(applyBet(s, 'p2', 10).ok, true);

  // Dealer rolls a low pair, challenger rolls hifumi and loses.
  let r = applyAction(s, { type: 'ROLL', playerId: 'p1' }, fixedRoll([2, 2, 3]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p1' }, fixedRoll([2, 2, 3]));
  assert.equal(r.ok, true);

  r = applyAction(s, { type: 'ROLL', playerId: 'p2' }, fixedRoll([1, 2, 3]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p2' }, fixedRoll([1, 2, 3]));
  assert.equal(r.ok, true);

  // Dealer gains pot + hifumi bonus.
  assert.equal(s.scores.p1, 120);
  assert.equal(s.scores.p2, 80);
});

test('state machine: classic compares hands (challenger 456 beats dealer pair)', () => {
  const s = createInitialGameState(['p1', 'p2'], { ruleMode: 'classic', setsTotal: 1, rerollsMax: 0 });
  assert.equal(applyBet(s, 'p2', 10).ok, true);

  let r = applyAction(s, { type: 'ROLL', playerId: 'p1' }, fixedRoll([2, 2, 3]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p1' }, fixedRoll([2, 2, 3]));
  assert.equal(r.ok, true);

  r = applyAction(s, { type: 'ROLL', playerId: 'p2' }, fixedRoll([4, 5, 6]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p2' }, fixedRoll([4, 5, 6]));
  assert.equal(r.ok, true);

  // Challenger gets pot + 1x bonus.
  assert.equal(s.scores.p2, 110);
  assert.equal(s.scores.p1, 90);
});

test('state machine: classic compares hands (dealer 456 beats challenger pair)', () => {
  const s = createInitialGameState(['p1', 'p2'], { ruleMode: 'classic', setsTotal: 1, rerollsMax: 0 });
  assert.equal(applyBet(s, 'p2', 10).ok, true);

  let r = applyAction(s, { type: 'ROLL', playerId: 'p1' }, fixedRoll([4, 5, 6]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p1' }, fixedRoll([4, 5, 6]));
  assert.equal(r.ok, true);

  r = applyAction(s, { type: 'ROLL', playerId: 'p2' }, fixedRoll([2, 2, 3]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p2' }, fixedRoll([2, 2, 3]));
  assert.equal(r.ok, true);

  // Dealer gets pot + 1x bonus.
  assert.equal(s.scores.p1, 120);
  assert.equal(s.scores.p2, 80);
});

test('state machine: classic compares hands (hifumi loses to dealer pair)', () => {
  const s = createInitialGameState(['p1', 'p2'], { ruleMode: 'classic', setsTotal: 1, rerollsMax: 0 });
  assert.equal(applyBet(s, 'p2', 10).ok, true);

  let r = applyAction(s, { type: 'ROLL', playerId: 'p1' }, fixedRoll([2, 2, 3]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p1' }, fixedRoll([2, 2, 3]));
  assert.equal(r.ok, true);

  r = applyAction(s, { type: 'ROLL', playerId: 'p2' }, fixedRoll([1, 2, 3]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p2' }, fixedRoll([1, 2, 3]));
  assert.equal(r.ok, true);

  // Dealer gets pot + hifumi penalty.
  assert.equal(s.scores.p1, 120);
  assert.equal(s.scores.p2, 80);
});

test('state machine: classic draw returns pot to challenger (no bonus)', () => {
  const s = createInitialGameState(['p1', 'p2'], { ruleMode: 'classic', setsTotal: 1, rerollsMax: 0 });
  assert.equal(applyBet(s, 'p2', 10).ok, true);

  let r = applyAction(s, { type: 'ROLL', playerId: 'p1' }, fixedRoll([2, 2, 3]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p1' }, fixedRoll([2, 2, 3]));
  assert.equal(r.ok, true);

  r = applyAction(s, { type: 'ROLL', playerId: 'p2' }, fixedRoll([2, 2, 3]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p2' }, fixedRoll([2, 2, 3]));
  assert.equal(r.ok, true);

  // Pot is returned to challenger; no bonus transfer.
  assert.equal(s.scores.p1, 100);
  assert.equal(s.scores.p2, 100);
});

test('state machine: classic triple strength (pinzoro > other triple)', () => {
  const s = createInitialGameState(['p1', 'p2'], { ruleMode: 'classic', setsTotal: 1, rerollsMax: 0 });
  assert.equal(applyBet(s, 'p2', 10).ok, true);

  let r = applyAction(s, { type: 'ROLL', playerId: 'p1' }, fixedRoll([2, 2, 2]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p1' }, fixedRoll([2, 2, 2]));
  assert.equal(r.ok, true);

  r = applyAction(s, { type: 'ROLL', playerId: 'p2' }, fixedRoll([1, 1, 1]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p2' }, fixedRoll([1, 1, 1]));
  assert.equal(r.ok, true);

  // Challenger pinzoro beats dealer triple.
  assert.equal(s.scores.p2, 140);
  assert.equal(s.scores.p1, 60);
});

test('state machine: classic triple strength (higher triple beats lower triple)', () => {
  const s = createInitialGameState(['p1', 'p2'], { ruleMode: 'classic', setsTotal: 1, rerollsMax: 0 });
  assert.equal(applyBet(s, 'p2', 10).ok, true);

  let r = applyAction(s, { type: 'ROLL', playerId: 'p1' }, fixedRoll([2, 2, 2]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p1' }, fixedRoll([2, 2, 2]));
  assert.equal(r.ok, true);

  r = applyAction(s, { type: 'ROLL', playerId: 'p2' }, fixedRoll([6, 6, 6]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p2' }, fixedRoll([6, 6, 6]));
  assert.equal(r.ok, true);

  // Non-pinzoro triples are equal strength (draw).
  assert.equal(s.scores.p2, 100);
  assert.equal(s.scores.p1, 100);
});

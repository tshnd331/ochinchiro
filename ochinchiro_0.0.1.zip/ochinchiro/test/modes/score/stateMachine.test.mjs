import test from 'node:test';
import assert from 'node:assert/strict';

import { applyAction, createInitialGameState, getCurrentPlayerId } from '../../../game/stateMachine.mjs';

function fixedRoll(dice) {
  return () => dice;
}

test('state machine: score mode starts at 0', () => {
  const s = createInitialGameState(['p1', 'p2'], { ruleMode: 'score', roundsTotal: 1 });
  assert.equal(s.scores.p1, 0);
  assert.equal(s.scores.p2, 0);
});

test('state machine: score mode KEEP adds hand score', () => {
  const s = createInitialGameState(['p1', 'p2'], { ruleMode: 'score', roundsTotal: 1, rerollsMax: 0 });

  let r = applyAction(s, { type: 'ROLL', playerId: 'p1' }, fixedRoll([4, 5, 6]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p1' }, fixedRoll([4, 5, 6]));
  assert.equal(r.ok, true);
  assert.equal(s.scores.p1, 90);
});

test('state machine: score mode allows negative scores on hifumi', () => {
  const s = createInitialGameState(['p1'], { ruleMode: 'score', roundsTotal: 1, rerollsMax: 0 });

  let r = applyAction(s, { type: 'ROLL', playerId: 'p1' }, fixedRoll([1, 2, 3]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p1' }, fixedRoll([1, 2, 3]));
  assert.equal(r.ok, true);
  assert.equal(s.scores.p1, -100);
});

test('state machine: score mode ROUND_STARTED payload has no dealerId', () => {
  const s = createInitialGameState(['p1', 'p2'], { ruleMode: 'score', roundsTotal: 2, rerollsMax: 0 });

  let r = applyAction(s, { type: 'ROLL', playerId: 'p1' }, fixedRoll([4, 5, 6]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p1' }, fixedRoll([4, 5, 6]));
  assert.equal(r.ok, true);

  r = applyAction(s, { type: 'ROLL', playerId: 'p2' }, fixedRoll([2, 2, 5]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p2' }, fixedRoll([2, 2, 5]));
  assert.equal(r.ok, true);

  const roundStarted = r.events.find((e) => e.type === 'ROUND_STARTED');
  assert.ok(roundStarted);
  assert.equal(Object.prototype.hasOwnProperty.call(roundStarted.payload, 'dealerId'), false);
});

test('state machine: score mode does not emit ROUND_RESULT', () => {
  const s = createInitialGameState(['p1', 'p2'], { ruleMode: 'score', roundsTotal: 2, rerollsMax: 0 });

  let r = applyAction(s, { type: 'ROLL', playerId: 'p1' }, fixedRoll([4, 5, 6]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p1' }, fixedRoll([4, 5, 6]));
  assert.equal(r.ok, true);

  r = applyAction(s, { type: 'ROLL', playerId: 'p2' }, fixedRoll([2, 2, 5]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p2' }, fixedRoll([2, 2, 5]));
  assert.equal(r.ok, true);

  const roundResult = r.events.find((e) => e.type === 'ROUND_RESULT');
  assert.equal(roundResult, undefined);
});

test('state machine: score mode advances turn order sequentially', () => {
  const s = createInitialGameState(['p1', 'p2', 'p3'], { ruleMode: 'score', roundsTotal: 1, rerollsMax: 0 });
  assert.equal(getCurrentPlayerId(s), 'p1');

  let r = applyAction(s, { type: 'ROLL', playerId: 'p1' }, fixedRoll([2, 2, 5]));
  assert.equal(r.ok, true);
  r = applyAction(s, { type: 'KEEP', playerId: 'p1' }, fixedRoll([2, 2, 5]));
  assert.equal(r.ok, true);
  assert.equal(getCurrentPlayerId(s), 'p2');
});

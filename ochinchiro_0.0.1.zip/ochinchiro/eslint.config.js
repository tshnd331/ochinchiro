import js from '@eslint/js';
import globals from 'globals';

export default [
  js.configs.recommended,
  {
    files: ['**/*.js', '**/*.mjs', '**/*.cjs'],
    ignores: ['node_modules/**', 'dist/**', 'coverage/**', 'data/events/**'],
    languageOptions: {
      ecmaVersion: 'latest',
      sourceType: 'module',
    },
  },
  {
    files: ['public/**/*.js', 'public/**/*.mjs', 'public/**/*.cjs'],
    languageOptions: {
      globals: {
        ...globals.browser,
      },
    },
  },
  {
    files: ['server.mjs', 'server/**/*.js', 'server/**/*.mjs', 'test/**/*.js', 'test/**/*.mjs'],
    languageOptions: {
      globals: {
        ...globals.node,
      },
    },
  },
];

export const KNOWN_RULE_MODES = ['classic', 'score', 'takeall'];
export const ENABLED_RULE_MODES = ['classic', 'score', 'takeall'];

export function normalizeRuleMode(input) {
  const mode = String(input ?? '').trim().toLowerCase();
  if (mode === 'score' || mode === 'classic' || mode === 'takeall') return mode;
  return 'classic';
}

export function assertEnabledRuleMode(mode) {
  if (!ENABLED_RULE_MODES.includes(mode)) {
    throw new Error(`unsupported ruleMode: ${mode}`);
  }
}

export function isClassicMode(mode) {
  return mode === 'classic';
}

export function isScoreMode(mode) {
  return mode === 'score';
}

export function isTakeAllMode(mode) {
  return mode === 'takeall';
}

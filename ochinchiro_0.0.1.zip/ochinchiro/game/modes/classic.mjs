export function isDealerInstantLose(hand) {
  return hand?.kind === '123';
}

export function isDealerInstantWin(hand) {
  if (!hand) return false;
  if (hand.kind === '456') return true;
  if (hand.kind === 'pair' && hand.point === 6) return true;
  if (hand.kind === 'triple') return true;
  return false;
}

export function bonusMultiplierForWinnerHand(hand) {
  if (!hand) return 0;
  if (hand.kind === '456') return 1;
  if (hand.kind === 'pair' && hand.point === 6) return 0;
  if (hand.kind === 'triple') {
    const d = Array.isArray(hand.dice) ? hand.dice : [];
    if (d.length === 3 && d[0] === 1 && d[1] === 1 && d[2] === 1) return 4;
    return 2;
  }
  return 0;
}

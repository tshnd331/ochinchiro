import { DEFAULT_RULES, canKeep, evaluateHand } from './rules.mjs';
import { assertEnabledRuleMode, normalizeRuleMode } from './modes/index.mjs';
import { bonusMultiplierForWinnerHand, isDealerInstantLose, isDealerInstantWin } from './modes/classic.mjs';

export function createInitialGameState(playerOrder, configOverrides = {}) {
  if (!Array.isArray(playerOrder) || playerOrder.length < 1) {
    throw new Error('playerOrder must be a non-empty array');
  }

  let config = {
    ...DEFAULT_RULES,
    ...configOverrides,
  };

  config = {
    ...config,
    ruleMode: normalizeRuleMode(config.ruleMode),
  };
  assertEnabledRuleMode(config.ruleMode);

  if (config.ruleMode === 'classic') {
    const setsTotal = Number(config.setsTotal);
    if (!Number.isInteger(setsTotal) || setsTotal < 1) {
      throw new Error('setsTotal must be an integer >= 1');
    }
    const roundsTotalOverride = configOverrides?.roundsTotal;
    if (roundsTotalOverride === undefined || roundsTotalOverride === null) {
      config = {
        ...config,
        roundsTotal: setsTotal * playerOrder.length,
      };
    }
  }

  const initialScore = config.ruleMode === 'classic' || config.ruleMode === 'takeall' ? 100 : 0;
  const scores = {};
  for (const playerId of playerOrder) scores[playerId] = initialScore;

  const initialOrder =
    config.ruleMode === 'classic' && playerOrder.length > 1
      ? [...playerOrder]
      : [...playerOrder];

  const dealerId =
    config.ruleMode === 'classic'
      ? initialOrder[0]
      : initialOrder[0];

  const takeallBaseOrder = config.ruleMode === 'takeall' ? [...initialOrder] : null;
  if (config.ruleMode === 'takeall' && initialOrder.length > 1) {
    const idx = Math.floor(Math.random() * initialOrder.length);
    const rotated = initialOrder.slice(idx).concat(initialOrder.slice(0, idx));
    initialOrder.length = 0;
    initialOrder.push(...rotated);
  }

  return {
    status: 'in_game',
    config,
    order: initialOrder,
    roundIndex: 0,
    turnIndex: 0,
    scores,
    round: {
      dealerId,
      dealerHand: null,
      challengerHands: {},
      winnerIds: [],
      dealerWonAny: false,
      bets: {},
      potCarry: config.ruleMode === 'takeall' ? 0 : 0,
      takeallOrder: config.ruleMode === 'takeall' ? [...initialOrder] : null,
      takeallContenders: config.ruleMode === 'takeall' ? [...initialOrder] : null,
      takeallHands: config.ruleMode === 'takeall' ? {} : null,
      takeallFullOrder: config.ruleMode === 'takeall' ? (takeallBaseOrder ?? [...initialOrder]) : null,
      takeallLastWinnerId: null,
    },
    currentTurn: {
      playerId: initialOrder[0],
      rerollsLeft: config.rerollsMax,
      lastDice: null,
      lastHand: null,
    },
    seq: 0,
  };
}

export function getCurrentPlayerId(state) {
  return state.currentTurn.playerId;
}

export function applyBet(state, playerId, amount) {
  if (state.status !== 'in_game') {
    return { ok: false, error: 'game_not_in_progress' };
  }
  if (state.config?.ruleMode !== 'classic' && state.config?.ruleMode !== 'takeall') {
    return { ok: false, error: 'bet_not_supported' };
  }
  if (!playerId || !state.scores || !(playerId in state.scores)) {
    return { ok: false, error: 'unknown_player' };
  }
  const dealerId = state.round?.dealerId ?? state.order[0];
  if (state.config?.ruleMode === 'classic' && playerId === dealerId) {
    return { ok: false, error: 'dealer_cannot_bet' };
  }

  const normalized = Number(amount ?? 0);
  if (!Number.isFinite(normalized)) {
    return { ok: false, error: 'invalid_amount' };
  }
  if (normalized < 10 || normalized % 10 !== 0) {
    return { ok: false, error: 'invalid_amount' };
  }

  if (!state.round) {
    state.round = {
      dealerId,
      dealerHand: null,
      challengerHands: {},
      winnerIds: [],
      dealerWonAny: false,
      bets: {},
      potCarry: state.config?.ruleMode === 'takeall' ? Number(state.round?.potCarry ?? 0) : 0,
      takeallOrder: state.config?.ruleMode === 'takeall' ? [...state.order] : null,
      takeallContenders: state.config?.ruleMode === 'takeall' ? [...state.order] : null,
      takeallHands: state.config?.ruleMode === 'takeall' ? {} : null,
      takeallFullOrder: state.config?.ruleMode === 'takeall' ? [...state.order] : null,
    };
  }
  if (!state.round.bets) state.round.bets = {};

  const currentBet = Number(state.round.bets[playerId] ?? 0);
  const maxBet = Number(state.scores[playerId] ?? 0) + currentBet;
  if (normalized > maxBet) {
    return { ok: false, error: 'insufficient_chips' };
  }

  const delta = normalized - currentBet;
  if (delta > 0) {
    if (state.scores[playerId] < delta) {
      return { ok: false, error: 'insufficient_chips' };
    }
    state.scores[playerId] -= delta;
  } else if (delta < 0) {
    state.scores[playerId] += Math.abs(delta);
  }

  state.round.bets[playerId] = normalized;
  return { ok: true };
}

function nextSeq(state) {
  state.seq += 1;
  return state.seq;
}

function advanceTurn(state) {
  const prevRoundIndex = state.roundIndex;

  state.turnIndex += 1;
  if (state.turnIndex >= state.order.length) {
    state.turnIndex = 0;
    state.roundIndex += 1;
  }

  const startedNewRound = state.roundIndex !== prevRoundIndex;

  if (state.roundIndex >= state.config.roundsTotal) {
    state.status = 'finished';
    return;
  }

  // In classic mode, rotate the dealer (turn order) each round for fairness.
  if (startedNewRound && state.config.ruleMode === 'classic' && state.order.length > 1) {
    const first = state.order.shift();
    state.order.push(first);
  }

  if (startedNewRound) {
    state.round = {
      dealerId: state.config.ruleMode === 'classic' ? state.order[0] : state.order[0],
      dealerHand: null,
      challengerHands: {},
      winnerIds: [],
      dealerWonAny: false,
      bets: {},
      potCarry: state.config.ruleMode === 'takeall' ? Number(state.round?.potCarry ?? 0) : 0,
      takeallOrder: state.config.ruleMode === 'takeall' ? [...state.order] : null,
      takeallContenders: state.config.ruleMode === 'takeall' ? [...state.order] : null,
      takeallHands: state.config.ruleMode === 'takeall' ? {} : null,
      takeallFullOrder: state.config.ruleMode === 'takeall' ? (state.round?.takeallFullOrder ?? [...state.order]) : null,
    };
  }

  const nextPlayerId = state.order[state.turnIndex];
  state.currentTurn = {
    playerId: nextPlayerId,
    rerollsLeft: state.config.rerollsMax,
    lastDice: null,
    lastHand: null,
  };
}

function advanceRound(state) {
  state.roundIndex += 1;
  state.turnIndex = 0;

  if (state.roundIndex >= state.config.roundsTotal) {
    state.status = 'finished';
    return;
  }

  // In classic mode, rotate the dealer (turn order) each round for fairness.
  if (state.config.ruleMode === 'classic' && state.order.length > 1) {
    const first = state.order.shift();
    state.order.push(first);
  }

  const prevPotCarry = Number(state.round?.potCarry ?? 0);

  if (state.config.ruleMode === 'takeall') {
    const baseOrder = Array.isArray(state.round?.takeallFullOrder)
      ? [...state.round.takeallFullOrder]
      : [...state.order];
    const lastWinnerId = state.round?.takeallLastWinnerId ?? null;
    if (lastWinnerId && baseOrder.includes(lastWinnerId)) {
      const idx = baseOrder.indexOf(lastWinnerId);
      state.order = baseOrder.slice(idx).concat(baseOrder.slice(0, idx));
    } else {
      state.order = baseOrder;
    }
  }

  state.round = {
    dealerId: state.config.ruleMode === 'classic' ? state.order[0] : state.order[0],
    dealerHand: null,
    challengerHands: {},
    winnerIds: [],
    dealerWonAny: false,
    bets: {},
    potCarry: state.config.ruleMode === 'takeall' ? prevPotCarry : 0,
    takeallOrder: state.config.ruleMode === 'takeall' ? [...state.order] : null,
    takeallContenders: state.config.ruleMode === 'takeall' ? [...state.order] : null,
    takeallHands: state.config.ruleMode === 'takeall' ? {} : null,
    takeallFullOrder: state.config.ruleMode === 'takeall' ? (state.round?.takeallFullOrder ?? [...state.order]) : null,
    takeallLastWinnerId: state.config.ruleMode === 'takeall' ? (state.round?.takeallLastWinnerId ?? null) : null,
  };

  const nextPlayerId = state.order[state.turnIndex];
  state.currentTurn = {
    playerId: nextPlayerId,
    rerollsLeft: state.config.rerollsMax,
    lastDice: null,
    lastHand: null,
  };
}

export function applyAction(state, action, rollDice3) {
  // action: { type: 'ROLL'|'REROLL'|'KEEP', playerId: string }
  // rollDice3: () => [d1,d2,d3]
  if (state.status !== 'in_game') {
    return { ok: false, error: 'game_not_in_progress', events: [] };
  }

  const expectedPlayerId = getCurrentPlayerId(state);
  if (action.playerId !== expectedPlayerId) {
    return { ok: false, error: 'not_your_turn', events: [] };
  }

  const events = [];
  const pushTransferEvent = (fromPlayerId, toPlayerId, amount) => {
    if (!amount || amount <= 0) return;
    events.push({
      seq: nextSeq(state),
      type: 'BET_TRANSFER',
      payload: {
        fromPlayerId: fromPlayerId ?? null,
        toPlayerId: toPlayerId ?? null,
        amount,
        roundIndex: state.roundIndex,
      },
    });
  };
  const bonusMultiplierForHand = bonusMultiplierForWinnerHand;
  const takeallHandMultiplier = (hand) => {
    if (!hand) return 0;
    if (hand.kind === 'triple') {
      if (hand.rank === 2000 || hand.label === 'ピンゾロ') return 5;
      return 3;
    }
    if (hand.kind === '456') return 2;
    if (hand.kind === 'none') return 0;
    return 1;
  };
    const takeallParticipantMultiplier = (playerCount) => {
      switch (Number(playerCount)) {
        case 2:
          return 1;
        case 3:
          return 1.5;
        case 4:
          return 2;
        case 5:
          return 2.5;
        case 6:
          return 3;
        default:
          return 1;
      }
    };
  const resolveDealerInstant = (hand) => {
    if (state.config?.ruleMode !== 'classic') return null;
    const dealerId = state.round?.dealerId;
    if (!dealerId || action.playerId !== dealerId) return null;

    if (isDealerInstantLose(hand)) {
      const bets = state.round.bets ?? {};
      const winnerIds = state.order.filter((pid) => pid !== dealerId);

      for (const [pid, amountRaw] of Object.entries(bets)) {
        if (pid === dealerId) continue;
        const betAmount = Number(amountRaw ?? 0);
        if (betAmount <= 0) continue;
        // Return pot to child
        state.scores[pid] += betAmount;
        pushTransferEvent(null, pid, betAmount);
        // Dealer pays bonus equal to bet
        state.scores[pid] += betAmount;
        state.scores[dealerId] -= betAmount;
        pushTransferEvent(dealerId, pid, betAmount);
        bets[pid] = 0;
      }

      events.push({
        seq: nextSeq(state),
        type: 'TURN_ENDED',
        payload: {
          playerId: action.playerId,
          gained: 0,
          totalScore: state.scores[action.playerId],
          roundIndex: state.roundIndex,
        },
      });

      const prevRoundIndex = state.roundIndex;
      advanceRound(state);

      if (state.status === 'finished') {
        events.push({ seq: nextSeq(state), type: 'GAME_ENDED', payload: { scores: state.scores } });
        return { ok: true, events };
      }

      if (state.roundIndex !== prevRoundIndex) {
        events.push({ seq: nextSeq(state), type: 'ROUND_ENDED', payload: { roundIndex: prevRoundIndex } });
        events.push({
          seq: nextSeq(state),
          type: 'ROUND_RESULT',
          payload: {
            roundIndex: prevRoundIndex,
            dealerId,
            winnerIds,
          },
        });
        events.push({
          seq: nextSeq(state),
          type: 'ROUND_STARTED',
          payload: { roundIndex: state.roundIndex, dealerId: state.round?.dealerId ?? state.order[0] },
        });
      }

      events.push({
        seq: nextSeq(state),
        type: 'TURN_STARTED',
        payload: {
          playerId: state.currentTurn.playerId,
          roundIndex: state.roundIndex,
          rerollsLeft: state.currentTurn.rerollsLeft,
        },
      });

      return { ok: true, events };
    }

    if (isDealerInstantWin(hand)) {
      const multiplier = bonusMultiplierForHand(hand);
      if (multiplier >= 0) {
        const bets = state.round.bets ?? {};
        const winnerIds = [dealerId];

        for (const [pid, amountRaw] of Object.entries(bets)) {
          if (pid === dealerId) continue;
          const betAmount = Number(amountRaw ?? 0);
          if (betAmount <= 0) continue;
          // Pot goes to dealer
          state.scores[dealerId] += betAmount;
          pushTransferEvent(null, dealerId, betAmount);
          // Bonus from child to dealer
          if (multiplier > 0) {
            const bonus = betAmount * multiplier;
            state.scores[dealerId] += bonus;
            state.scores[pid] -= bonus;
            pushTransferEvent(pid, dealerId, bonus);
          }
          bets[pid] = 0;
        }

        events.push({
          seq: nextSeq(state),
          type: 'TURN_ENDED',
          payload: {
            playerId: action.playerId,
            gained: 0,
            totalScore: state.scores[action.playerId],
            roundIndex: state.roundIndex,
          },
        });

      const prevRoundIndex = state.roundIndex;
      advanceRound(state);

        if (state.status === 'finished') {
          events.push({ seq: nextSeq(state), type: 'GAME_ENDED', payload: { scores: state.scores } });
          return { ok: true, events };
        }

        if (state.roundIndex !== prevRoundIndex) {
          events.push({ seq: nextSeq(state), type: 'ROUND_ENDED', payload: { roundIndex: prevRoundIndex } });
          events.push({
            seq: nextSeq(state),
            type: 'ROUND_RESULT',
            payload: {
              roundIndex: prevRoundIndex,
              dealerId,
              winnerIds,
            },
          });
          events.push({
            seq: nextSeq(state),
            type: 'ROUND_STARTED',
            payload: { roundIndex: state.roundIndex, dealerId: state.round?.dealerId ?? state.order[0] },
          });
        }

        events.push({
          seq: nextSeq(state),
          type: 'TURN_STARTED',
          payload: {
            playerId: state.currentTurn.playerId,
            roundIndex: state.roundIndex,
            rerollsLeft: state.currentTurn.rerollsLeft,
          },
        });

        return { ok: true, events };
      }
    }

    return null;
  };

  if (action.type === 'ROLL') {
    if (state.currentTurn.lastDice) {
      return { ok: false, error: 'already_rolled', events: [] };
    }

    const dice = rollDice3();
    const hand = evaluateHand(dice, state.config?.ruleMode);

    state.currentTurn.lastDice = dice;
    state.currentTurn.lastHand = hand;
    if (
      state.config?.ruleMode === 'classic' &&
      state.round?.dealerId &&
      action.playerId === state.round.dealerId
    ) {
      // Dealer's first roll with any hand locks rerolls.
      if (hand?.kind && hand.kind !== 'none') {
        state.currentTurn.rerollsLeft = 0;
      }
    }

    events.push({ seq: nextSeq(state), type: 'ROLL_RESOLVED', payload: { playerId: action.playerId, dice, hand } });

    const resolvedInstant = resolveDealerInstant(hand);
    if (resolvedInstant) return resolvedInstant;

    return { ok: true, events };
  }

  if (action.type === 'REROLL') {
    if (!state.currentTurn.lastDice) {
      return { ok: false, error: 'no_roll_yet', events: [] };
    }
    if (state.currentTurn.lastHand?.kind === '123') {
      return { ok: false, error: 'hifumi_no_reroll', events: [] };
    }
    if (state.currentTurn.rerollsLeft <= 0) {
      return { ok: false, error: 'no_rerolls_left', events: [] };
    }

    state.currentTurn.rerollsLeft -= 1;

    const dice = rollDice3();
    const hand = evaluateHand(dice, state.config?.ruleMode);

    state.currentTurn.lastDice = dice;
    state.currentTurn.lastHand = hand;

    events.push({
      seq: nextSeq(state),
      type: 'ROLL_RESOLVED',
      payload: { playerId: action.playerId, dice, hand, rerollsLeft: state.currentTurn.rerollsLeft },
    });

    const resolvedInstant = resolveDealerInstant(hand);
    if (resolvedInstant) return resolvedInstant;

    return { ok: true, events };
  }

  if (action.type === 'KEEP') {
    if (!state.currentTurn.lastDice || !state.currentTurn.lastHand) {
      return { ok: false, error: 'no_roll_yet', events: [] };
    }
    const keepAllowed = canKeep(state.currentTurn.lastHand, state.currentTurn.rerollsLeft, state.config?.ruleMode);
    if (!keepAllowed) {
      const forceKeep =
        action?.heberekeForceKeep === true &&
        state.config?.ruleMode !== 'takeall' &&
        state.currentTurn.lastHand?.kind === 'none' &&
        state.currentTurn.lastHand?.kind !== '123';
      if (!forceKeep) {
        return { ok: false, error: 'cannot_keep_yet', events: [] };
      }
    }

    let gained = 0;
    let classicRoundResult = null;

    if (state.config.ruleMode === 'takeall') {
      const round = state.round ?? {};
      const order = Array.isArray(round.takeallOrder) ? round.takeallOrder : [...state.order];
      const contenders = Array.isArray(round.takeallContenders) ? round.takeallContenders : [...order];
      round.takeallOrder = order;
      round.takeallContenders = contenders;
      round.takeallHands = round.takeallHands ?? {};
      if (!round.takeallFullOrder) round.takeallFullOrder = [...state.order];
      const myHand = state.currentTurn.lastHand;

      round.takeallHands[action.playerId] = myHand;

      events.push({
        seq: nextSeq(state),
        type: 'TURN_ENDED',
        payload: {
          playerId: action.playerId,
          gained,
          totalScore: state.scores[action.playerId],
          roundIndex: state.roundIndex,
        },
      });

      const allHaveHands = contenders.every((pid) => round.takeallHands?.[pid]);
      if (!allHaveHands) {
        const currentIndex = order.indexOf(action.playerId);
        const nextIndex = (currentIndex + 1) % order.length;
        const nextPlayerId = order[nextIndex];
        state.turnIndex = nextIndex;
        state.currentTurn = {
          playerId: nextPlayerId,
          rerollsLeft: state.config.rerollsMax,
          lastDice: null,
          lastHand: null,
        };

        events.push({
          seq: nextSeq(state),
          type: 'TURN_STARTED',
          payload: {
            playerId: state.currentTurn.playerId,
            roundIndex: state.roundIndex,
            rerollsLeft: state.currentTurn.rerollsLeft,
          },
        });

        return { ok: true, events };
      }

      let topRank = -Infinity;
      for (const pid of contenders) {
        const hand = round.takeallHands?.[pid];
        if (!hand) continue;
        if (hand.rank > topRank) topRank = hand.rank;
      }

      const topIds = contenders.filter((pid) => round.takeallHands?.[pid]?.rank === topRank);
      if (topIds.length > 1) {
        round.takeallContenders = [...topIds];
        round.takeallOrder = [...topIds];
        round.takeallHands = {};
        state.order = [...topIds];
        state.turnIndex = 0;
        state.currentTurn = {
          playerId: state.order[0],
          rerollsLeft: state.config.rerollsMax,
          lastDice: null,
          lastHand: null,
        };

        events.push({
          seq: nextSeq(state),
          type: 'TURN_STARTED',
          payload: {
            playerId: state.currentTurn.playerId,
            roundIndex: state.roundIndex,
            rerollsLeft: state.currentTurn.rerollsLeft,
          },
        });

        return { ok: true, events };
      }

      const winnerId = topIds[0];
      const bets = round.bets ?? {};
      const potCarry = Number(round.potCarry ?? 0);
      const potTotal = potCarry + Object.values(bets).reduce((sum, v) => sum + Number(v ?? 0), 0);
      const winnerBet = Number(bets[winnerId] ?? 0);
      const winnerHand = round.takeallHands?.[winnerId] ?? null;
      const playerCount = Number(round.takeallFullOrder?.length ?? state.order.length ?? 0);
      const takeAmount = (takeallHandMultiplier(winnerHand) + takeallParticipantMultiplier(playerCount)) * winnerBet;
      const payout = Math.max(0, Math.min(potTotal, takeAmount));
      if (winnerId && payout > 0) {
        state.scores[winnerId] += payout;
        pushTransferEvent(null, winnerId, payout);
      }
      round.potCarry = Math.max(0, potTotal - payout);
      for (const pid of Object.keys(bets)) bets[pid] = 0;

      round.winnerIds = [winnerId];
      round.takeallLastWinnerId = winnerId;

      if (round.takeallFullOrder) {
        state.order = [...round.takeallFullOrder];
      }

      const prevRoundIndex = state.roundIndex;
      const prevRound = state.round;
      const prevDealerId = prevRound?.dealerId ?? state.order[0];
      advanceRound(state);

      if (state.status === 'finished') {
        events.push({ seq: nextSeq(state), type: 'GAME_ENDED', payload: { scores: state.scores } });
        return { ok: true, events };
      }

      if (state.roundIndex !== prevRoundIndex) {
        events.push({ seq: nextSeq(state), type: 'ROUND_ENDED', payload: { roundIndex: prevRoundIndex } });
        classicRoundResult = {
          roundIndex: prevRoundIndex,
          dealerId: prevDealerId,
          winnerIds: [winnerId],
        };
        events.push({ seq: nextSeq(state), type: 'ROUND_RESULT', payload: classicRoundResult });
        events.push({
          seq: nextSeq(state),
          type: 'ROUND_STARTED',
          payload: { roundIndex: state.roundIndex, dealerId: state.round?.dealerId ?? state.order[0] },
        });
      }

      events.push({
        seq: nextSeq(state),
        type: 'TURN_STARTED',
        payload: {
          playerId: state.currentTurn.playerId,
          roundIndex: state.roundIndex,
          rerollsLeft: state.currentTurn.rerollsLeft,
        },
      });

      return { ok: true, events };
    }

    if (state.config.ruleMode === 'classic') {
      const dealerId = state.round?.dealerId ?? state.order[0];
      const dealerHand = state.round?.dealerHand ?? null;
      const myHand = state.currentTurn.lastHand;
      const winnerIds = Array.isArray(state.round?.winnerIds) ? state.round.winnerIds : [];
      let dealerWonAny = Boolean(state.round?.dealerWonAny);
      const bets = state.round?.bets ?? {};

      if (action.playerId === dealerId) {
        // Dealer (parent) acts first in the round.
        state.round.dealerId = dealerId;
        state.round.dealerHand = myHand;

        const challengerHands = state.round.challengerHands ?? {};
        for (const [pid, hand] of Object.entries(challengerHands)) {
          if (!hand) continue;
          const betAmount = Number(bets[pid] ?? 0);
          if (hand.rank > myHand.rank) {
            if (!winnerIds.includes(pid)) winnerIds.push(pid);
            if (betAmount > 0) {
              state.scores[pid] += betAmount;
              pushTransferEvent(null, pid, betAmount);
            }
            const bonus = betAmount * bonusMultiplierForHand(hand);
            if (bonus !== 0) {
              const fromId = bonus > 0 ? dealerId : pid;
              const toId = bonus > 0 ? pid : dealerId;
              const amount = Math.abs(bonus);
              state.scores[toId] += amount;
              state.scores[fromId] -= amount;
              pushTransferEvent(fromId, toId, amount);
            }
          } else if (hand.rank < myHand.rank) {
            if (betAmount > 0) {
              state.scores[dealerId] += betAmount;
              pushTransferEvent(null, dealerId, betAmount);
            }
            dealerWonAny = true;
            const bonus = betAmount * bonusMultiplierForHand(myHand);
            if (bonus !== 0) {
              const fromId = bonus > 0 ? pid : dealerId;
              const toId = bonus > 0 ? dealerId : pid;
              const amount = Math.abs(bonus);
              state.scores[toId] += amount;
              state.scores[fromId] -= amount;
              pushTransferEvent(fromId, toId, amount);
            }
            if (hand.kind === '123' && betAmount > 0) {
              state.scores[dealerId] += betAmount;
              state.scores[pid] -= betAmount;
              pushTransferEvent(pid, dealerId, betAmount);
            }
          } else if (betAmount > 0) {
            state.scores[pid] += betAmount;
            pushTransferEvent(null, pid, betAmount);
          }
          if (betAmount > 0) bets[pid] = 0;
        }

        state.round.challengerHands = {};
        state.round.winnerIds = winnerIds;
        state.round.dealerWonAny = dealerWonAny;
        gained = 0;
      } else if (dealerHand) {
        const betAmount = Number(bets[action.playerId] ?? 0);
        if (myHand.rank > dealerHand.rank) {
          gained = 0;
          if (!winnerIds.includes(action.playerId)) winnerIds.push(action.playerId);
          if (betAmount > 0) {
            state.scores[action.playerId] += betAmount;
            pushTransferEvent(null, action.playerId, betAmount);
          }
          const bonus = betAmount * bonusMultiplierForHand(myHand);
          if (bonus !== 0) {
            const fromId = bonus > 0 ? dealerId : action.playerId;
            const toId = bonus > 0 ? action.playerId : dealerId;
            const amount = Math.abs(bonus);
            state.scores[toId] += amount;
            state.scores[fromId] -= amount;
            pushTransferEvent(fromId, toId, amount);
          }
        } else if (myHand.rank < dealerHand.rank) {
          gained = 0;
          dealerWonAny = true;
          if (betAmount > 0) {
            state.scores[dealerId] += betAmount;
            pushTransferEvent(null, dealerId, betAmount);
          }
          const bonus = betAmount * bonusMultiplierForHand(dealerHand);
          if (bonus !== 0) {
            const fromId = bonus > 0 ? action.playerId : dealerId;
            const toId = bonus > 0 ? dealerId : action.playerId;
            const amount = Math.abs(bonus);
            state.scores[toId] += amount;
            state.scores[fromId] -= amount;
            pushTransferEvent(fromId, toId, amount);
          }
          if (myHand.kind === '123' && betAmount > 0) {
            state.scores[dealerId] += betAmount;
            state.scores[action.playerId] -= betAmount;
            pushTransferEvent(action.playerId, dealerId, betAmount);
          }
        } else {
          gained = 0;
          if (betAmount > 0) {
            state.scores[action.playerId] += betAmount;
            pushTransferEvent(null, action.playerId, betAmount);
          }
        }
        if (betAmount > 0) bets[action.playerId] = 0;
        state.round.winnerIds = winnerIds;
        state.round.dealerWonAny = dealerWonAny;
      } else {
        // Safety: if a challenger somehow acts before dealer, store the hand.
        state.round.challengerHands = state.round.challengerHands ?? {};
        state.round.challengerHands[action.playerId] = myHand;
        gained = 0;
      }
    } else {
      gained = state.currentTurn.lastHand.score;
      state.scores[action.playerId] += gained;
    }

    events.push({
      seq: nextSeq(state),
      type: 'TURN_ENDED',
      payload: {
        playerId: action.playerId,
        gained,
        totalScore: state.scores[action.playerId],
        roundIndex: state.roundIndex,
      },
    });

    const prevRoundIndex = state.roundIndex;
    const prevRound = state.round;
    const prevDealerId = prevRound?.dealerId ?? state.order[0];
    advanceTurn(state);

    if (state.status === 'finished') {
      events.push({ seq: nextSeq(state), type: 'GAME_ENDED', payload: { scores: state.scores } });
      return { ok: true, events };
    }

    if (state.roundIndex !== prevRoundIndex) {
      events.push({ seq: nextSeq(state), type: 'ROUND_ENDED', payload: { roundIndex: prevRoundIndex } });
      if (state.config.ruleMode === 'classic') {
        const prevRoundSafe = prevRound ?? {};
        const roundWinners = Array.isArray(prevRoundSafe.winnerIds) ? [...prevRoundSafe.winnerIds] : [];
        if (prevRoundSafe.dealerWonAny && !roundWinners.includes(prevDealerId)) {
          roundWinners.push(prevDealerId);
        }
        classicRoundResult = {
          roundIndex: prevRoundIndex,
          dealerId: prevDealerId,
          winnerIds: roundWinners,
        };
        events.push({ seq: nextSeq(state), type: 'ROUND_RESULT', payload: classicRoundResult });
      }
      events.push({
        seq: nextSeq(state),
        type: 'ROUND_STARTED',
        payload:
          state.config.ruleMode === 'classic'
            ? { roundIndex: state.roundIndex, dealerId: state.round?.dealerId ?? state.order[0] }
            : { roundIndex: state.roundIndex },
      });
    }

    events.push({
      seq: nextSeq(state),
      type: 'TURN_STARTED',
      payload: {
        playerId: state.currentTurn.playerId,
        roundIndex: state.roundIndex,
        rerollsLeft: state.currentTurn.rerollsLeft,
      },
    });

    return { ok: true, events };
  }

  return { ok: false, error: 'unknown_action', events: [] };
}

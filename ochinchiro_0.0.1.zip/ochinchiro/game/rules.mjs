﻿export const DEFAULT_RULES = {
  diceCount: 3,
  rerollsMax: 2,
  roundsTotal: 5,
  // Classic mode: total sets. One set = (playerCount) rounds.
  // Total classic rounds are derived as: roundsTotal = setsTotal * playerCount.
  setsTotal: 3,
  ruleMode: 'score', // 'score'|'classic'
};

function assertDice(dice) {
  if (!Array.isArray(dice) || dice.length !== 3) {
    throw new Error('dice must be an array of 3 numbers');
  }
  for (const die of dice) {
    if (!Number.isInteger(die) || die < 1 || die > 6) {
      throw new Error('die must be an integer in 1..6');
    }
  }
}

export function normalizeDice(dice) {
  assertDice(dice);
  return [...dice].sort((a, b) => a - b);
}

export function evaluateHand(dice, ruleMode = 'score') {
  const [a, b, c] = normalizeDice(dice);
  const isTakeall = ruleMode === 'takeall';

  if (a === b && b === c) {
    // Strongest.
    // Special case: pinzoro (1-1-1) is the highest triple.
    // Otherwise, all other triples are equal strength.
    if (a === 1) {
      return {
        kind: 'triple',
        label: 'ピンゾロ',
        score: isTakeall ? 2000 : 200,
        rank: 2000,
        dice: [a, b, c],
      };
    }
    return {
      kind: 'triple',
      label: isTakeall ? `${a}ゾロ` : 'アラシ',
      score: isTakeall ? 1900 + a : 110,
      rank: isTakeall ? 1900 + a : 1100,
      dice: [a, b, c],
    };
  }

  if (a === 4 && b === 5 && c === 6) {
    return {
      kind: '456',
      label: 'シゴロ',
      score: isTakeall ? 1800 : 90,
      rank: isTakeall ? 1800 : 900,
      dice: [a, b, c],
    };
  }

  if (a === 1 && b === 2 && c === 3) {
    // Worst: negative points.
    return {
      kind: '123',
      label: 'ヒフミ',
      score: isTakeall ? 0 : -100,
      rank: isTakeall ? 0 : -100,
      dice: [a, b, c],
    };
  }

  // Pair + point
  if (a === b || b === c) {
    const pairValue = b;
    const point = a === b ? c : a;
    const isClassic = ruleMode === 'classic';
    return {
      kind: 'pair',
      label: `${point}の目`,
      pairValue,
      point,
      score: isTakeall ? 1700 + point : isClassic ? 20 : 20 + point,
      rank: isTakeall ? 1700 + point : isClassic ? 500 : 500 + point,
      dice: [a, b, c],
    };
  }

  // No hand.
  return {
    kind: 'none',
    label: '役なし',
    score: isTakeall ? 100 : 0,
    rank: isTakeall ? 100 : 0,
    dice: [a, b, c],
  };
}

export function canKeep(hand, rerollsLeft, ruleMode = 'score') {
  if (ruleMode === 'takeall') return true;
  // MVP rule:
  // - If none: you may keep only when rerollsLeft === 0 (it becomes 0 points).
  // - Otherwise: always keepable.
  if (hand.kind === 'none') return rerollsLeft <= 0;
  return true;
}

export function formatDice(dice) {
  const [a, b, c] = normalizeDice(dice);
  return `${a}-${b}-${c}`;
}









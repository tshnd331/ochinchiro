import { evaluateHand } from '../rules.mjs';

function computeExpectedScoreFreshRoll() {
  let sum = 0;
  let count = 0;
  for (let a = 1; a <= 6; a++) {
    for (let b = 1; b <= 6; b++) {
      for (let c = 1; c <= 6; c++) {
        const hand = evaluateHand([a, b, c]);
        sum += hand.score;
        count++;
      }
    }
  }
  return sum / count;
}

export const EXPECTED_SCORE_FRESH_ROLL = computeExpectedScoreFreshRoll();

function clamp01(v) {
  return Math.max(0, Math.min(1, v));
}

function pickWeighted(options, weights) {
  const total = weights.reduce((s, w) => s + w, 0);
  let r = Math.random() * total;
  for (let i = 0; i < options.length; i++) {
    r -= weights[i];
    if (r <= 0) return options[i];
  }
  return options[options.length - 1];
}

export function chooseBotBet({
  difficulty,
  bankrollCPU,
  bankrollOpponent,
  roundsLeft,
  minBet,
  options,
}) {
  if (!Number.isFinite(bankrollCPU) || bankrollCPU <= 0) return 0;
  const capRate = difficulty === 'easy' ? 0.25 : difficulty === 'normal' ? 0.35 : 0.45;
  const maxBet = Math.max(minBet, Math.floor(bankrollCPU * capRate));
  const filtered = options.filter((b) => b >= minBet && b <= maxBet);
  if (filtered.length === 0) return Math.min(minBet, bankrollCPU);

  if (difficulty === 'easy') {
    const easyOptions = filtered.slice(0, Math.min(4, filtered.length));
    const weights = easyOptions.map((_, i) => (i === 0 ? 50 : i === 1 ? 30 : i === 2 ? 15 : 5));
    let bet = pickWeighted(easyOptions, weights);
    if (bankrollCPU < bankrollOpponent && Math.random() < 0.2) {
      bet = filtered[Math.min(filtered.length - 1, 1)];
    }
    return bet;
  }

  let targetRate = 0.12;
  const diff = bankrollCPU - bankrollOpponent;
  if (difficulty === 'normal') {
    if (diff > bankrollOpponent * 0.2) targetRate -= 0.04;
    if (diff < -bankrollOpponent * 0.2) targetRate += 0.06;
    if (roundsLeft <= 5) targetRate += 0.05;
    targetRate += (Math.random() * 0.04 - 0.02);
  } else {
    const danger = clamp01((20 - bankrollCPU) / 20);
    const urgency = clamp01((-diff) / (bankrollOpponent * 0.6 || 1));
    const finish = clamp01(diff / (bankrollOpponent * 0.5 || 1));
    targetRate = 0.18 + 0.20 * urgency + 0.10 * danger - 0.08 * finish;
    targetRate *= (0.9 + Math.random() * 0.2);
  }

  let rawBet = Math.max(minBet, Math.floor(bankrollCPU * targetRate));
  rawBet = Math.min(rawBet, maxBet);
  let best = filtered[0];
  let bestDiff = Math.abs(filtered[0] - rawBet);
  for (const b of filtered) {
    const d = Math.abs(b - rawBet);
    if (d < bestDiff) {
      best = b;
      bestDiff = d;
    }
  }
  return best;
}

export function decideBotAction({
  difficulty,
  hand,
  rerollsLeft,
  situation,
}) {
  // situation: { roundIndex, roundsTotal, myScore, topScore }
  if (rerollsLeft <= 0) return 'keep';

  // Rule: ヒフミ (1-2-3) cannot be rerolled.
  if (hand.kind === '123') return 'keep';

  if (hand.kind === 'none') return 'reroll';

  if (situation?.mode === 'takeall') {
    const topRank = Number(situation?.takeallTopRank ?? -Infinity);
    if (Number.isFinite(topRank) && topRank > -Infinity) {
      if (difficulty === 'easy') {
        if (hand.rank < topRank && hand.rank < 1700) return 'reroll';
        return 'keep';
      }
      if (difficulty === 'normal') {
        return hand.rank < topRank ? 'reroll' : 'keep';
      }
      // hard
      if (hand.rank < topRank) return 'reroll';
      return 'keep';
    }
  }

  if (difficulty === 'easy') {
    if (hand.kind === 'pair' && hand.point <= 2) return 'reroll';
    return 'keep';
  }

  if (difficulty === 'normal') {
    return hand.score < EXPECTED_SCORE_FRESH_ROLL ? 'reroll' : 'keep';
  }

  // hard
  const scoreGap = Math.max(0, (situation?.topScore ?? 0) - (situation?.myScore ?? 0));
  const isLastRound = (situation?.roundIndex ?? 0) >= (situation?.roundsTotal ?? 1) - 1;

  let threshold = EXPECTED_SCORE_FRESH_ROLL;
  if (scoreGap >= 30) threshold += 5;
  if (isLastRound) threshold += 5;

  return hand.score < threshold ? 'reroll' : 'keep';
}

import http from 'node:http';
import { createReadStream, existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';
import { Server } from 'socket.io';

import { applyAction, applyBet, createInitialGameState, getCurrentPlayerId } from './game/stateMachine.mjs';
import { assertEnabledRuleMode, normalizeRuleMode } from './game/modes/index.mjs';
import { evaluateHand } from './game/rules.mjs';
import { chooseBotBet, decideBotAction } from './game/bot/strategies.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT ?? 3000);
const DATA_DIR = process.env.DATA_DIR ?? path.join(__dirname, 'data');
const TURN_TIMEOUT_MS = Number(process.env.TURN_TIMEOUT_MS ?? 20000);
const ROUND_ADVANCE_TIMEOUT_MS = Number(process.env.ROUND_ADVANCE_TIMEOUT_MS ?? TURN_TIMEOUT_MS);
const AUTO_KEEP_DELAY_MS = Number(process.env.AUTO_KEEP_DELAY_MS ?? 1500);
const DEBUG_DICE_ENABLED = process.env.DEBUG_DICE === '1';

const PUBLIC_DIR = path.join(__dirname, 'public');

function randomId() {
  return crypto.randomUUID();
}

function randomToken() {
  return crypto.randomBytes(24).toString('base64url');
}

function randomInviteCode() {
  // 6 chars, base32-ish
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let out = '';
  for (let i = 0; i < 6; i++) out += alphabet[crypto.randomInt(0, alphabet.length)];
  return out;
}

function rollDice3() {
  return [crypto.randomInt(1, 7), crypto.randomInt(1, 7), crypto.randomInt(1, 7)];
}

function normalizeDebugDice(value) {
  if (!DEBUG_DICE_ENABLED) return null;
  if (!Array.isArray(value) || value.length !== 3) return null;
  const dice = value.map((v) => Number(v));
  if (!dice.every((d) => Number.isInteger(d) && d >= 1 && d <= 6)) return null;
  return dice;
}

function normalizeDebugHebereke(value) {
  const v = Number(value);
  if (!Number.isFinite(v)) return null;
  return Math.max(0, Math.min(5, Math.round(v)));
}

function nowIso() {
  return new Date().toISOString();
}

function json(res, status, body) {
  const buf = Buffer.from(JSON.stringify(body));
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': buf.length,
  });
  res.end(buf);
}

async function serveStatic(req, res) {
  const url = new URL(req.url ?? '/', `http://${req.headers.host ?? 'localhost'}`);
  if (url.pathname === '/health') {
    return json(res, 200, { ok: true, uptimeSec: process.uptime() });
  }

  if (url.pathname.startsWith('/api/')) {
    return json(res, 404, { ok: false, error: 'not_implemented' });
  }

  const pathname = url.pathname === '/' ? '/index.html' : url.pathname;
  const safePath = path.normalize(pathname).replace(/^([/\\])+/g, '');
  const filePath = path.join(PUBLIC_DIR, safePath);

  if (!filePath.startsWith(PUBLIC_DIR)) {
    res.writeHead(400);
    res.end('bad path');
    return;
  }

  if (!existsSync(filePath)) {
    res.writeHead(404);
    res.end('not found');
    return;
  }

  const ext = path.extname(filePath);
  const contentType =
    ext === '.html' ? 'text/html; charset=utf-8' :
    ext === '.js' ? 'text/javascript; charset=utf-8' :
    ext === '.css' ? 'text/css; charset=utf-8' :
    'application/octet-stream';

  res.writeHead(200, { 'content-type': contentType });
  createReadStream(filePath).pipe(res);
}

const server = http.createServer((req, res) => {
  serveStatic(req, res).catch((err) => {
    console.error('static error', err);
    res.writeHead(500);
    res.end('internal error');
  });
});

const io = new Server(server, {
  cors: { origin: true, credentials: true },
});

console.log(`[debug] DEBUG_DICE ${DEBUG_DICE_ENABLED ? 'enabled' : 'disabled'}`);

/**
 * In-memory rooms.
 * This MVP keeps state in memory. Audit logs are persisted.
 */
const roomsById = new Map();
const roomsByCode = new Map();

function makeRoom(mode) {
  const roomId = randomId();
  let inviteCode = randomInviteCode();
  while (roomsByCode.has(inviteCode)) inviteCode = randomInviteCode();

  return {
    roomId,
    inviteCode,
    mode, // 'pvp'
    // Default to 'classic' unless explicitly changed.
    ruleMode: 'classic', // 'score'|'classic'
    classicSetsTotal: 3,
    nextBotNumber: 1,
    status: 'lobby',
    createdAt: nowIso(),
    hostPlayerId: null,
    players: new Map(), // playerId -> player
    reconnectTokenToPlayerId: new Map(),
    chat: [],
    game: null,
    timers: { turn: null, autoKeep: null, bot: null, setsLog: null, roundAdvance: null, bet: null },
    autoKeep: null, // { playerId, dueAtMs, timeoutMs }
    turn: null, // { dueAtMs }
    recentEvents: [],
    pendingSetsLog: null, // { value: number }
    roundAdvance: null, // { roundIndex, ackedPlayerIds: Set<string> }
    roundGains: {}, // { [roundIndex]: { [playerId]: gained } }
    heberekeEnabled: false,
    heberekeLevels: {}, // { [playerId]: level }
    roomName: 'ルーム',
    maxPlayers: 4,
    isPublic: false,
  };
}

function pickNextHost(room, excludePlayerId = null) {
  const candidates = [...room.players.values()].filter(
    (p) => p.playerType === 'human' && p.connected && p.playerId !== excludePlayerId,
  );
  return candidates[0]?.playerId ?? null;
}

function transferHostIfNeeded(room, disconnectedPlayerId) {
  if (room.mode !== 'pvp') return;
  if (!room.hostPlayerId) return;
  if (room.hostPlayerId !== disconnectedPlayerId) return;

  const nextHostId = pickNextHost(room, disconnectedPlayerId);
  if (!nextHostId) {
    room.hostPlayerId = null;
    return;
  }

  room.hostPlayerId = nextHostId;
  recordEvent(room, {
    type: 'HOST_TRANSFERRED',
    at: nowIso(),
    roomId: room.roomId,
    actorPlayerId: disconnectedPlayerId,
    nextHostPlayerId: nextHostId,
  });
  const nextName = room.players.get(nextHostId)?.displayName ?? 'GUEST';
  pushChat(room, null, `ホストが ${nextName} に移りました`);
}

function ensureHostIfNeeded(room) {
  if (room.mode !== 'pvp') return;

  const currentHost = room.hostPlayerId ? room.players.get(room.hostPlayerId) : null;
  const hasValidHost = Boolean(currentHost && currentHost.playerType === 'human' && currentHost.connected);
  if (hasValidHost) return;

  room.hostPlayerId = pickNextHost(room);
}

function removePlayerAndTokens(room, playerId) {
  room.players.delete(playerId);
  for (const [token, pid] of room.reconnectTokenToPlayerId.entries()) {
    if (pid === playerId) room.reconnectTokenToPlayerId.delete(token);
  }
}

function cleanupPvpLobbyPlayers(room) {
  if (room.mode !== 'pvp') return;

  for (const p of [...room.players.values()]) {
    const shouldRemoveHuman = p.playerType === 'human' && !p.connected;
    const shouldRemoveBot = p.playerType === 'bot' && !p.connected;
    if (shouldRemoveHuman || shouldRemoveBot) {
      removePlayerAndTokens(room, p.playerId);
    }
  }

  // Reset ready for remaining humans so lobby controls are available.
  for (const p of room.players.values()) {
    if (p.playerType === 'human') p.ready = false;
  }

  ensureHostIfNeeded(room);
}

function scheduleSetsTotalLog(room) {
  if (room.timers.setsLog) clearTimeout(room.timers.setsLog);
  room.timers.setsLog = setTimeout(() => {
    room.timers.setsLog = null;
    if (room.mode !== 'pvp') return;
    const n = room.pendingSetsLog?.value;
    if (!Number.isInteger(n)) return;
    pushChat(room, null, `セット数変更: ${n}`);
  }, 1000);
}

function connectedHumans(room) {
  return [...room.players.values()].filter((p) => p.playerType === 'human' && p.connected);
}

function reconcileRoundAdvanceAfterRosterChange(room) {
  if (!room.roundAdvance) return;
  const required = connectedHumans(room);
  const requiredIds = new Set(required.map((p) => p.playerId));
  room.roundAdvance.ackedPlayerIds = new Set(
    [...room.roundAdvance.ackedPlayerIds].filter((id) => requiredIds.has(id))
  );
  const allAcked = required.every((p) => room.roundAdvance.ackedPlayerIds.has(p.playerId));
  if (allAcked) {
    if (room.timers.roundAdvance) {
      clearTimeout(room.timers.roundAdvance);
      room.timers.roundAdvance = null;
    }
    room.roundAdvance = null;
    emitRoomState(room);
    scheduleTurnTimeout(room);
    scheduleBotTurnIfNeeded(room);
    return;
  }
  emitRoomState(room);
}

function activePlayers(room) {
  // Players that should participate in PvP lobby/game: connected humans + bots.
  return [...room.players.values()].filter((p) => (p.playerType === 'human' ? p.connected : p.playerType === 'bot'));
}

function clampHeberekeLevel(value) {
  const v = Number(value);
  if (!Number.isFinite(v)) return 0;
  return Math.max(0, Math.min(5, Math.round(v)));
}

function initHeberekeLevels(room, playerIds) {
  if (!room) return;
  const ids = Array.isArray(playerIds) ? playerIds : [];
  const next = {};
  for (const id of ids) next[id] = 0;
  room.heberekeLevels = next;
}

function bumpHeberekeLevel(room, playerId, delta) {
  if (!room || !playerId || !delta) return;
  const current = clampHeberekeLevel(room.heberekeLevels?.[playerId] ?? 0);
  const next = clampHeberekeLevel(current + delta);
  if (!room.heberekeLevels) room.heberekeLevels = {};
  room.heberekeLevels[playerId] = next;
}

function updateHeberekeLevels(room, { winnerIds = [], dealerId = null } = {}) {
  if (!room?.heberekeEnabled || !room.game) return;

  const mode = room.game.config?.ruleMode ?? room.ruleMode ?? 'classic';
  const playerIds = Object.keys(room.game.scores ?? {});
  if (playerIds.length === 0) return;

  if (mode === 'classic' && dealerId) {
    const winners = Array.isArray(winnerIds) ? winnerIds : [];
    const dealerWonAny = winners.includes(dealerId);
    const dealerLostAny = winners.some((id) => id && id !== dealerId);

    if (dealerWonAny) bumpHeberekeLevel(room, dealerId, -1);
    else if (dealerLostAny) bumpHeberekeLevel(room, dealerId, 1);

    const childWinners = winners.filter((id) => id && id !== dealerId);
    if (childWinners.length === 0) return;

    for (const pid of playerIds) {
      if (pid === dealerId) continue;
      if (childWinners.includes(pid)) bumpHeberekeLevel(room, pid, -1);
      else bumpHeberekeLevel(room, pid, 1);
    }
    return;
  }

  const winners = Array.isArray(winnerIds) ? winnerIds : [];
  if (winners.length !== 1) return;
  const winnerId = winners[0];
  for (const pid of playerIds) {
    if (pid === winnerId) bumpHeberekeLevel(room, pid, -1);
    else bumpHeberekeLevel(room, pid, 1);
  }
}

function requiredBetPlayers(room) {
  if (!room) return [];
  return [...room.players.values()].filter((p) =>
    p.playerType === 'bot' || (p.playerType === 'human' && p.connected)
  );
}

function isBetMode(room) {
  const mode = room?.game?.config?.ruleMode ?? room?.ruleMode ?? 'classic';
  return mode === 'classic' || mode === 'takeall';
}

function areBetsComplete(room) {
  if (!room?.game || !isBetMode(room)) return true;
  const mode = room.game.config?.ruleMode;
  const dealerId = room.game.round?.dealerId ?? room.game.order?.[0] ?? null;
  const required =
    mode === 'classic'
      ? requiredBetPlayers(room).filter((p) => p.playerId !== dealerId)
      : requiredBetPlayers(room);
  if (required.length === 0) return true;
  const bets = room.game.round?.bets ?? {};
  return required.every((p) => Object.prototype.hasOwnProperty.call(bets, p.playerId));
}

function autoBetBotsIfNeeded(room) {
  if (!room?.game || !isBetMode(room)) return false;
  if (room.roundAdvance) return false;
  if (room.game.currentTurn?.lastDice) return false;
  const dealerId = room.game.round?.dealerId ?? room.game.order?.[0] ?? null;

  const roundIndex = room.game.roundIndex ?? 0;
  const roundsLeft = Math.max(0, (room.game.config?.roundsTotal ?? 1) - roundIndex - 1);
  const minBet = 10;
  const betOptions = [10, 20, 30, 50, 80, 100];

  const bets = room.game.round?.bets ?? {};
  let changed = false;
  for (const p of room.players.values()) {
    if (p.playerType !== 'bot') continue;
    if (room.game.config?.ruleMode === 'classic' && p.playerId === dealerId) continue;
    if (Object.prototype.hasOwnProperty.call(bets, p.playerId)) continue;
    const chips = Number(room.game.scores?.[p.playerId] ?? 0);
    const opponentScores = Object.entries(room.game.scores ?? {})
      .filter(([pid]) => pid !== p.playerId)
      .map(([, v]) => Number(v ?? 0));
    const bankrollOpponent = opponentScores.length ? Math.max(...opponentScores) : 0;
    const amount = chips >= minBet
      ? chooseBotBet({
          difficulty: p.botDifficulty ?? 'easy',
          bankrollCPU: chips,
          bankrollOpponent,
          roundsLeft,
          minBet,
          options: betOptions,
        })
      : 0;
    const result = applyBet(room.game, p.playerId, amount);
    if (result.ok) {
      const at = nowIso();
      const ev = {
        type: 'BET_PLACED',
        payload: {
          playerId: p.playerId,
          amount,
          roundIndex: room.game.roundIndex,
        },
      };
      recordEvent(room, { ...ev, at, roomId: room.roomId, actorPlayerId: p.playerId });
      io.to(room.roomId).emit('game:event', { ...ev, at });
      changed = true;
    }
  }
  return changed;
}

function deleteRoom(room) {
  // Clear all timers
  if (room.timers.turn) clearTimeout(room.timers.turn);
  if (room.timers.autoKeep) clearTimeout(room.timers.autoKeep);
  if (room.timers.bot) clearTimeout(room.timers.bot);
  if (room.timers.setsLog) clearTimeout(room.timers.setsLog);
  if (room.timers.roundAdvance) clearTimeout(room.timers.roundAdvance);
  if (room.timers.bet) clearTimeout(room.timers.bet);
  
  // Remove from maps
  roomsById.delete(room.roomId);
  roomsByCode.delete(room.inviteCode);
  
  console.log(`Room ${room.roomId} (${room.inviteCode}) deleted - no human players remaining`);
}

function checkAndDeleteEmptyRoom(room) {
  const humanPlayers = [...room.players.values()].filter(
    (p) => p.playerType === 'human' && p.connected
  );
  
  if (humanPlayers.length === 0) {
    deleteRoom(room);
    return true;
  }
  return false;
}

function snapshotGamePlayerNames(room) {
  if (!room.game || !room.game.scores) return;

  const names = {};
  for (const playerId of Object.keys(room.game.scores)) {
    const p = room.players.get(playerId);
    names[playerId] = p?.displayName ?? playerId;
  }
  room.game.playerNames = names;
}

function serializeRoom(room) {
  const players = [...room.players.values()].map((p) => ({
    playerId: p.playerId,
    displayName: p.displayName,
    playerType: p.playerType,
    botDifficulty: p.botDifficulty ?? null,
    ready: p.ready,
    connected: p.connected,
  }));

  return {
    roomId: room.roomId,
    inviteCode: room.inviteCode,
    mode: room.mode,
    // Keep server-side serialization consistent: default to 'classic'.
    ruleMode: room.ruleMode ?? 'classic',
    classicSetsTotal: room.classicSetsTotal ?? 3,
    status: room.status,
    hostPlayerId: room.hostPlayerId,
    createdAt: room.createdAt,
    roomName: room.roomName ?? 'ルーム',
    maxPlayers: room.maxPlayers ?? 4,
    isPublic: Boolean(room.isPublic),
    heberekeEnabled: Boolean(room.heberekeEnabled),
    heberekeLevels: room.heberekeLevels ?? {},
    players,
    chat: room.chat.slice(-50),
    recentEvents: room.recentEvents.slice(-50),
    roundAdvance: room.roundAdvance
      ? {
          roundIndex: room.roundAdvance.roundIndex,
          winnerIds: room.roundAdvance.winnerIds ?? [],
          ackedPlayerIds: [...room.roundAdvance.ackedPlayerIds],
          dueAt: room.roundAdvance.dueAtMs ? new Date(room.roundAdvance.dueAtMs).toISOString() : null,
          timeoutMs: room.roundAdvance.timeoutMs ?? null,
        }
      : null,
    autoKeep: room.autoKeep
      ? {
          playerId: room.autoKeep.playerId,
          dueAt: new Date(room.autoKeep.dueAtMs).toISOString(),
          timeoutMs: room.autoKeep.timeoutMs,
        }
      : null,
    turn: room.turn
      ? { dueAt: new Date(room.turn.dueAtMs).toISOString(), timeoutMs: TURN_TIMEOUT_MS }
      : null,
    game: room.game
      ? {
          status: room.game.status,
          config: room.game.config,
          roundIndex: room.game.roundIndex,
          scores: room.game.scores,
          playerNames: room.game.playerNames ?? null,
          round: room.game.round
            ? {
                dealerId: room.game.round.dealerId,
                bets: room.game.round.bets ?? {},
                potCarry: Number(room.game.round.potCarry ?? 0),
                potTotal:
                  Number(room.game.round.potCarry ?? 0) +
                  Object.values(room.game.round.bets ?? {}).reduce((sum, v) => sum + Number(v ?? 0), 0),
              }
            : null,
          currentTurn: {
            playerId: room.game.currentTurn.playerId,
            rerollsLeft: room.game.currentTurn.rerollsLeft,
            lastDice: room.game.currentTurn.lastDice,
            lastHand: room.game.currentTurn.lastHand,
          },
          seq: room.game.seq,
        }
      : null,
  };
}

function emitRoomState(room) {
  io.to(room.roomId).emit('room:state', { room: serializeRoom(room) });
}

function pushChat(room, playerId, text) {
  const msg = {
    messageId: randomId(),
    playerId,
    text,
    createdAt: nowIso(),
  };
  room.chat.push(msg);
  if (room.chat.length > 200) room.chat.splice(0, room.chat.length - 200);
  io.to(room.roomId).emit('chat:message', msg);
}

async function appendAudit(room, event) {
  // Minimal JSONL append.
  // Path: web/data/events/<roomId>/<gameSeq>.jsonl (game may be null in lobby)
  const dir = path.join(DATA_DIR, 'events', room.roomId);
  await import('node:fs/promises').then((m) => m.mkdir(dir, { recursive: true }));

  const fileName = room.game ? `${room.gameIdSafe ?? 'game'}.jsonl` : 'lobby.jsonl';
  const filePath = path.join(dir, fileName);
  const line = JSON.stringify(event) + '\n';
  await import('node:fs/promises').then((m) => m.appendFile(filePath, line, 'utf8'));
}

function recordEvent(room, event) {
  room.recentEvents.push(event);
  if (room.recentEvents.length > 200) room.recentEvents.splice(0, room.recentEvents.length - 200);
  appendAudit(room, event).catch((err) => console.error('audit append failed', err));
}

const SUPPRESSED_GAME_EVENT_TYPES = new Set(['TURN_STARTED', 'TURN_ENDED', 'ROUND_ENDED']);

function buildInitialRoundStartedEvent(room) {
  const ruleMode = room.game?.config?.ruleMode ?? room.ruleMode ?? 'score';
  if (ruleMode === 'classic') {
    const dealerId = room.game?.round?.dealerId ?? getCurrentPlayerId(room.game);
    return { seq: 0, type: 'ROUND_STARTED', payload: { roundIndex: 0, dealerId } };
  }

  return { seq: 0, type: 'ROUND_STARTED', payload: { roundIndex: 0 } };
}

function requireRoom(socket) {
  const roomId = socket.data.roomId;
  if (!roomId) return null;
  return roomsById.get(roomId) ?? null;
}

function errorToSocket(socket, message) {
  socket.emit('error:message', { message });
}

function scheduleTurnTimeout(room) {
  if (room.timers.turn) clearTimeout(room.timers.turn);
  if (!room.game || room.status !== 'in_game') {
    room.turn = null;
    return;
  }
  if (room.roundAdvance) {
    room.turn = null;
    emitRoomState(room);
    return;
  }

  room.turn = { dueAtMs: Date.now() + TURN_TIMEOUT_MS };
  emitRoomState(room);
  scheduleBetTimeout(room);

  const currentPlayerId = getCurrentPlayerId(room.game);
  room.timers.turn = setTimeout(() => {
    const player = room.players.get(currentPlayerId);
    if (!player) return;

    if (isBetMode(room) && !areBetsComplete(room)) {
      scheduleBetTimeout(room);
      scheduleTurnTimeout(room);
      return;
    }

    // Minimal auto-play:
    // - If not rolled yet: roll, then (if last reroll already) keep.
    // - If already rolled: reroll if possible, otherwise keep.
    if (!room.game.currentTurn.lastDice) {
      applyAndBroadcast(room, { type: 'ROLL', playerId: currentPlayerId });
      if (room.game && room.game.status === 'in_game' && room.game.currentTurn.playerId === currentPlayerId) {
        if (room.game.currentTurn.rerollsLeft <= 0 && room.game.currentTurn.lastDice) {
          applyAndBroadcast(room, { type: 'KEEP', playerId: currentPlayerId });
        }
      }
      return;
    }

    if (room.game.currentTurn.rerollsLeft > 0) {
      applyAndBroadcast(room, { type: 'REROLL', playerId: currentPlayerId });
      return;
    }

    applyAndBroadcast(room, { type: 'KEEP', playerId: currentPlayerId });
  }, TURN_TIMEOUT_MS);
}

function scheduleBetTimeout(room) {
  if (room.timers.bet) {
    clearTimeout(room.timers.bet);
    room.timers.bet = null;
  }

  if (!room?.game || !isBetMode(room)) return;
  if (room.roundAdvance) return;
  if (room.game.currentTurn?.lastDice) return;
  if (areBetsComplete(room)) return;

  room.timers.bet = setTimeout(() => {
    room.timers.bet = null;
    if (!room?.game || room.status !== 'in_game') return;
    if (room.game.currentTurn?.lastDice) return;
    if (areBetsComplete(room)) return;

    const dealerId = room.game.round?.dealerId ?? room.game.order?.[0] ?? null;
    const bets = room.game.round?.bets ?? {};
    let changed = false;
    for (const p of requiredBetPlayers(room)) {
      if (room.game.config?.ruleMode === 'classic' && p.playerId === dealerId) continue;
      if (Object.prototype.hasOwnProperty.call(bets, p.playerId)) continue;
      const result = applyBet(room.game, p.playerId, 10);
      if (result.ok) {
        const at = nowIso();
        const ev = {
          type: 'BET_PLACED',
          payload: {
            playerId: p.playerId,
            amount: 10,
            roundIndex: room.game.roundIndex,
          },
        };
        recordEvent(room, { ...ev, at, roomId: room.roomId, actorPlayerId: p.playerId });
        io.to(room.roomId).emit('game:event', { ...ev, at });
        changed = true;
      }
    }

    if (changed) emitRoomState(room);
    scheduleBotTurnIfNeeded(room);
  }, TURN_TIMEOUT_MS);
}

function scheduleRoundAdvanceTimeout(room) {
  if (room.timers.roundAdvance) {
    clearTimeout(room.timers.roundAdvance);
    room.timers.roundAdvance = null;
  }
  if (!room.roundAdvance || !room.game || room.status !== 'in_game') return;

  if (room.timers.bet) {
    clearTimeout(room.timers.bet);
    room.timers.bet = null;
  }

  room.roundAdvance.dueAtMs = Date.now() + ROUND_ADVANCE_TIMEOUT_MS;
  room.roundAdvance.timeoutMs = ROUND_ADVANCE_TIMEOUT_MS;
  emitRoomState(room);

  room.timers.roundAdvance = setTimeout(() => {
    room.timers.roundAdvance = null;
    if (!room.roundAdvance) return;
    if (room.timers.bet) {
      clearTimeout(room.timers.bet);
      room.timers.bet = null;
    }
    room.roundAdvance = null;
    emitRoomState(room);
    scheduleTurnTimeout(room);
    scheduleBotTurnIfNeeded(room);
  }, ROUND_ADVANCE_TIMEOUT_MS);
}

function cancelAutoKeep(room) {
  if (room.timers.autoKeep) clearTimeout(room.timers.autoKeep);
  room.timers.autoKeep = null;
  room.autoKeep = null;
}

function scheduleBotTurnIfNeeded(room) {
  if (room.timers.bot) {
    clearTimeout(room.timers.bot);
    room.timers.bot = null;
  }

  const didAutoBet = autoBetBotsIfNeeded(room);
  if (didAutoBet) {
    emitRoomState(room);
  }

  if (room.roundAdvance) return;

  const currentPlayerId = room.game?.status === 'in_game' ? getCurrentPlayerId(room.game) : null;
  if (!currentPlayerId) return;
  const currentPlayer = room.players.get(currentPlayerId);
  if (!currentPlayer || currentPlayer.playerType !== 'bot') return;

  if (room.autoKeep && room.autoKeep.playerId === currentPlayerId) return;

  const hasDice = Boolean(room.game.currentTurn.lastDice);
  const delay = hasDice ? 2000 : crypto.randomInt(250, 751);

  room.timers.bot = setTimeout(() => {
    room.timers.bot = null;
    if (!room.game || room.game.status !== 'in_game') return;
    if (getCurrentPlayerId(room.game) !== currentPlayerId) return;

    if (!room.game.currentTurn.lastDice) {
      if (isBetMode(room)) {
        const dealerId = room.game.round?.dealerId ?? room.game.order?.[0] ?? null;
        const isDealerTurn = dealerId && currentPlayerId === dealerId;
        if ((room.game.config?.ruleMode === 'classic' && isDealerTurn && !areBetsComplete(room)) ||
            (room.game.config?.ruleMode === 'takeall' && !areBetsComplete(room))) {
          return;
        }
      }
      applyAndBroadcast(room, { type: 'ROLL', playerId: currentPlayerId });
      return;
    }

    const hand = room.game.currentTurn.lastHand ?? evaluateHand(room.game.currentTurn.lastDice, room.game?.config?.ruleMode);
    const round = room.game.round ?? {};
    let takeallTopRank = null;
    if (room.game.config?.ruleMode === 'takeall') {
      const contenders = Array.isArray(round.takeallContenders) ? round.takeallContenders : [];
      const hands = round.takeallHands ?? {};
      let best = -Infinity;
      for (const pid of contenders) {
        const h = hands?.[pid];
        if (h && typeof h.rank === 'number') best = Math.max(best, h.rank);
      }
      if (best > -Infinity) takeallTopRank = best;
    }
    const action2 = decideBotAction({
      difficulty: currentPlayer.botDifficulty ?? 'easy',
      hand,
      rerollsLeft: room.game.currentTurn.rerollsLeft,
      situation: {
        roundIndex: room.game.roundIndex,
        roundsTotal: room.game.config.roundsTotal,
        myScore: room.game.scores[currentPlayerId] ?? 0,
        topScore: topScoreOf(room.game),
        mode: room.game.config?.ruleMode,
        takeallTopRank,
      },
    });

    if (action2 === 'reroll') {
      applyAndBroadcast(room, { type: 'REROLL', playerId: currentPlayerId });
      return;
    }

    applyAndBroadcast(room, { type: 'KEEP', playerId: currentPlayerId });
  }, delay);
}

function scheduleAutoKeep(room, playerId) {
  cancelAutoKeep(room);

  const dueAtMs = Date.now() + AUTO_KEEP_DELAY_MS;
  room.autoKeep = { playerId, dueAtMs, timeoutMs: AUTO_KEEP_DELAY_MS };

  room.timers.autoKeep = setTimeout(() => {
    if (!room.game || room.status !== 'in_game') return;
    if (getCurrentPlayerId(room.game) !== playerId) return;
    if (!room.game.currentTurn.lastDice) return;
    if (room.game.currentTurn.rerollsLeft > 0) return;

    cancelAutoKeep(room);
    applyAndBroadcast(room, { type: 'KEEP', playerId });
  }, AUTO_KEEP_DELAY_MS);

  emitRoomState(room);
}

function resetRoomToLobby(room, actorPlayerId) {
  if (room.timers.turn) clearTimeout(room.timers.turn);
  room.timers.turn = null;
  if (room.timers.bot) clearTimeout(room.timers.bot);
  room.timers.bot = null;
  if (room.timers.bet) clearTimeout(room.timers.bet);
  room.timers.bet = null;
  cancelAutoKeep(room);
  room.turn = null;
  room.roundAdvance = null;

  room.status = 'lobby';
  room.game = null;
  room.gameIdSafe = null;
  room.roundGains = {};
  room.heberekeLevels = {};

  for (const p of room.players.values()) {
    p.ready = false;
  }

  recordEvent(room, { type: 'RETURNED_TO_LOBBY', at: nowIso(), roomId: room.roomId, actorPlayerId });
  emitRoomState(room);
}

function topScoreOf(state) {
  return Math.max(...Object.values(state.scores));
}

function applyAndBroadcast(room, action) {
  if (!room.game) return;
  const debugDice = normalizeDebugDice(action?.debugDice);
  const rollDiceForAction = () => (debugDice ? [...debugDice] : rollDice3());
  const result = applyAction(room.game, action, rollDiceForAction);
  if (!result.ok) return result;

  cancelAutoKeep(room);

  for (const ev of result.events) {
    if (ev.type === 'TURN_ENDED') {
      const roundIndex = ev.payload?.roundIndex;
      const playerId = ev.payload?.playerId;
      const gained = ev.payload?.gained;
      if (Number.isInteger(roundIndex) && playerId) {
        if (!room.roundGains[roundIndex]) room.roundGains[roundIndex] = {};
        room.roundGains[roundIndex][playerId] = Number(gained ?? 0);
      }
    }
    if (SUPPRESSED_GAME_EVENT_TYPES.has(ev.type)) continue;
    const at = nowIso();
    recordEvent(room, { ...ev, at, roomId: room.roomId });
    io.to(room.roomId).emit('game:event', { ...ev, at });
  }

  if (room.game.status === 'finished') {
    snapshotGamePlayerNames(room);
    room.status = 'lobby';
    room.turn = null;

    cleanupPvpLobbyPlayers(room);
  }

  const roundEndedEvent = result.events.find((ev) => ev.type === 'ROUND_ENDED');
  if (roundEndedEvent && room.game.status === 'in_game') {
    const roundIndex = roundEndedEvent.payload?.roundIndex ?? room.game.roundIndex - 1;
    let winnerIds = [];
    let dealerId = null;
    if (room.game.config?.ruleMode === 'classic' || room.game.config?.ruleMode === 'takeall') {
      const roundResult = result.events.find((ev) => ev.type === 'ROUND_RESULT');
      winnerIds = roundResult?.payload?.winnerIds ?? [];
      dealerId = roundResult?.payload?.dealerId ?? null;
    } else {
      const gains = room.roundGains[roundIndex] ?? {};
      const entries = Object.entries(gains);
      if (entries.length) {
        let maxGained = -Infinity;
        for (const [, value] of entries) maxGained = Math.max(maxGained, Number(value));
        winnerIds = entries.filter(([, value]) => Number(value) === maxGained).map(([pid]) => pid);
      }
    }
    updateHeberekeLevels(room, { winnerIds, dealerId });
    const ackedPlayerIds = new Set();
    // Bots auto-ack immediately
    room.roundAdvance = { roundIndex, winnerIds, ackedPlayerIds };
    scheduleRoundAdvanceTimeout(room);
    io.to(room.roomId).emit('round:result', {
      roundIndex,
      winnerIds,
    });
    if (room.timers.turn) clearTimeout(room.timers.turn);
    room.timers.turn = null;
    if (room.timers.bot) clearTimeout(room.timers.bot);
    room.timers.bot = null;
    cancelAutoKeep(room);
  }

  emitRoomState(room);
  if (!room.roundAdvance) scheduleTurnTimeout(room);

  // UX: after the final reroll, players can only keep; delay auto-keep slightly.
  if (action.type === 'REROLL' && room.status === 'in_game') {
    const currentPlayerId = getCurrentPlayerId(room.game);
    const currentPlayer = room.players.get(currentPlayerId);
    if (
      currentPlayerId === action.playerId &&
      currentPlayer?.playerType === 'human' &&
      room.game.currentTurn.rerollsLeft <= 0 &&
      room.game.currentTurn.lastDice
    ) {
      scheduleAutoKeep(room, currentPlayerId);
      return result;
    }
  }

  scheduleBotTurnIfNeeded(room);
  return result;
}

io.on('connection', (socket) => {
  socket.data.roomId = null;
  socket.data.playerId = null;
  socket.data.debugDicePending = null;

  socket.on('rooms:list', () => {
    const roomsList = [];
    for (const room of roomsById.values()) {
      if (room.status === 'lobby' && room.isPublic) {
        const activeCount = activePlayers(room).length;
        roomsList.push({
          roomId: room.roomId,
          inviteCode: room.inviteCode,
          ruleMode: room.ruleMode,
          playerCount: activeCount,
          maxPlayers: room.maxPlayers,
          hostName: room.players.get(room.hostPlayerId)?.displayName || 'Unknown',
          roomName: room.roomName,
        });
      }
    }
    socket.emit('rooms:list', { rooms: roomsList });
  });

  socket.on('room:create', ({ displayName, ruleMode, classicSetsTotal } = {}) => {
    const safeName = String(displayName ?? '').trim().slice(0, 20);
    if (!safeName) return errorToSocket(socket, '名前を入力してください');

    const room = makeRoom('pvp');

    const safeRuleMode = normalizeRuleMode(ruleMode);
    assertEnabledRuleMode(safeRuleMode);
    room.ruleMode = safeRuleMode;

    if (classicSetsTotal !== undefined) {
      const n = Number(classicSetsTotal);
      if (Number.isInteger(n) && n >= 1 && n <= 20) room.classicSetsTotal = n;
    }

    const hostPlayerId = randomId();
    const reconnectToken = randomToken();

    room.hostPlayerId = hostPlayerId;
    room.players.set(hostPlayerId, {
      playerId: hostPlayerId,
      displayName: safeName,
      playerType: 'human',
      ready: false,
      connected: true,
    });
    room.reconnectTokenToPlayerId.set(reconnectToken, hostPlayerId);

    roomsById.set(room.roomId, room);
    roomsByCode.set(room.inviteCode, room.roomId);

    socket.data.roomId = room.roomId;
    socket.data.playerId = hostPlayerId;
    socket.join(room.roomId);

    recordEvent(room, { type: 'ROOM_CREATED', at: nowIso(), roomId: room.roomId, actorPlayerId: hostPlayerId });
    emitRoomState(room);

    socket.emit('room:created', {
      roomId: room.roomId,
      inviteCode: room.inviteCode,
      playerId: hostPlayerId,
      reconnectToken,
    });

  });

  socket.on('room:join', ({ inviteCode, displayName } = {}) => {
    const code = String(inviteCode ?? '').trim().toUpperCase();
    const safeName = String(displayName ?? '').trim().slice(0, 20);
    if (!code) return errorToSocket(socket, '招待コードを入力してください');
    if (!safeName) return errorToSocket(socket, '名前を入力してください');

    const roomId = roomsByCode.get(code);
    if (!roomId) return errorToSocket(socket, '招待コードが見つかりません');
    const room = roomsById.get(roomId);
    if (!room) return errorToSocket(socket, 'ルームが見つかりません');
    if (room.status !== 'lobby') return errorToSocket(socket, '開始済みのルームです');

    const maxPlayers = room.maxPlayers ?? 4;
    if (activePlayers(room).length >= maxPlayers) return errorToSocket(socket, '満員です');

    const playerId = randomId();
    const reconnectToken = randomToken();

    room.players.set(playerId, {
      playerId,
      displayName: safeName,
      playerType: 'human',
      ready: false,
      connected: true,
    });
    room.reconnectTokenToPlayerId.set(reconnectToken, playerId);

    socket.data.roomId = room.roomId;
    socket.data.playerId = playerId;
    socket.join(room.roomId);

    recordEvent(room, { type: 'PLAYER_JOINED', at: nowIso(), roomId: room.roomId, actorPlayerId: playerId });
    if (room.mode === 'pvp') {
      const display = room.players.get(playerId)?.displayName ?? 'GUEST';
      pushChat(room, null, `${display} が入室しました`);
    }

    ensureHostIfNeeded(room);
    emitRoomState(room);

    socket.emit('room:joined', { roomId: room.roomId, playerId, reconnectToken });
  });

  socket.on('room:add_bot', ({ botDifficulty } = {}) => {
    const room = requireRoom(socket);
    if (!room) return;
    if (room.mode !== 'pvp') return;
    if (room.status !== 'lobby') return;

    const actorPlayerId = socket.data.playerId;
    if (actorPlayerId !== room.hostPlayerId) return errorToSocket(socket, 'ホストのみ操作できます');

    const actor = room.players.get(actorPlayerId);
    if (actor?.ready) return errorToSocket(socket, '準備完了を解除してください');

    const maxPlayers = room.maxPlayers ?? 4;
    if (activePlayers(room).length >= maxPlayers) return errorToSocket(socket, '満員です');

    const diff = botDifficulty === 'hard' ? 'hard' : botDifficulty === 'easy' ? 'easy' : 'normal';

    let nextBotNumber = Number(room.nextBotNumber ?? 1);
    if (!Number.isInteger(nextBotNumber) || nextBotNumber < 1) nextBotNumber = 1;
    if (nextBotNumber === 1) {
      const maxExisting = Math.max(
        0,
        ...[...room.players.values()]
          .filter((p) => p.playerType === 'bot')
          .map((p) => {
            const m = /^CPU(\d+)$/.exec(String(p.displayName ?? ''));
            return m ? Number(m[1]) : 0;
          }),
      );
      if (maxExisting >= 1) nextBotNumber = maxExisting + 1;
    }

    const botIndex = nextBotNumber;
    room.nextBotNumber = botIndex + 1;
    const botPlayerId = randomId();
    room.players.set(botPlayerId, {
      playerId: botPlayerId,
      displayName: `CPU${botIndex}`,
      playerType: 'bot',
      botDifficulty: diff,
      ready: true,
      connected: true,
    });

    recordEvent(room, { type: 'BOT_ADDED', at: nowIso(), roomId: room.roomId, actorPlayerId, botPlayerId, botDifficulty: diff });
    pushChat(room, null, `CPUを追加しました（${diff}）`);
    emitRoomState(room);
  });

  socket.on('room:remove_bot', ({ botPlayerId } = {}) => {
    const room = requireRoom(socket);
    if (!room) return;
    if (room.mode !== 'pvp') return;
    if (room.status !== 'lobby') return;

    const actorPlayerId = socket.data.playerId;
    if (actorPlayerId !== room.hostPlayerId) return errorToSocket(socket, 'ホストのみ操作できます');

    const actor = room.players.get(actorPlayerId);
    if (actor?.ready) return errorToSocket(socket, '準備完了を解除してください');

    const targetId = String(botPlayerId ?? '').trim();
    const target = room.players.get(targetId);
    if (!target) return;
    if (target.playerType !== 'bot') return;

    room.players.delete(targetId);
    recordEvent(room, { type: 'BOT_REMOVED', at: nowIso(), roomId: room.roomId, actorPlayerId, botPlayerId: targetId });
    pushChat(room, null, `CPUを削除しました`);
    emitRoomState(room);
  });

  socket.on('room:cycle_bot_difficulty', ({ botPlayerId } = {}) => {
    const room = requireRoom(socket);
    if (!room) return;
    if (room.mode !== 'pvp') return;
    if (room.status !== 'lobby') return;

    const actorPlayerId = socket.data.playerId;
    if (actorPlayerId !== room.hostPlayerId) return errorToSocket(socket, 'ホストのみ操作できます');

    const actor = room.players.get(actorPlayerId);
    if (actor?.ready) return errorToSocket(socket, '準備完了を解除してください');

    const targetId = String(botPlayerId ?? '').trim();
    const target = room.players.get(targetId);
    if (!target) return;
    if (target.playerType !== 'bot') return;

    const current = target.botDifficulty === 'easy' ? 'easy' : target.botDifficulty === 'hard' ? 'hard' : 'normal';
    const next = current === 'easy' ? 'normal' : current === 'normal' ? 'hard' : 'easy';
    target.botDifficulty = next;

    recordEvent(room, {
      type: 'BOT_DIFFICULTY_CYCLED',
      at: nowIso(),
      roomId: room.roomId,
      actorPlayerId,
      botPlayerId: targetId,
      from: current,
      to: next,
    });
    pushChat(room, null, `${target.displayName} の難易度を変更しました（${current} → ${next}）`);
    emitRoomState(room);
  });

  socket.on('room:ready', ({ ready } = {}) => {
    const room = requireRoom(socket);
    if (!room) return;
    const playerId = socket.data.playerId;
    const player = room.players.get(playerId);
    if (!player) return;

    player.ready = Boolean(ready);
    recordEvent(room, { type: 'READY_SET', at: nowIso(), roomId: room.roomId, actorPlayerId: playerId, ready: player.ready });
    emitRoomState(room);
  });

  socket.on('room:set_rule_mode', ({ ruleMode } = {}) => {
    const room = requireRoom(socket);
    if (!room) return;
    if (room.status !== 'lobby') return;

    const actorPlayerId = socket.data.playerId;
    if (actorPlayerId !== room.hostPlayerId) return errorToSocket(socket, 'ホストのみ変更できます');

    const actor = room.players.get(actorPlayerId);
    if (actor?.ready) return errorToSocket(socket, '準備完了を解除してください');
    const nextRuleMode = normalizeRuleMode(ruleMode);
    assertEnabledRuleMode(nextRuleMode);
    if (room.ruleMode === nextRuleMode) return;
    room.ruleMode = nextRuleMode;

    recordEvent(room, { type: 'RULE_MODE_SET', at: nowIso(), roomId: room.roomId, actorPlayerId, ruleMode: nextRuleMode });
    if (room.mode === 'pvp') pushChat(room, null, `モード変更: ${nextRuleMode}`);
    emitRoomState(room);
  });

  socket.on('room:set_hebereke', ({ enabled } = {}) => {
    const room = requireRoom(socket);
    if (!room) return;
    if (room.status !== 'lobby') return;

    const actorPlayerId = socket.data.playerId;
    if (actorPlayerId !== room.hostPlayerId) return errorToSocket(socket, 'ホストのみ操作できます');

    const actor = room.players.get(actorPlayerId);
    if (actor?.ready) return errorToSocket(socket, '準備解除してから変更してください');

    const nextEnabled = Boolean(enabled);
    if (room.heberekeEnabled === nextEnabled) return;
    room.heberekeEnabled = nextEnabled;
    recordEvent(room, { type: 'HEBEREKE_SET', at: nowIso(), roomId: room.roomId, actorPlayerId, enabled: nextEnabled });
    if (room.mode === 'pvp') pushChat(room, null, `へべれけモード: ${nextEnabled ? 'ON' : 'OFF'}`);
    emitRoomState(room);
  });

  socket.on('room:set_classic_sets_total', ({ setsTotal } = {}) => {
    const room = requireRoom(socket);
    if (!room) return;
    if (room.status !== 'lobby') return;

    const actorPlayerId = socket.data.playerId;
    if (actorPlayerId !== room.hostPlayerId) return errorToSocket(socket, 'ホストのみ変更できます');

    const actor = room.players.get(actorPlayerId);
    if (actor?.ready) return errorToSocket(socket, '準備完了を解除してください');

    const n = Number(setsTotal);
    if (!Number.isInteger(n) || n < 1 || n > 20) return errorToSocket(socket, 'セット数は1〜20で指定してください');
    if (room.classicSetsTotal === n) return;

    room.classicSetsTotal = n;
    recordEvent(room, { type: 'CLASSIC_SETS_TOTAL_SET', at: nowIso(), roomId: room.roomId, actorPlayerId, setsTotal: n });
    if (room.mode === 'pvp') {
      room.pendingSetsLog = { value: n };
      scheduleSetsTotalLog(room);
    }
    emitRoomState(room);
  });

  socket.on('room:set_name', ({ roomName } = {}) => {
    const room = requireRoom(socket);
    if (!room) return;
    if (room.status !== 'lobby') return;

    const actorPlayerId = socket.data.playerId;
    if (actorPlayerId !== room.hostPlayerId) return errorToSocket(socket, 'ホストのみ変更できます');

    const actor = room.players.get(actorPlayerId);
    if (actor?.ready) return errorToSocket(socket, '準備完了を解除してください');

    const safeName = String(roomName ?? '').trim().slice(0, 30);
    if (!safeName) return errorToSocket(socket, 'ルーム名を入力してください');
    if (room.roomName === safeName) return;

    room.roomName = safeName;
    recordEvent(room, { type: 'ROOM_NAME_SET', at: nowIso(), roomId: room.roomId, actorPlayerId, roomName: safeName });
    if (room.mode === 'pvp') pushChat(room, null, `ルーム名変更: ${safeName}`);
    emitRoomState(room);
  });

  socket.on('room:set_max_players', ({ maxPlayers } = {}) => {
    const room = requireRoom(socket);
    if (!room) return;
    if (room.status !== 'lobby') return;

    const actorPlayerId = socket.data.playerId;
    if (actorPlayerId !== room.hostPlayerId) return errorToSocket(socket, 'ホストのみ変更できます');

    const actor = room.players.get(actorPlayerId);
    if (actor?.ready) return errorToSocket(socket, '準備完了を解除してください');

    const n = Number(maxPlayers);
    if (!Number.isInteger(n) || n < 2 || n > 6) return errorToSocket(socket, '最大人数は2〜6で指定してください');
    if (room.maxPlayers === n) return;

    const currentPlayerCount = activePlayers(room).length;
    if (currentPlayerCount > n) return errorToSocket(socket, `現在${currentPlayerCount}人が参加しているため、${n}人以下に減らせません`);

    room.maxPlayers = n;
    recordEvent(room, { type: 'MAX_PLAYERS_SET', at: nowIso(), roomId: room.roomId, actorPlayerId, maxPlayers: n });
    if (room.mode === 'pvp') pushChat(room, null, `最大人数変更: ${n}人`);
    emitRoomState(room);
  });

  socket.on('room:set_is_public', ({ isPublic } = {}) => {
    const room = requireRoom(socket);
    if (!room) return;
    if (room.status !== 'lobby') return;

    const actorPlayerId = socket.data.playerId;
    if (actorPlayerId !== room.hostPlayerId) return errorToSocket(socket, 'ホストのみ変更できます');

    const actor = room.players.get(actorPlayerId);
    if (actor?.ready) return errorToSocket(socket, '準備完了を解除してください');

    const nextIsPublic = Boolean(isPublic);
    if (room.isPublic === nextIsPublic) return;

    room.isPublic = nextIsPublic;
    recordEvent(room, { type: 'IS_PUBLIC_SET', at: nowIso(), roomId: room.roomId, actorPlayerId, isPublic: nextIsPublic });
    if (room.mode === 'pvp') pushChat(room, null, `公開設定: ${nextIsPublic ? 'ON' : 'OFF'}`);
    emitRoomState(room);
  });

  socket.on('room:transfer_host', ({ nextHostPlayerId } = {}) => {
    const room = requireRoom(socket);
    if (!room) return;
    if (room.mode !== 'pvp') return;
    if (room.status !== 'lobby') return;

    const actorPlayerId = socket.data.playerId;
    if (actorPlayerId !== room.hostPlayerId) return errorToSocket(socket, 'ホストのみ操作できます');

    const actor = room.players.get(actorPlayerId);
    if (actor?.ready) return errorToSocket(socket, '準備完了を解除してください');

    const nextId = String(nextHostPlayerId ?? '').trim();
    if (!nextId) return;
    if (nextId === actorPlayerId) return;

    const next = room.players.get(nextId);
    if (!next || next.playerType !== 'human' || !next.connected) return errorToSocket(socket, '委任先が無効です');

    room.hostPlayerId = nextId;
    recordEvent(room, {
      type: 'HOST_TRANSFERRED',
      at: nowIso(),
      roomId: room.roomId,
      actorPlayerId,
      nextHostPlayerId: nextId,
    });
    const nextName = next.displayName ?? 'GUEST';
    pushChat(room, null, `ホストが ${nextName} に移りました`);
    emitRoomState(room);
  });

  socket.on('game:start', () => {
    const room = requireRoom(socket);
    if (!room) return;
    if (room.status !== 'lobby') return;

    const playerId = socket.data.playerId;
    if (playerId !== room.hostPlayerId) return errorToSocket(socket, 'ホストのみ開始できます');

    const humans = connectedHumans(room);
    const participants = activePlayers(room);
    if (participants.length < 2) return errorToSocket(socket, '2人以上必要です');
    if (!humans.every((p) => p.ready)) return errorToSocket(socket, '全員の準備完了が必要です');

    // Start a new game (keep prior events for log continuity).
    room.status = 'in_game';
    room.gameIdSafe = `game-${Date.now()}`;
    room.game = createInitialGameState(participants.map((p) => p.playerId), {
      ruleMode: room.ruleMode,
      setsTotal: room.classicSetsTotal,
    });
    initHeberekeLevels(room, participants.map((p) => p.playerId));
    room.roundAdvance = null;
    room.roundGains = {};

    recordEvent(room, { type: 'GAME_STARTED', at: nowIso(), roomId: room.roomId, actorPlayerId: playerId });

    const at = nowIso();
    const ev = buildInitialRoundStartedEvent(room);
    recordEvent(room, { ...ev, at, roomId: room.roomId });
    io.to(room.roomId).emit('game:event', { ...ev, at });

    emitRoomState(room);
    scheduleTurnTimeout(room);
    scheduleBotTurnIfNeeded(room);
  });

  socket.on('room:return_to_lobby', () => {
    const room = requireRoom(socket);
    if (!room) return;
    if (room.mode !== 'pvp') return;
    if (socket.data.playerId !== room.hostPlayerId) return errorToSocket(socket, 'ホストのみ操作できます');
    if (room.status !== 'lobby') return;
    if (!room.game || room.game.status !== 'finished') return;

    resetRoomToLobby(room, socket.data.playerId);
  });

  socket.on('debug:set_dice', (payload) => {
    const dice = normalizeDebugDice(payload?.debugDice ?? payload);
    if (!dice) return;
    socket.data.debugDicePending = dice;
  });

  socket.on('debug:set_hebereke', (payload) => {
    const room = requireRoom(socket);
    if (!room) return;
    const playerId = socket.data.playerId;
    if (!playerId) return;
    const level = normalizeDebugHebereke(payload?.level ?? payload);
    if (level === null) return;
    if (!room.heberekeLevels) room.heberekeLevels = {};
    room.heberekeLevels[playerId] = level;
    emitRoomState(room);
  });

  socket.on('turn:roll', (payload) => {
    const payloadDice = normalizeDebugDice(payload?.debugDice);
    const debugDice = payloadDice ?? normalizeDebugDice(socket.data.debugDicePending);
    const room = requireRoom(socket);
    if (!room || !room.game) return;
    if (room.roundAdvance) return;
    if (isBetMode(room)) {
      const dealerId = room.game.round?.dealerId ?? room.game.order?.[0] ?? null;
      const isDealerTurn = dealerId && room.game.currentTurn?.playerId === dealerId;
      const needsBlock =
        (room.game.config?.ruleMode === 'classic' && isDealerTurn && !areBetsComplete(room)) ||
        (room.game.config?.ruleMode === 'takeall' && !areBetsComplete(room));
      if (needsBlock) {
        return errorToSocket(socket, 'bets_not_complete');
      }
    }
    const result = applyAndBroadcast(room, { type: 'ROLL', playerId: socket.data.playerId, debugDice });
    if (debugDice && result?.ok) socket.data.debugDicePending = null;
  });

  socket.on('turn:reroll', (payload) => {
    const payloadDice = normalizeDebugDice(payload?.debugDice);
    const debugDice = payloadDice ?? normalizeDebugDice(socket.data.debugDicePending);
    const room = requireRoom(socket);
    if (!room || !room.game) return;
    if (room.roundAdvance) return;
    const result = applyAndBroadcast(room, { type: 'REROLL', playerId: socket.data.playerId, debugDice });
    if (debugDice && result?.ok) socket.data.debugDicePending = null;
  });

  socket.on('turn:keep', (payload) => {
    const room = requireRoom(socket);
    if (!room || !room.game) return;
    if (room.roundAdvance) return;

    if (room.autoKeep && room.autoKeep.playerId === socket.data.playerId && Date.now() < room.autoKeep.dueAtMs) {
      return;
    }

    const heberekeForceKeep = Boolean(payload?.heberekeForceKeep);
    applyAndBroadcast(room, { type: 'KEEP', playerId: socket.data.playerId, heberekeForceKeep });
  });

  socket.on('round:bet', ({ amount } = {}) => {
    const room = requireRoom(socket);
    if (!room || !room.game) return;
    if (room.roundAdvance) return;

    const playerId = socket.data.playerId;
    if (!isBetMode(room)) {
      return errorToSocket(socket, 'ベットできません');
    }
    if (room.game.currentTurn?.lastDice) {
      return errorToSocket(socket, 'ベットできません');
    }
    const result = applyBet(room.game, playerId, amount);
    if (!result.ok) {
      return errorToSocket(socket, 'ベットできません');
    }

    {
      const at = nowIso();
      const ev = {
        type: 'BET_PLACED',
        payload: {
          playerId,
          amount: Number(amount ?? 0),
          roundIndex: room.game.roundIndex,
        },
      };
      recordEvent(room, { ...ev, at, roomId: room.roomId, actorPlayerId: playerId });
      io.to(room.roomId).emit('game:event', { ...ev, at });
    }

    emitRoomState(room);
    scheduleBetTimeout(room);
    scheduleBotTurnIfNeeded(room);
  });

  socket.on('round:ack', () => {
    console.log('[round:ack] EVENT RECEIVED');
    const room = requireRoom(socket);
    if (!room || !room.roundAdvance) {
      console.log('[round:ack] skipped - no room or no roundAdvance', {
        hasRoom: !!room,
        hasRoundAdvance: !!room?.roundAdvance,
      });
      return;
    }

    const playerId = socket.data.playerId;
    if (!playerId) {
      console.log('[round:ack] skipped - no playerId');
      return;
    }

    const required = connectedHumans(room);
    if (!required.find((p) => p.playerId === playerId)) {
      console.log('[round:ack] skipped - player not in required list', {
        playerId,
        requiredIds: required.map(p => p.playerId),
      });
      return;
    }

    console.log('[round:ack] received from', playerId, 'roundAdvance before:', {
      ackedCount: room.roundAdvance.ackedPlayerIds.size,
      requiredCount: required.length,
    });

    room.roundAdvance.ackedPlayerIds.add(playerId);

    const allAcked = required.every((p) => room.roundAdvance.ackedPlayerIds.has(p.playerId));
    console.log('[round:ack] ackedPlayerIds size now:', room.roundAdvance.ackedPlayerIds.size, 'allAcked:', allAcked);
    
    if (allAcked) {
      console.log('[round:ack] all players acked - clearing roundAdvance and resuming game');
      if (room.timers.roundAdvance) {
        clearTimeout(room.timers.roundAdvance);
        room.timers.roundAdvance = null;
      }
      room.roundAdvance = null;
      emitRoomState(room);
      scheduleTurnTimeout(room);
      scheduleBotTurnIfNeeded(room);
      return;
    }

    emitRoomState(room);
  });

  socket.on('chat:send', ({ text } = {}) => {
    const room = requireRoom(socket);
    if (!room) return;
    if (room.mode !== 'pvp') return;

    const msg = String(text ?? '').trim();
    if (!msg) return;
    if (msg.length > 200) return errorToSocket(socket, 'メッセージが長すぎます');

    pushChat(room, socket.data.playerId, msg);
  });

  socket.on('reconnect', ({ roomId, reconnectToken } = {}) => {
    const rId = String(roomId ?? '').trim();
    const token = String(reconnectToken ?? '').trim();
    const room = roomsById.get(rId);
    if (!room) return errorToSocket(socket, 'ルームが見つかりません');

    const playerId = room.reconnectTokenToPlayerId.get(token);
    if (!playerId) return errorToSocket(socket, '再接続に失敗しました');

    const player = room.players.get(playerId);
    if (!player) return errorToSocket(socket, '再接続に失敗しました');

    socket.data.roomId = room.roomId;
    socket.data.playerId = playerId;
    socket.join(room.roomId);

    player.connected = true;
    if (
      room.mode === 'pvp' &&
      room.status === 'in_game' &&
      player.playerType === 'bot' &&
      typeof player.displayName === 'string' &&
      player.displayName.endsWith('(CPU)')
    ) {
      player.playerType = 'human';
      player.displayName = player.displayName.slice(0, -'(CPU)'.length);
    }
    recordEvent(room, { type: 'RECONNECTED', at: nowIso(), roomId: room.roomId, actorPlayerId: playerId });
    if (room.mode === 'pvp') {
      const display = room.players.get(playerId)?.displayName ?? 'GUEST';
      pushChat(room, null, `${display} が再接続しました`);
    }

    ensureHostIfNeeded(room);
    emitRoomState(room);
    socket.emit('room:reconnected', {
      roomId: room.roomId,
      playerId,
      reconnectToken: token,
    });
  });

  socket.on('disconnect', () => {
    const room = requireRoom(socket);
    if (!room) return;
    const playerId = socket.data.playerId;
    const player = room.players.get(playerId);
    if (!player) return;

    const wasHuman = player.playerType === 'human';
    const displayBefore = player.displayName ?? 'GUEST';

    player.connected = false;
    recordEvent(room, { type: 'DISCONNECTED', at: nowIso(), roomId: room.roomId, actorPlayerId: playerId });

    if (room.mode === 'pvp' && room.status === 'in_game' && wasHuman) {
      if (typeof player.displayName === 'string' && !player.displayName.endsWith('(CPU)')) {
        player.displayName = `${player.displayName}(CPU)`;
      }
      player.playerType = 'bot';
      player.botDifficulty = player.botDifficulty ?? 'normal';
      pushChat(room, null, `${displayBefore} が退出しました（CPUが代行します）`);
      scheduleBotTurnIfNeeded(room);
    } else if (room.mode === 'pvp') {
      pushChat(room, null, `${displayBefore} が退出しました`);
    }

    if (room.mode === 'pvp' && room.status === 'in_game') {
      reconcileRoundAdvanceAfterRosterChange(room);
    }

    transferHostIfNeeded(room, playerId);
    
    // Check if room should be deleted (no human players left)
    if (checkAndDeleteEmptyRoom(room)) {
      return; // Room was deleted, don't emit state
    }
    
    emitRoomState(room);
  });
});

server.listen(PORT, () => {
  console.log(`Web server listening on http://localhost:${PORT}`);
  console.log(`Data dir: ${DATA_DIR}`);
});

const socket = window.io();

const $ = (id) => document.getElementById(id);

const STORAGE_KEYS = {
  guestName: 'guestName',
  roomId: 'roomId',
  reconnectToken: 'reconnectToken',
};

const screens = {
  top: $('screen-top'),
  lobby: $('screen-lobby'),
  match: $('screen-match'),
  result: $('screen-result'),
};

const state = {
  room: null,
  playerId: null,
  reconnectToken: null,
  lastRoomStatus: null,
  lastGameStatus: null,
  pvpShowResult: null, // null (auto) | true (show result) | false (show lobby)
  unifiedPanelTab: 'log', // 'chat' | 'log'
  turnTimerRaf: null,
  diceAnimQueue: [],
  roundAdvanceHold: null,
  roundAdvanceHoldAcked: false,
  pendingRoundResult: null,
  lastRoundResultSeq: null,
  lastRollResolvedSeq: null,
  cachedRoundRolls: new Map(),
  cachedRoundRollsRoundIndex: null,
  cachedRoundContext: { currentPlayerId: null, dealerId: null },
  betDraft: 0,
  betDraftRoundIndex: null,
  debugDicePending: null,
  debugHeberekeLevel: null,
  debugHoldDiceModal: false,
  heberekeMasks: new Map(), // rollSeq -> [bool,bool,bool]
  heberekeMaskFallback: new Map(), // fallbackKey -> [bool,bool,bool] | null
  cachedMatchStatus: {
    roundLabel: '--',
    setLabel: '',
    showSet: false,
    turnLabel: '--',
    rerollsLabel: '--',
  },
  pendingRoundStartEvents: [],
  lastRoundAdvanceActive: false,
  deferRoundStartedLogs: false,
  audio: {
    unlocked: false,
    ctx: null,
    rollEl: null,
  },
};

const TURN_TIMER = {
  circumference: 2 * Math.PI * 18,
};

const DICE_ANIM = {
  minShowMs: 650,
  maxShowMs: 1100,
  postSettleCloseMs: 920,
};

const UI_FLAGS = {
  diceModalModeDefault: '3d', // '2d' | '3d'
};

const I18N = {
  storageKey: 'lang',
  defaultLang: 'ja',
  current: 'ja',
  strings: {
    en: {
      'app.title': 'OCHIN-CHIRO(β)',
      'app.tagline': 'A casual place to play Chinchiro',
      'lang.label': 'Language',
      'lang.ja': 'Japanese',
      'lang.en': 'English',
      'top.guestLabel': 'Guest name',
      'top.guestPlaceholder': 'e.g. Taro',
      'top.roomTitle': 'Room',
      'top.create': 'Create',
      'top.join': 'Join',
      'top.invitePlaceholder': 'Invite code',
      'top.howto.title': 'How to Play',
      'top.howto.rule': 'Rules: Classic / Score',
      'top.howto.hand': 'Hands: Pinzoro / Triples / 4-5-6 / Pair + Kicker / No hand / 1-2-3',
      'top.howto.steps': 'On your turn: Roll → up to 3 rerolls → Confirm',
      'lobby.title': 'Lobby',
      'lobby.participants': 'Players',
      'lobby.addCpu': 'Add CPU',
      'lobby.settings': 'Settings',
      'lobby.inviteLabel': 'Invite code',
      'lobby.copyInviteAria': 'Copy invite code',
      'lobby.roomName': 'Room name',
      'lobby.maxPlayers': 'Max players',
      'lobby.public': 'Public settings',
      'lobby.publicLabel': 'Show in room list',
      'lobby.mode': 'Mode',
      'lobby.mode.classic': 'Classic',
      'lobby.mode.score': 'Score',
      'lobby.mode.takeall': 'Take-all',
      'lobby.mode.helpHtml': '<strong>Classic</strong><br>Chip pool rules. Win to take chips.<br><strong>Score</strong><br>Compete by total score across rounds.<br><strong>Take-all</strong><br>Everyone bets; the strongest hand takes the pot.',
      'lobby.sets': 'Sets',
      'lobby.setsHelp': '1 set = repeat rounds until the dealer completes one rotation',
      'lobby.hebereke': 'Hebereke',
      'lobby.heberekeLabel': 'Hebereke mode',
      'lobby.hostOnlyNote': '*Only the host can change these',
      'lobby.ready': 'Ready',
      'lobby.start': 'Start (Host)',
      'match.title': 'Match',
      'match.round': 'Round',
      'match.set': 'Set',
      'match.roll': 'Roll',
      'match.reroll': 'Reroll',
      'match.keep': 'Confirm',
      'match.nextRound': 'Next round',
      'match.waiting': 'Waiting...',
      'match.timeLeft': 'Time left',
      'match.pot': 'Pot',
      'match.total': 'Total: {total} chips',
      'match.bet': 'Bet',
      'match.confirm': 'Confirm',
      'match.players': 'Players',
      'result.title': 'Result',
      'result.back': 'Back to top',
      'chat.aria': 'Chat and log',
      'chat.log': 'Log',
      'chat.chat': 'Chat',
      'chat.placeholder': 'Message',
      'chat.send': 'Send',
      'chat.leave': 'Leave',
      'dice.modalAria': 'Dice animation',
      'dice.title': 'Dice',
      'dice.stageAria': 'Rolling dice',
      'dice.skip': 'Click to skip',
      'hand.label': 'Hand',
      'dice.rollTitle': '{who} rolled the dice',
      'pot.empty': 'No bets',
      'pot.unbet': 'Not bet',
      'pot.amount': '{amount} chips',
      'pot.totalShort': 'Total: {total} chips',
      'bet.amount': '{amount} chips',
      'ack.nextRound': 'Next round',
      'ack.waiting': 'Waiting...',
      'player.host': '(Host)',
      'player.difficulty': 'Change difficulty',
      'player.remove': 'Remove',
      'player.transferHost': 'Transfer host',
      'room.defaultName': 'Room',
      'room.back': 'Back to room',
      'turn.timer': '{sec}s left',
      'button.roll': 'Roll',
      'button.reroll': 'Reroll ({count})',
      'badge.dealer': 'Dealer',
      'badge.turn': 'Turn',
      'score.chip': 'Chips',
      'score.score': 'Score',
      'result.winner': 'Winner: <b>{name}</b>',
      'result.draw': 'Draw',
      'log.handDetail': ' / Hand: {label}',
      'log.roll': 'Roll: {dice}{hand}',
      'log.roundStart': 'Round start{round}',
      'log.roundStartDealer': 'Round start{round} (Dealer: {dealer})',
      'log.draw': 'Draw',
      'log.win': '{names} win',
      'log.bet': '{amount} chips bet',
      'log.unknown': 'Unknown',
      'log.transfer.from': '{from} → {to} : {amount} chips',
      'log.gameStart': 'Game start',
      'log.gameEnd': 'Game end',
      'rooms.empty': 'No rooms yet',
      'rooms.join': 'Join',
      'toast.nameRequired': 'Please enter a name',
      'toast.codeRequired': 'Please enter an invite code',
      'toast.maxPlayers': 'There are already {count} players; cannot reduce below {max}',
      'toast.copySuccess': 'Copied',
      'toast.copyFail': 'Copy failed',
      'room.hostLabel': 'Host: {name}',
      'room.playersLabel': '{count}/{max} players',
    },
  },
};

const I18N_DEFAULTS = new WeakMap();
const I18N_DOM = [
  { selector: '.header h1', key: 'app.title' },
  { selector: '.header .sub', key: 'app.tagline' },
  { selector: '#screen-top .field span', key: 'top.guestLabel' },
  { selector: '#input-name', key: 'top.guestPlaceholder', attr: 'placeholder' },
  { selector: '#screen-top .pvp-header h3', key: 'top.roomTitle' },
  { selector: '#btn-create', key: 'top.create' },
  { selector: '#input-code', key: 'top.invitePlaceholder', attr: 'placeholder' },
  { selector: '#btn-join', key: 'top.join' },
  { selector: '#screen-top .card:nth-of-type(2) h3', key: 'top.howto.title' },
  { selector: '#screen-top .card:nth-of-type(2) li:nth-child(1)', key: 'top.howto.rule' },
  { selector: '#screen-top .card:nth-of-type(2) li:nth-child(2)', key: 'top.howto.hand' },
  { selector: '#screen-top .card:nth-of-type(2) li:nth-child(3)', key: 'top.howto.steps' },
  { selector: '#screen-lobby > h2', key: 'lobby.title' },
  { selector: '#screen-lobby .card:nth-of-type(1) h3', key: 'lobby.participants' },
  { selector: '#btn-add-bot', key: 'lobby.addCpu' },
  { selector: '#screen-lobby .card:nth-of-type(2) h3', key: 'lobby.settings' },
  { selector: '#screen-lobby .settings-top .row span', key: 'lobby.inviteLabel' },
  { selector: '#btn-copy-code', key: 'lobby.copyInviteAria', attr: 'aria-label' },
  { selector: '#screen-lobby .settings-row .field-row span', key: 'lobby.public' },
  { selector: 'label[for="checkbox-is-public-lobby"]', key: 'lobby.publicLabel' },
  { selector: '#select-rule-mode-lobby option[value="classic"]', key: 'lobby.mode.classic' },
  { selector: '#select-rule-mode-lobby option[value="score"]', key: 'lobby.mode.score' },
  { selector: '#select-rule-mode-lobby option[value="takeall"]', key: 'lobby.mode.takeall' },
  { selector: '#help-mode-bubble .help-bubble__inner', key: 'lobby.mode.helpHtml', attr: 'html' },
  { selector: '#field-sets-total-lobby .field-row span', key: 'lobby.sets' },
  { selector: '#help-sets-bubble .help-bubble__inner', key: 'lobby.setsHelp' },
  { selector: '#screen-lobby .settings-bottom > label.field:last-child > span', key: 'lobby.hebereke' },
  { selector: 'label[for="checkbox-hebereke-lobby"]', key: 'lobby.heberekeLabel' },
  { selector: '#screen-lobby .settings-bottom + .sub', key: 'lobby.hostOnlyNote' },
  { selector: '#btn-ready span:last-child', key: 'lobby.ready' },
  { selector: '#btn-start', key: 'lobby.start' },
  { selector: '#screen-match > h2', key: 'match.title' },
  { selector: '#row-set', key: 'match.set', attr: 'data-prefix' },
  { selector: '#btn-roll', key: 'match.roll' },
  { selector: '#btn-reroll', key: 'match.reroll' },
  { selector: '#btn-keep', key: 'match.keep' },
  { selector: '#btn-round-ack', key: 'match.nextRound' },
  { selector: '.turn-timer', key: 'match.timeLeft', attr: 'aria-label' },
  { selector: '#turn-timer', key: 'match.timeLeft', attr: 'aria-label' },
  { selector: '#round-result-modal', key: 'match.pot', attr: 'aria-label' },
  { selector: '.round-pot-title', key: 'match.pot' },
  { selector: '.bet-label', key: 'match.bet' },
  { selector: '#btn-bet-confirm', key: 'match.confirm' },
  { selector: '#screen-match .match-players h3', key: 'match.players' },
  { selector: '#screen-result > h2', key: 'result.title' },
  { selector: '#btn-back', key: 'result.back' },
  { selector: '#screen-result .result-players h3', key: 'match.players' },
  { selector: '#chat-card .tabs', key: 'chat.aria', attr: 'aria-label' },
  { selector: '#tab-log', key: 'chat.log' },
  { selector: '#tab-chat', key: 'chat.chat' },
  { selector: '#chat-input', key: 'chat.placeholder', attr: 'placeholder' },
  { selector: '#chat-send', key: 'chat.send' },
  { selector: '#btn-leave', key: 'chat.leave' },
  { selector: '#dice-modal', key: 'dice.modalAria', attr: 'aria-label' },
  { selector: '#dice-modal-title', key: 'dice.title' },
  { selector: '#dice-stage', key: 'dice.stageAria', attr: 'aria-label' },
  { selector: '.modal__hint', key: 'dice.skip' },
];

function formatI18n(template, vars) {
  if (!vars) return template;
  return String(template).replace(/\{(\w+)\}/g, (_, key) => {
    if (vars[key] === undefined || vars[key] === null) return '';
    return String(vars[key]);
  });
}

function t(key, vars, fallback) {
  const lang = I18N.current || I18N.defaultLang;
  const dict = I18N.strings[lang] ?? {};
  const template = dict[key] ?? fallback ?? key;
  return formatI18n(template, vars);
}

function getDefaultFor(el) {
  if (!I18N_DEFAULTS.has(el)) I18N_DEFAULTS.set(el, {});
  return I18N_DEFAULTS.get(el);
}

function applyI18nText(el, key, attr) {
  if (!el) return;
  const lang = I18N.current || I18N.defaultLang;
  const defaults = getDefaultFor(el);
  const defaultKey = attr || 'text';
  if (defaults[defaultKey] === undefined) {
    if (attr === 'placeholder') defaults[defaultKey] = el.placeholder ?? '';
    else if (attr === 'aria-label') defaults[defaultKey] = el.getAttribute('aria-label') ?? '';
    else if (attr === 'html') defaults[defaultKey] = el.innerHTML ?? '';
    else defaults[defaultKey] = el.textContent ?? '';
  }
  const translated = t(key, null, defaults[defaultKey]);
  if (lang === I18N.defaultLang && !I18N.strings[lang]?.[key]) {
    if (attr === 'placeholder') el.placeholder = defaults[defaultKey];
    else if (attr === 'aria-label') el.setAttribute('aria-label', defaults[defaultKey]);
    else if (attr === 'html') el.innerHTML = defaults[defaultKey];
    else el.textContent = defaults[defaultKey];
    return;
  }
  if (attr === 'placeholder') el.placeholder = translated;
  else if (attr === 'aria-label') el.setAttribute('aria-label', translated);
  else if (attr === 'html') el.innerHTML = translated;
  else el.textContent = translated;
}

function applyI18n(lang) {
  I18N.current = lang;
  document.documentElement.setAttribute('lang', lang);
  const roomNameLabel = document.querySelector('#input-room-name-lobby')?.closest('label.field')?.querySelector('span');
  if (roomNameLabel) applyI18nText(roomNameLabel, 'lobby.roomName');
  const maxPlayersLabel = document.querySelector('#input-max-players-lobby')?.closest('label.field')?.querySelector('span');
  if (maxPlayersLabel) applyI18nText(maxPlayersLabel, 'lobby.maxPlayers');
  const modeLabel = document.querySelector('#select-rule-mode-lobby')?.closest('label.field')?.querySelector('.field-row span');
  if (modeLabel) applyI18nText(modeLabel, 'lobby.mode');
  const roundRow = document.querySelector('#screen-match .status > div:first-child');
  if (roundRow) {
    const prefix = t('match.round', null, 'ラウンド');
    if (roundRow.firstChild) roundRow.firstChild.textContent = `${prefix}: `;
  }
  for (const entry of I18N_DOM) {
    if (entry.selector === '#row-set' && entry.attr === 'data-prefix') {
      // Special-case for "Set:" prefix in the match status row.
      const row = document.querySelector('#row-set');
      if (!row) continue;
      const prefix = t(entry.key, null, 'セット');
      const span = row.querySelector('span');
      if (span && row.firstChild) row.firstChild.textContent = `${prefix}: `;
      continue;
    }
    const nodes = document.querySelectorAll(entry.selector);
    if (!nodes.length) continue;
    nodes.forEach((el) => applyI18nText(el, entry.key, entry.attr));
  }
  const langLabel = document.querySelector('.lang-switch-label');
  if (langLabel) langLabel.textContent = t('lang.label', null, 'Language');
  const langSelect = document.querySelector('#lang-select');
  if (langSelect) {
    langSelect.value = lang;
    const optJa = langSelect.querySelector('option[value="ja"]');
    const optEn = langSelect.querySelector('option[value="en"]');
    if (optJa) optJa.textContent = t('lang.ja', null, '日本語');
    if (optEn) optEn.textContent = t('lang.en', null, 'English');
  }
}

function setLanguage(lang, { persist = true, rerender = true } = {}) {
  const next = lang === 'en' ? 'en' : 'ja';
  if (persist) {
    try { localStorage.setItem(I18N.storageKey, next); } catch { /* ignore */ }
  }
  applyI18n(next);
  if (rerender && state.room) {
    try { renderRoom(state.room); } catch { /* ignore */ }
    try { renderChat(state.room); } catch { /* ignore */ }
  }
}

function detectLanguage() {
  try {
    const stored = String(localStorage.getItem(I18N.storageKey) ?? '').trim().toLowerCase();
    if (stored === 'ja' || stored === 'en') return stored;
  } catch { /* ignore */ }
  const nav = String(navigator.language ?? '').toLowerCase();
  if (nav.startsWith('en')) return 'en';
  return I18N.defaultLang;
}

function initLanguageSwitcher() {
  const header = document.querySelector('.header');
  if (!header) return;
  if (document.getElementById('lang-select')) return;
  const wrap = document.createElement('div');
  wrap.className = 'lang-switch';
  const label = document.createElement('label');
  label.className = 'lang-switch-label';
  label.textContent = t('lang.label', null, 'Language');
  const select = document.createElement('select');
  select.id = 'lang-select';
  const optJa = document.createElement('option');
  optJa.value = 'ja';
  optJa.textContent = t('lang.ja', null, '日本語');
  const optEn = document.createElement('option');
  optEn.value = 'en';
  optEn.textContent = t('lang.en', null, 'English');
  select.appendChild(optJa);
  select.appendChild(optEn);
  select.value = I18N.current;
  select.addEventListener('change', () => setLanguage(select.value));
  wrap.appendChild(label);
  wrap.appendChild(select);
  header.appendChild(wrap);
}

function isBetMode(ruleMode) {
  return ruleMode === 'classic' || ruleMode === 'takeall';
}

function setRoundResultModalVisible(visible) {
  const modal = $('round-result-modal');
  if (!modal) return;
  modal.classList.toggle('hidden', !visible);
  modal.setAttribute('aria-hidden', visible ? 'false' : 'true');
}

function normalizeDebugDice(value) {
  if (Array.isArray(value) && value.length === 3) {
    const dice = value.map((v) => Number(v));
    if (dice.every((d) => Number.isInteger(d) && d >= 1 && d <= 6)) return dice;
    return null;
  }
  if (typeof value === 'string') {
    const parts = value.split(',').map((v) => v.trim()).filter(Boolean);
    if (parts.length !== 3) return null;
    const dice = parts.map((v) => Number(v));
    if (dice.every((d) => Number.isInteger(d) && d >= 1 && d <= 6)) return dice;
  }
  return null;
}

window.setDebugDice = (value) => {
  const dice = normalizeDebugDice(value);
  if (!dice) {
    console.warn('[debug] invalid dice. use [1,2,3] or "1,2,3"');
    return false;
  }
  state.debugDicePending = dice;
  if (socket?.connected) socket.emit('debug:set_dice', { debugDice: dice });
  console.log('[debug] next dice set', dice);
  return true;
};

window.setDebugHebereke = (value) => {
  const level = Number(value);
  if (!Number.isFinite(level)) {
    console.warn('[debug] invalid hebereke level. use 0-5');
    return false;
  }
  const clamped = Math.max(0, Math.min(5, Math.round(level)));
  state.debugHeberekeLevel = clamped;
  if (state.room && state.playerId) {
    state.room.heberekeLevels = state.room.heberekeLevels ?? {};
    state.room.heberekeLevels[state.playerId] = clamped;
    try {
      renderMatchPlayers(state.room);
    } catch {
      // ignore
    }
  }
  if (socket?.connected) socket.emit('debug:set_hebereke', { level: clamped });
  console.log('[debug] hebereke level set', clamped);
  return true;
};

window.setDebugHoldDiceModal = (value = true) => {
  state.debugHoldDiceModal = Boolean(value);
  console.log('[debug] hold dice modal', state.debugHoldDiceModal);
  return state.debugHoldDiceModal;
};

function getDiceModalMode() {
  try {
    const v = String(localStorage.getItem('diceModalMode') ?? '').trim().toLowerCase();
    if (v === '2d' || v === '3d') return v;
  } catch {
    // ignore
  }
  return UI_FLAGS.diceModalModeDefault;
}

const SFX = {
  rollMp3Url: '/chi.mp3',
  rollMp3Volume: 0.55,
  rollBedVolume: 0.09,
  rollClackVolume: 0.22,
};

function ensureDiceRollAudioElement() {
  if (state.audio.rollEl) return state.audio.rollEl;
  try {
    const el = new Audio(SFX.rollMp3Url);
    el.preload = 'auto';
    el.loop = true;
    el.volume = SFX.rollMp3Volume;
    state.audio.rollEl = el;
    return el;
  } catch {
    return null;
  }
}

function ensureAudioUnlockListeners() {
  const AudioCtx = window.AudioContext || window.webkitAudioContext;
  if (state.audio.unlocked) return;
  if (state.audio._unlockAttached) return;
  state.audio._unlockAttached = true;

  const unlock = async () => {
    try {
      if (AudioCtx) {
        if (!state.audio.ctx) state.audio.ctx = new AudioCtx();
        await state.audio.ctx.resume();
      }

      // Prime HTMLAudio playback in a user gesture to satisfy autoplay policies.
      const rollEl = ensureDiceRollAudioElement();
      if (rollEl) {
        try {
          await rollEl.play();
          rollEl.pause();
          rollEl.currentTime = 0;
        } catch {
          // ignore
        }
      }

      state.audio.unlocked = true;
    } catch {
      // ignore
    }
  };

  window.addEventListener('pointerdown', unlock, { once: true, passive: true });
  window.addEventListener('keydown', unlock, { once: true });
}

function startDiceRollingSfx() {
  // Prefer the provided MP3 if available.
  const rollEl = ensureDiceRollAudioElement();
  if (rollEl) {
    try {
      rollEl.pause();
      rollEl.currentTime = 0;
    } catch {
      // ignore
    }

    // Best-effort: play may be blocked until a user gesture unlocks audio.
    const p = rollEl.play();
    if (p && typeof p.catch === 'function') p.catch(() => {});

    return () => {
      try {
        rollEl.pause();
        rollEl.currentTime = 0;
      } catch {
        // ignore
      }
    };
  }

  const AudioCtx = window.AudioContext || window.webkitAudioContext;
  if (!AudioCtx) return;

  // Best effort: if not unlocked yet, browsers may block audio.
  // We silently no-op to avoid UI disruption.
  if (!state.audio.ctx) {
    try {
      state.audio.ctx = new AudioCtx();
    } catch {
      return;
    }
  }

  const ctx = state.audio.ctx;
  if (!ctx) return;
  if (ctx.state === 'suspended') return;

  const now = ctx.currentTime;

  // Master gain for this rolling instance.
  const master = ctx.createGain();
  master.gain.setValueAtTime(0.0001, now);
  master.gain.exponentialRampToValueAtTime(1.0, now + 0.02);
  master.connect(ctx.destination);

  // Continuous rolling bed: low-ish filtered noise.
  const bedLen = Math.floor(ctx.sampleRate * 0.25);
  const bedBuf = ctx.createBuffer(1, Math.max(1, bedLen), ctx.sampleRate);
  {
    const data = bedBuf.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
  }

  const bedSrc = ctx.createBufferSource();
  bedSrc.buffer = bedBuf;
  bedSrc.loop = true;

  const bedFilter = ctx.createBiquadFilter();
  bedFilter.type = 'lowpass';
  bedFilter.frequency.setValueAtTime(1700, now);
  bedFilter.Q.setValueAtTime(0.7, now);

  const bedGain = ctx.createGain();
  bedGain.gain.setValueAtTime(0.0001, now);
  bedGain.gain.exponentialRampToValueAtTime(Math.max(0.0001, SFX.rollBedVolume), now + 0.03);

  bedSrc.connect(bedFilter);
  bedFilter.connect(bedGain);
  bedGain.connect(master);
  bedSrc.start(now);

  const scheduleClack = (t0) => {
    const dur = rand(0.012, 0.028);
    const len = Math.max(1, Math.floor(ctx.sampleRate * dur));
    const buffer = ctx.createBuffer(1, len, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;

    const src = ctx.createBufferSource();
    src.buffer = buffer;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(rand(1600, 4200), t0);
    filter.Q.setValueAtTime(rand(0.8, 3.0), t0);

    const gain = ctx.createGain();
    const amp = rand(0.08, 0.18) * Math.max(0.0001, SFX.rollClackVolume);
    gain.gain.setValueAtTime(0.0001, t0);
    gain.gain.exponentialRampToValueAtTime(amp, t0 + 0.004);
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);

    if (ctx.createStereoPanner) {
      const pan = ctx.createStereoPanner();
      pan.pan.setValueAtTime(rand(-0.55, 0.55), t0);
      src.connect(filter);
      filter.connect(pan);
      pan.connect(gain);
    } else {
      src.connect(filter);
      filter.connect(gain);
    }

    gain.connect(master);
    src.start(t0);
    src.stop(t0 + dur + 0.02);

    // Tiny tonal tick for a "clack" feel.
    try {
      const osc = ctx.createOscillator();
      osc.type = 'square';
      osc.frequency.setValueAtTime(rand(260, 760), t0);
      const og = ctx.createGain();
      og.gain.setValueAtTime(0.0001, t0);
      og.gain.exponentialRampToValueAtTime(rand(0.01, 0.035) * Math.max(0.0001, SFX.rollClackVolume), t0 + 0.002);
      og.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
      osc.connect(og);
      og.connect(master);
      osc.start(t0);
      osc.stop(t0 + dur + 0.02);
    } catch {
      // ignore
    }
  };

  let stopped = false;
  let timeoutId = null;
  const scheduleNext = () => {
    if (stopped) return;
    const delayMs = randInt(40, 110);
    timeoutId = window.setTimeout(() => {
      if (stopped) return;
      const t0 = ctx.currentTime + 0.02;
      const hits = randInt(1, 3); // simulate 3 dice colliding
      for (let i = 0; i < hits; i++) scheduleClack(t0 + rand(0, 0.02));
      scheduleNext();
    }, delayMs);
  };

  scheduleNext();

  return () => {
    if (stopped) return;
    stopped = true;
    if (timeoutId) window.clearTimeout(timeoutId);

    const t = ctx.currentTime;
    try {
      master.gain.cancelScheduledValues(t);
      master.gain.setValueAtTime(master.gain.value || 0.2, t);
      master.gain.exponentialRampToValueAtTime(0.0001, t + 0.06);
    } catch {
      // ignore
    }

    try {
      bedGain.gain.cancelScheduledValues(t);
      bedGain.gain.setValueAtTime(bedGain.gain.value || 0.05, t);
      bedGain.gain.exponentialRampToValueAtTime(0.0001, t + 0.06);
    } catch {
      // ignore
    }

    try {
      bedSrc.stop(t + 0.08);
    } catch {
      // ignore
    }

    window.setTimeout(() => {
      try { bedSrc.disconnect(); } catch { /* ignore */ }
      try { bedFilter.disconnect(); } catch { /* ignore */ }
      try { bedGain.disconnect(); } catch { /* ignore */ }
      try { master.disconnect(); } catch { /* ignore */ }
    }, 200);
  };
}

function isResolvedDice(dice) {
  return (
    Array.isArray(dice) &&
    dice.length === 3 &&
    dice.every((d) => Number.isInteger(d) && d >= 1 && d <= 6)
  );
}

function diceEqual(a, b) {
  if (!Array.isArray(a) || !Array.isArray(b) || a.length !== 3 || b.length !== 3) return false;
  return a[0] === b[0] && a[1] === b[1] && a[2] === b[2];
}

function findLatestRollResolvedEvent(room) {
  if (!room || !Array.isArray(room.recentEvents)) return null;
  for (let i = room.recentEvents.length - 1; i >= 0; i--) {
    const ev = room.recentEvents[i];
    if (ev?.type === 'ROLL_RESOLVED') return ev;
  }
  return null;
}

function findLatestRollResolvedEventForPlayer(room, playerId) {
  if (!room || !playerId || !Array.isArray(room.recentEvents)) return null;
  for (let i = room.recentEvents.length - 1; i >= 0; i--) {
    const ev = room.recentEvents[i];
    if (ev?.type === 'ROLL_RESOLVED' && ev?.payload?.playerId === playerId) return ev;
  }
  return null;
}

function clampHeberekeLevel(value) {
  const v = Number(value);
  if (!Number.isFinite(v)) return 0;
  return Math.max(0, Math.min(5, Math.round(v)));
}

function getHeberekeLevel(room, playerId) {
  if (!playerId) return 0;
  if (playerId === state.playerId && Number.isFinite(state.debugHeberekeLevel)) {
    return clampHeberekeLevel(state.debugHeberekeLevel);
  }
  if (!room?.heberekeEnabled) return 0;
  return clampHeberekeLevel(room?.heberekeLevels?.[playerId] ?? 0);
}

function rollHeberekeMask(level) {
  const lv = clampHeberekeLevel(level);
  if (lv <= 0) return null;
  if (lv >= 5) {
    const mask = [false, false, false];
    const first = randInt(0, 2);
    mask[first] = true;
    const secondChance = Math.random();
    if (secondChance < 0.35) {
      const remaining = [0, 1, 2].filter((i) => i !== first);
      const second = remaining[randInt(0, remaining.length - 1)];
      mask[second] = true;
    }
    console.log('[hebereke] mask roll', { level: lv, first, secondChance, mask });
    return mask;
  }

  const prob = lv === 1 ? 0.25 : lv === 2 ? 0.5 : lv === 3 ? 0.75 : 1.0;
  const roll = Math.random();
  if (roll > prob) {
    console.log('[hebereke] mask roll', { level: lv, roll, prob, masked: false });
    return null;
  }
  const mask = [false, false, false];
  mask[randInt(0, 2)] = true;
  console.log('[hebereke] mask roll', { level: lv, roll, prob, mask });
  return mask;
}

function getHeberekeFallbackKey(room, playerId, dice) {
  if (!room || !playerId || !Array.isArray(dice)) return null;
  const g = room.game;
  const roundIndex = g?.roundIndex ?? 'r?';
  const turnIndex = g?.turnIndex ?? 't?';
  const rerollsLeft = g?.currentTurn?.rerollsLeft ?? 'rr?';
  return `${playerId}:${roundIndex}:${turnIndex}:${rerollsLeft}:${dice.join('-')}`;
}

function getHeberekeMaskFallback(room, playerId, dice) {
  if (!room?.heberekeEnabled || playerId !== state.playerId) return null;
  if (!Array.isArray(dice) || dice.length !== 3) return null;
  const level = getHeberekeLevel(room, playerId);
  if (level <= 0) return null;
  if (!state.heberekeMaskFallback) state.heberekeMaskFallback = new Map();
  const key = getHeberekeFallbackKey(room, playerId, dice);
  if (!key) return null;
  if (state.heberekeMaskFallback.has(key)) return state.heberekeMaskFallback.get(key);
  const mask = rollHeberekeMask(level);
  state.heberekeMaskFallback.set(key, mask ?? null);
  if (state.heberekeMaskFallback.size > 160) {
    const keys = [...state.heberekeMaskFallback.keys()];
    for (let i = 0; i < keys.length - 120; i++) state.heberekeMaskFallback.delete(keys[i]);
  }
  return mask ?? null;
}

function getHeberekeMaskForRoll(room, playerId, rollSeq) {
  if (!room?.heberekeEnabled || playerId !== state.playerId) return null;
  if (rollSeq === null || rollSeq === undefined) return null;
  const level = getHeberekeLevel(room, playerId);
  if (level <= 0) return null;
  if (!state.heberekeMasks) state.heberekeMasks = new Map();
  if (state.heberekeMasks.has(rollSeq)) return state.heberekeMasks.get(rollSeq);

  const mask = rollHeberekeMask(level);
  state.heberekeMasks.set(rollSeq, mask ?? null);
  if (state.heberekeMasks.size > 120) {
    const keys = [...state.heberekeMasks.keys()];
    for (let i = 0; i < keys.length - 80; i++) state.heberekeMasks.delete(keys[i]);
  }
  return mask;
}

function applyDieMaskClass(el, masked) {
  if (!el) return;
  if (masked) el.classList.add('die--drunk');
  else el.classList.remove('die--drunk');
}

function maskDiceString(dice, mask) {
  if (!Array.isArray(dice)) return '';
  if (!Array.isArray(mask)) return dice.join('-');
  return dice.map((v, i) => (mask[i] ? '?' : String(v))).join('-');
}

function getHeberekeMaskForDice(room, playerId, dice) {
  if (!room || playerId !== state.playerId) return null;
  const latest = findLatestRollResolvedEventForPlayer(room, playerId);
  if (!latest?.payload?.dice) return null;
  if (!diceEqual(latest.payload.dice, dice)) return null;
  if (latest?.payload?.hand?.kind === '123') {
    if (state.heberekeMasks?.has?.(latest.seq)) state.heberekeMasks.delete(latest.seq);
    return null;
  }
  const mask = getHeberekeMaskForRoll(room, playerId, latest.seq);
  if (Array.isArray(mask)) return mask;
  return getHeberekeMaskFallback(room, playerId, dice);
}

function renderDiceAndHand({ dice, hand, mask }) {
  const diceEl = $('dice');
  if (diceEl) {
    diceEl.innerHTML = '';
    const arr = Array.isArray(dice) && dice.length === 3 ? dice : [null, null, null];
    for (let i = 0; i < arr.length; i++) {
      const d = arr[i];
      const div = document.createElement('div');
      div.className = 'die';
      if (Number.isInteger(d) && d >= 1 && d <= 6) {
        div.setAttribute('data-face', String(d));
        // Build a 2D die face (top) with pips.
        for (let i = 1; i <= 9; i++) {
          const pip = document.createElement('span');
          pip.className = `pip p${i}`;
          div.appendChild(pip);
        }
      } else {
        div.classList.add('die--placeholder');
        div.textContent = '·';
      }
      if (Array.isArray(mask) && mask[i]) applyDieMaskClass(div, true);
      diceEl.appendChild(div);
    }
  }

  const handEl = $('hand');
  if (handEl) {
    const ruleMode = state.room?.game?.config?.ruleMode ?? null;
    const handLabel = t('hand.label', null, '役');
    if (hand?.label) {
      const heberekeActive = Array.isArray(mask) && mask.some(Boolean);
      const label = heberekeActive ? '???' : hand.label;
      handEl.textContent = ruleMode === 'score'
        ? `${handLabel}: ${label} / +${hand.score}`
        : `${handLabel}: ${label}`;
    } else {
      handEl.textContent = `${handLabel}: -`;
    }
  }
}

function dequeueDiceModal() {
  if (document.body.classList.contains('modal-open')) {
    console.log('[hebereke] dequeue skipped (modal-open)');
    return;
  }
  const next = state.diceAnimQueue.shift();
  if (!next) {
    console.log('[hebereke] dequeue skipped (empty queue)');
    return;
  }
  console.log('[hebereke] dequeue start', { rollSeq: next.rollSeq, playerId: next.playerId, dice: next.dice, mask: next.mask });

  let modalMask = next.mask;
  if (!Array.isArray(modalMask) && next.rollSeq !== null && next.rollSeq !== undefined) {
    modalMask = getHeberekeMaskForRoll(state.room, next.playerId, next.rollSeq);
  }
  if (!Array.isArray(modalMask) && (next.rollSeq === null || next.rollSeq === undefined)) {
    modalMask = getHeberekeMaskForDice(state.room, next.playerId, next.dice);
  }
  if (!Array.isArray(modalMask) && (next.rollSeq === null || next.rollSeq === undefined)) {
    modalMask = getHeberekeMaskFallback(state.room, next.playerId, next.dice);
  }
  if (Array.isArray(modalMask)) {
    console.log('[hebereke] modal dequeue mask', { rollSeq: next.rollSeq, mask: modalMask });
  }
  showDiceModal({
    title: next.title,
    dice: next.dice,
    mask: modalMask,
    playerId: next.playerId,
    rollSeq: next.rollSeq,
    maskDisabled: next.maskDisabled,
    onClosed: () => {
      // Reveal exactly what the user just saw — but only if it's still
      // the latest authoritative dice for the current turn.
      const latestDice = state.room?.game?.currentTurn?.lastDice ?? null;
      const latestHand = state.room?.game?.currentTurn?.lastHand ?? null;

      if (diceEqual(latestDice, next.dice)) {
        const mask = getHeberekeMaskForDice(state.room, next.playerId, next.dice);
        renderDiceAndHand({ dice: next.dice, hand: next.hand, mask });
      } else {
        // The room state advanced while the modal was open (bot/auto-keep/etc).
        // Sync the UI to the latest room to avoid showing stale dice.
        try {
          if (state.room) renderRoom(state.room);
        } catch {
          // ignore
        }
        // If renderRoom is not safe here for some reason, at least refresh dice.
        try {
          const latestPid = state.room?.game?.currentTurn?.playerId ?? null;
          const mask = getHeberekeMaskForDice(state.room, latestPid, latestDice);
          renderDiceAndHand({ dice: latestDice, hand: latestHand, mask });
        } catch {
          // ignore
        }
      }
      try {
        if (state.room) renderMatchPlayers(state.room);
      } catch {
        // ignore
      }
      // Continue with any queued rolls.
      dequeueDiceModal();
    },
  });
}

function maybeShowDiceModalFromState(nextRoom) {
  if (!nextRoom || nextRoom.status !== 'in_game') return;

  const prevRoom = state.room;
  if (!prevRoom || prevRoom.status !== 'in_game') {
    const latestEv = findLatestRollResolvedEvent(nextRoom);
    if (latestEv?.seq !== undefined) state.lastRollResolvedSeq = latestEv.seq;
    return; // don't animate on first sync
  }

  const latestEv = findLatestRollResolvedEvent(nextRoom);
  if (latestEv?.seq !== undefined && latestEv.seq !== state.lastRollResolvedSeq) {
    const nextDice = latestEv?.payload?.dice;
    const hand = latestEv?.payload?.hand ?? nextRoom?.game?.currentTurn?.lastHand ?? null;
    if (isResolvedDice(nextDice)) {
      const pid = latestEv?.payload?.playerId ?? nextRoom?.game?.currentTurn?.playerId;
      const who = playerLabel(nextRoom, pid);
      const title = t('dice.rollTitle', { who }, `${who} がサイコロを振った`);
      const maskDisabled = latestEv?.payload?.hand?.kind === '123';
      const mask = maskDisabled ? null : getHeberekeMaskForRoll(nextRoom, pid, latestEv.seq);
      state.diceAnimQueue.push({ title, dice: nextDice, hand, mask, playerId: pid, rollSeq: latestEv.seq, maskDisabled });
      console.log('[hebereke] enqueue roll_resolved', { rollSeq: latestEv.seq, playerId: pid, dice: nextDice, mask });
      state.lastRollResolvedSeq = latestEv.seq;
      dequeueDiceModal();
      return;
    }
    state.lastRollResolvedSeq = latestEv.seq;
  }

  const nextDice = nextRoom?.game?.currentTurn?.lastDice;
  const prevDice = prevRoom?.game?.currentTurn?.lastDice;
  if (!isResolvedDice(nextDice)) return;
  if (diceEqual(prevDice, nextDice)) return;

  const pid = nextRoom?.game?.currentTurn?.playerId;
  const who = playerLabel(nextRoom, pid);
  const title = t('dice.rollTitle', { who }, `${who} がサイコロを振った`);
  const hand = nextRoom?.game?.currentTurn?.lastHand ?? null;

  const maskDisabled = nextRoom?.game?.currentTurn?.lastHand?.kind === '123';
  const mask = maskDisabled ? null : getHeberekeMaskForDice(nextRoom, pid, nextDice);
  state.diceAnimQueue.push({ title, dice: nextDice, hand, mask, playerId: pid, rollSeq: null, maskDisabled });
  console.log('[hebereke] enqueue dice_change', { playerId: pid, dice: nextDice, mask });
  dequeueDiceModal();
}

function showScreen(name) {
  for (const [k, el] of Object.entries(screens)) {
    el.classList.toggle('hidden', k !== name);
  }
  
  // Always hide chat-card and chat-actions on top screen
  if (name === 'top') {
    $('chat-card').classList.add('hidden');
    $('chat-actions').classList.add('hidden');
  }
}

function toast(message) {
  const t = $('toast');
  t.textContent = message;
  t.classList.remove('hidden');
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => t.classList.add('hidden'), 2400);
}

function displayName() {
  const name = String($('input-name').value ?? '').trim();
  if (name) localStorage.setItem(STORAGE_KEYS.guestName, name);
  return name;
}

function clearReconnectStorage() {
  localStorage.removeItem(STORAGE_KEYS.roomId);
  localStorage.removeItem(STORAGE_KEYS.reconnectToken);
}

function restoreGuestName() {
  const input = $('input-name');
  if (!input) return;
  if (String(input.value ?? '').trim()) return;
  const saved = String(localStorage.getItem(STORAGE_KEYS.guestName) ?? '').trim();
  if (saved) input.value = saved;
}

function scoreTitleForMode(ruleMode) {
  return ruleMode === 'classic' || ruleMode === 'takeall'
    ? t('score.chip', null, 'コマ')
    : t('score.score', null, 'スコア');
}

function getPlayerWaitStatus(room, player) {
  if (!room || !player || room.status !== 'in_game' || !room.game) {
    return { show: false, waiting: false };
  }
  const g = room.game;
  const dealerId = g.round?.dealerId ?? null;

  if (room.roundAdvance) {
    const ackedIds = new Set(room.roundAdvance.ackedPlayerIds ?? []);
    const needsAck = player.playerType === 'human' && player.connected && !ackedIds.has(player.playerId);
    return { show: true, waiting: needsAck };
  }

  const betContext = getBetContext(room);
  if (betContext && !g.currentTurn?.lastDice) {
    const bets = g.round?.bets ?? {};
    const eligible =
      (betContext.mode === 'classic' ? player.playerId !== dealerId : true) &&
      (player.playerType === 'bot' || (player.playerType === 'human' && player.connected));
    const hasBet = Object.prototype.hasOwnProperty.call(bets, player.playerId);
    const bettingPhaseActive = !areBetsComplete(room, betContext);

    if (bettingPhaseActive) {
      if (eligible && !hasBet) return { show: true, waiting: true };
      return { show: true, waiting: false };
    }

    if (!eligible) {
      // Dealer after betting phase: waiting to roll
      if (betContext.mode === 'classic' && player.playerId === dealerId && g.currentTurn?.playerId === dealerId) {
        return { show: true, waiting: true };
      }
      return { show: true, waiting: false };
    }
  }

  if (g.currentTurn?.playerId === player.playerId) {
    return { show: true, waiting: true };
  }

  return { show: true, waiting: false };
}

function getBetContext(room) {
  const g = room?.game;
  const mode = g?.config?.ruleMode;
  if (!g || (mode !== 'classic' && mode !== 'takeall')) return null;
  const bets = g?.round?.bets ?? {};
  const potTotal =
    Number.isFinite(g?.round?.potTotal)
      ? Number(g.round.potTotal)
      : Object.values(bets).reduce((sum, v) => sum + Number(v ?? 0), 0);
  return {
    bets,
    potTotal,
    potCarry: Number(g?.round?.potCarry ?? 0),
    dealerId: mode === 'classic' ? g?.round?.dealerId ?? null : null,
    roundIndex: g?.roundIndex ?? 0,
    mode,
  };
}

function getRequiredBetPlayerIds(room, dealerId, mode) {
  if (!room) return [];
  const active = room.players.filter((p) =>
    p.playerType === 'bot' || (p.playerType === 'human' && p.connected)
  );
  if (mode === 'classic') {
    if (!dealerId) return [];
    return active.filter((p) => p.playerId !== dealerId).map((p) => p.playerId);
  }
  if (mode === 'takeall') {
    return active.map((p) => p.playerId);
  }
  return [];
}

function areBetsComplete(room, betContext) {
  if (!room || !betContext) return true;
  const requiredIds = getRequiredBetPlayerIds(room, betContext.dealerId, betContext.mode);
  if (requiredIds.length === 0) return true;
  const bets = betContext.bets ?? {};
  return requiredIds.every((pid) => Object.prototype.hasOwnProperty.call(bets, pid));
}

function clampBetAmount(value) {
  if (!Number.isFinite(value)) return 0;
  if (value <= 0) return 10;
  return Math.floor(value / 10) * 10;
}

function computeRoundWinners(room, roundIndex) {
  if (!room) return { winnerIds: [], roundIndex };
  const mode = room.game?.config?.ruleMode ?? room.ruleMode ?? 'score';
  const events = Array.isArray(room.recentEvents) ? room.recentEvents : [];

  if (mode === 'classic' || mode === 'takeall') {
    const roundResult = [...events]
      .reverse()
      .find((ev) => ev?.type === 'ROUND_RESULT' && ev?.payload?.roundIndex === roundIndex);
    const winnerIds = roundResult?.payload?.winnerIds ?? [];
    return { winnerIds, roundIndex };
  }

  const turnEvents = events.filter(
    (ev) => ev?.type === 'TURN_ENDED' && ev?.payload?.roundIndex === roundIndex
  );
  if (!turnEvents.length) return { winnerIds: [], roundIndex };

  let maxGained = -Infinity;
  for (const ev of turnEvents) {
    const gained = Number(ev?.payload?.gained ?? 0);
    if (gained > maxGained) maxGained = gained;
  }
  const winnerIds = turnEvents
    .filter((ev) => Number(ev?.payload?.gained ?? 0) === maxGained)
    .map((ev) => ev?.payload?.playerId)
    .filter(Boolean);

  return { winnerIds, roundIndex };
}

function findLatestRoundResultEvent(room) {
  const events = Array.isArray(room?.recentEvents) ? room.recentEvents : [];
  for (let i = events.length - 1; i >= 0; i--) {
    const ev = events[i];
    if (ev?.type === 'ROUND_RESULT' || ev?.type === 'ROUND_ENDED') return ev;
  }
  return null;
}

function renderRoundResultModal(room) {
  const modal = $('round-result-modal');
  const potTotalEl = $('round-pot-total');
  const potListEl = $('round-pot-list');
  const betControls = $('bet-controls');
  const betAmountEl = $('bet-amount');
  const betMinusBtn = $('btn-bet-minus');
  const betPlusBtn = $('btn-bet-plus');
  const betConfirmBtn = $('btn-bet-confirm');
  const ackBtn = $('btn-round-ack');
  const rollBtn = $('btn-roll');
  const rerollBtn = $('btn-reroll');
  const keepBtn = $('btn-keep');
  const actionsRow = document.querySelector('.row-actions');

  if (
    !modal ||
    !potTotalEl ||
    !potListEl ||
    !betControls ||
    !betAmountEl ||
    !betMinusBtn ||
    !betPlusBtn ||
    !betConfirmBtn ||
    !ackBtn
  ) {
    return;
  }

  if (!room || room.status !== 'in_game' || !room.game) {
    setRoundResultModalVisible(false);
    return;
  }

  const mode = room.game?.config?.ruleMode ?? room.ruleMode ?? 'score';
  if (!isBetMode(mode)) {
    setRoundResultModalVisible(false);
    return;
  }

  const serverAdvance = room?.roundAdvance ?? null;
  if (serverAdvance) {
    const prevRoundIndex = state.roundAdvanceHold?.roundIndex ?? null;
    if (prevRoundIndex !== serverAdvance.roundIndex) {
      state.roundAdvanceHoldAcked = false;
    }
    state.roundAdvanceHold = serverAdvance;
  }

  const advance = serverAdvance ?? state.roundAdvanceHold;
  const clearedByServer = Boolean(state.roundAdvanceHold || state.roundAdvanceHoldAcked) && !serverAdvance;
  if (clearedByServer) {
    const latestRoundEv = findLatestRoundResultEvent(room);
    state.lastRoundResultSeq = latestRoundEv?.seq ?? state.lastRoundResultSeq;
    state.roundAdvanceHold = null;
    state.roundAdvanceHoldAcked = false;
  }

  const g = room.game;
  const betContext = getBetContext(room);
  if (!betContext) {
    setRoundResultModalVisible(false);
    return;
  }
  const bets = betContext?.bets ?? {};
  const potTotal = betContext?.potTotal ?? 0;
  const dealerId = betContext?.dealerId ?? null;
  const betMode = betContext?.mode ?? null;

  potTotalEl.textContent = t('pot.totalShort', { total: potTotal }, `合計: ${potTotal}コマ`);
  potListEl.innerHTML = '';
  const requiredIds = getRequiredBetPlayerIds(room, dealerId, betMode);
  const betEntries = requiredIds.map((pid) => ({
    pid,
    hasBet: Object.prototype.hasOwnProperty.call(bets, pid),
    amount: Number(bets[pid] ?? 0),
  }));
  if (betEntries.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'round-pot-item';
    empty.textContent = t('pot.empty', null, 'ベットなし');
    potListEl.appendChild(empty);
  } else {
    for (const entry of betEntries) {
      const line = document.createElement('div');
      line.className = 'round-pot-item';
      const name = document.createElement('span');
      name.textContent = playerLabel(room, entry.pid);
      const value = document.createElement('span');
      value.textContent = entry.hasBet
        ? t('pot.amount', { amount: entry.amount }, `${entry.amount}コマ`)
        : t('pot.unbet', null, '未ベット');
      line.appendChild(name);
      line.appendChild(value);
      potListEl.appendChild(line);
    }
  }

  const myBet = Number(bets[state.playerId] ?? 0);
  const hasMyBet = Object.prototype.hasOwnProperty.call(bets, state.playerId);
  const myChips = Number(g?.scores?.[state.playerId] ?? 0);
  const maxBet = clampBetAmount(myChips + myBet);

  if (state.betDraftRoundIndex !== betContext?.roundIndex) {
    state.betDraftRoundIndex = betContext?.roundIndex ?? null;
    state.betDraft = myBet >= 10 ? myBet : 10;
  }
  state.betDraft = clampBetAmount(state.betDraft);
  if (state.betDraft > maxBet) state.betDraft = maxBet;

  betAmountEl.textContent = t('bet.amount', { amount: state.betDraft }, `${state.betDraft}コマ`);

  const betsComplete = areBetsComplete(room, betContext);
  const betAllowed =
    Boolean(betContext) &&
    room.status === 'in_game' &&
    state.playerId &&
    !room.roundAdvance &&
    !g?.currentTurn?.lastDice &&
    (betMode === 'classic' ? dealerId && state.playerId !== dealerId : true);

  betControls.classList.toggle('hidden', !betAllowed);

  const canDec = betAllowed && state.betDraft >= 10;
  const canInc = betAllowed && state.betDraft + 10 <= maxBet;
  betMinusBtn.disabled = !canDec;
  betPlusBtn.disabled = !canInc;
  betConfirmBtn.disabled =
    !betAllowed ||
    state.betDraft < 10 ||
    (state.betDraft === myBet && hasMyBet);
  modal.classList.toggle(
    'pulse-border',
    Boolean(!room.roundAdvance && !betsComplete && betAllowed && !hasMyBet)
  );

    renderRoundAdvanceControls(room);

setRoundResultModalVisible(true);
  modal.classList.remove('round-result-idle');
}


function renderRoundAdvanceControls(room) {
  const ackBtn = $('btn-round-ack');
  if (!ackBtn) return;
  const rollBtn = $('btn-roll');
  const rerollBtn = $('btn-reroll');
  const keepBtn = $('btn-keep');
  const actionsRow = document.querySelector('.row-actions');

  const advance = room?.roundAdvance ?? state.roundAdvanceHold;
  if (advance) {
    const ackedIds = Array.isArray(advance.ackedPlayerIds) ? advance.ackedPlayerIds : [];
    const alreadyAcked = Boolean(state.playerId && ackedIds.includes(state.playerId));
    ackBtn.disabled = alreadyAcked;
    ackBtn.textContent = alreadyAcked
      ? t('ack.waiting', null, '待機中...')
      : t('ack.nextRound', null, '次のラウンドへ');
    ackBtn.classList.toggle('pulse-border', !alreadyAcked);

    if (rollBtn) rollBtn.disabled = true;
    if (rerollBtn) rerollBtn.disabled = true;
    if (keepBtn) keepBtn.disabled = true;
    if (actionsRow) actionsRow.classList.add('round-result-waiting');
  } else {
    ackBtn.disabled = true;
    ackBtn.textContent = t('ack.nextRound', null, '次のラウンドへ');
    ackBtn.classList.remove('pulse-border');
    if (actionsRow) actionsRow.classList.remove('round-result-waiting');
  }

  if (!ackBtn.dataset.roundAckHandlerAttached) {
    ackBtn.dataset.roundAckHandlerAttached = 'true';
    ackBtn.addEventListener('click', function handleRoundAck() {
      if (ackBtn.disabled) {
        return;
      }
      ackBtn.disabled = true;
      ackBtn.textContent = t('ack.waiting', null, '待機中...');
      state.roundAdvanceHoldAcked = true;
      if (state.playerId && state.roundAdvanceHold) {
        const list = Array.isArray(state.roundAdvanceHold.ackedPlayerIds)
          ? state.roundAdvanceHold.ackedPlayerIds
          : [];
        if (!list.includes(state.playerId)) list.push(state.playerId);
        state.roundAdvanceHold.ackedPlayerIds = list;
      }
      const latestRoundEv = findLatestRoundResultEvent(state.room);
      state.lastRoundResultSeq = latestRoundEv?.seq ?? state.lastRoundResultSeq;
      if (state.room) {
        const mode = state.room.game?.config?.ruleMode ?? state.room.ruleMode ?? 'score';
        if (isBetMode(mode)) renderRoundResultModal(state.room);
        else renderRoundAdvanceControls(state.room);
      }
      socket.emit('round:ack');
    });
  }
}


function renderRoom(room) {
  state.lastRoomStatus = room.status;
  state.room = room;

  const roundAdvanceActive = Boolean(room.roundAdvance);
  if (!roundAdvanceActive && state.roundAdvanceHold) {
    state.roundAdvanceHold = null;
    state.roundAdvanceHoldAcked = false;
  }
  if (!roundAdvanceActive && room?.game) {
    const roomRoundIndex = Number(room.game.roundIndex ?? 0);
    if (state.cachedRoundRollsRoundIndex !== null && state.cachedRoundRollsRoundIndex !== roomRoundIndex) {
      state.cachedRoundRolls.clear();
      state.cachedRoundRollsRoundIndex = roomRoundIndex;
    }
  }
  if ((state.lastRoundAdvanceActive || state.deferRoundStartedLogs) && !roundAdvanceActive) {
    const log = $('event-log');
    if (log && state.pendingRoundStartEvents.length > 0) {
      for (const ev of state.pendingRoundStartEvents) {
        const line = formatEventLine(state.room, ev);
        log.textContent += (log.textContent ? '\n' : '') + line;
      }
      log.scrollTop = log.scrollHeight;
    }
    state.pendingRoundStartEvents = [];
    state.deferRoundStartedLogs = false;
  }
  state.lastRoundAdvanceActive = roundAdvanceActive;

  const nextGameStatus = room?.game?.status ?? null;
  const prevGameStatus = state.lastGameStatus;
  state.lastGameStatus = nextGameStatus;
  if (nextGameStatus === 'in_game') state.pvpShowResult = null;
  if (nextGameStatus !== 'in_game' || prevGameStatus !== 'in_game') {
    state.heberekeMasks?.clear?.();
    state.heberekeMaskFallback?.clear?.();
  }

  const isParticipant =
    room.mode === 'pvp' &&
    Boolean(state.playerId) &&
    room?.game?.scores &&
    Object.prototype.hasOwnProperty.call(room.game.scores, state.playerId);

  if (room.mode === 'pvp' && nextGameStatus === 'finished' && prevGameStatus !== 'finished' && state.pvpShowResult !== false) {
    if (isParticipant) state.pvpShowResult = true;
  }

  $('label-code').textContent = room.inviteCode;

  const isHost = room.hostPlayerId === state.playerId;
  const me = room.players.find((p) => p.playerId === state.playerId);

  if (state.pendingRoundResult) {
    // console.log('[round-result] apply pendingRoundResult', state.pendingRoundResult);
    const { roundIndex, winnerIds } = state.pendingRoundResult;
    room.roundAdvance = {
      roundIndex: Number(roundIndex ?? 0),
      winnerIds: Array.isArray(winnerIds) ? winnerIds : [],
      ackedPlayerIds: room.roundAdvance?.ackedPlayerIds ?? [],
    };
    state.roundAdvanceHold = room.roundAdvance;
    state.roundAdvanceHoldAcked = false;
    state.pendingRoundResult = null;
  }

  if (!room.roundAdvance && room.status === 'in_game' && !state.roundAdvanceHoldAcked) {
    const latestRoundEv = findLatestRoundResultEvent(room);
    const latestSeq = latestRoundEv?.seq ?? null;
    // console.log('[round-result] fallback latestRoundEv', { latestSeq, latestRoundEv });
    if (latestRoundEv && latestSeq !== state.lastRoundResultSeq) {
      const roundIndex = latestRoundEv?.payload?.roundIndex ?? 0;
      const { winnerIds } = computeRoundWinners(room, roundIndex);
      // console.log('[round-result] fallback set roundAdvance', { roundIndex, winnerIds });
      room.roundAdvance = {
        roundIndex: Number(roundIndex ?? 0),
        winnerIds,
        ackedPlayerIds: [],
      };
      state.roundAdvanceHold = room.roundAdvance;
      state.roundAdvanceHoldAcked = false;
      state.lastRoundResultSeq = latestSeq;
    }
  }

  {
    const betContext = getBetContext(room);
    if (betContext) renderRoundResultModal(room);
    else {
      const modal = $('round-result-modal');
      if (modal) {
        modal.classList.add('hidden');
        modal.setAttribute('aria-hidden', 'true');
      }
    }
  }
  const meReady = Boolean(me?.ready);

  const playersEl = $('list-players');
  playersEl.innerHTML = '';
  for (const p of room.players) {
    if (room.mode === 'pvp' && !p.connected) continue;
    const li = document.createElement('li');
    li.className = 'player-item';

    const ready = p.ready ? '✅' : '☐';
    const type = p.playerType === 'bot' ? `🤖(${p.botDifficulty})` : '';
    const hostMark = p.playerId === room.hostPlayerId
      ? t('player.host', null, '（ホスト）')
      : '';

    const label = document.createElement('span');
    label.className = 'player-label';

    const readySpan = document.createElement('span');
    readySpan.className = 'player-ready';
    readySpan.textContent = ready;
    label.appendChild(readySpan);

    const waitStatus = getPlayerWaitStatus(room, p);
    const waitSpan = document.createElement('span');
    waitSpan.className = 'player-wait-indicator';
    if (!waitStatus.show) {
      waitSpan.classList.add('is-hidden');
    } else if (waitStatus.waiting) {
      waitSpan.classList.add('is-waiting');
    } else {
      waitSpan.textContent = '✓';
    }
    label.appendChild(waitSpan);

    const nameSpan = document.createElement('span');
    nameSpan.className = 'player-name';
    nameSpan.textContent = `${p.displayName}${hostMark}${type}`;
    label.appendChild(nameSpan);

    li.appendChild(label);

    const canManageLobby = room.mode === 'pvp' && room.status === 'lobby' && isHost && !meReady;
    if (isHost && p.playerType === 'bot') {
      const difficultyBtn = document.createElement('button');
      difficultyBtn.type = 'button';
      difficultyBtn.className = 'player-diff hidden-until-hover';
      difficultyBtn.textContent = t('player.difficulty', null, '難易度変更');
      difficultyBtn.disabled = !canManageLobby;
      difficultyBtn.addEventListener('click', () => {
        socket.emit('room:cycle_bot_difficulty', { botPlayerId: p.playerId });
      });
      li.appendChild(difficultyBtn);

      const removeBtn = document.createElement('button');
      removeBtn.type = 'button';
      removeBtn.className = 'player-remove hidden-until-hover danger';
      removeBtn.textContent = t('player.remove', null, '削除');
      removeBtn.disabled = !canManageLobby;
      removeBtn.addEventListener('click', () => {
        socket.emit('room:remove_bot', { botPlayerId: p.playerId });
      });
      li.appendChild(removeBtn);
    } else if (isHost && p.playerType === 'human' && p.connected && p.playerId !== room.hostPlayerId) {
      const transferBtn = document.createElement('button');
      transferBtn.type = 'button';
      transferBtn.className = 'player-transfer hidden-until-hover';
      transferBtn.textContent = t('player.transferHost', null, 'ホスト委任');
      transferBtn.disabled = !canManageLobby;
      transferBtn.addEventListener('click', () => {
        socket.emit('room:transfer_host', { nextHostPlayerId: p.playerId });
      });
      li.appendChild(transferBtn);
    }
    playersEl.appendChild(li);
  }

  $('btn-start').disabled = !isHost || room.status !== 'lobby';

  const addBotBtn = $('btn-add-bot');
  if (addBotBtn) {
    const activeCount = room.players.filter((p) => (p.playerType === 'bot' ? true : p.connected)).length;
    const maxPlayers = room.maxPlayers ?? 4;
    const isPvpLobby = room.mode === 'pvp' && room.status === 'lobby';
    const canAddBot = isPvpLobby && isHost && !meReady;
    if (isPvpLobby && isHost) addBotBtn.classList.remove('hidden');
    else addBotBtn.classList.add('hidden');
    addBotBtn.disabled = !canAddBot || activeCount >= maxPlayers;
  }

  const ruleModeSelect = $('select-rule-mode-lobby');
  if (ruleModeSelect) {
    // Default to 'classic' unless the room explicitly specifies another mode.
    if (room.ruleMode === 'score') ruleModeSelect.value = 'score';
    else if (room.ruleMode === 'takeall') ruleModeSelect.value = 'takeall';
    else ruleModeSelect.value = 'classic';
    ruleModeSelect.disabled = !isHost || meReady || room.status !== 'lobby';
  }

  const roomNameInput = $('input-room-name-lobby');
  if (roomNameInput) {
    if (document.activeElement !== roomNameInput) {
      roomNameInput.value = room.roomName ?? t('room.defaultName', null, 'ルーム');
    }
    roomNameInput.disabled = !isHost || meReady || room.status !== 'lobby';
  }

  const maxPlayersInput = $('input-max-players-lobby');
  if (maxPlayersInput) {
    if (document.activeElement !== maxPlayersInput) {
      maxPlayersInput.value = room.maxPlayers ?? 4;
    }
    maxPlayersInput.disabled = !isHost || meReady || room.status !== 'lobby';
  }

  const isPublicCheckbox = $('checkbox-is-public-lobby');
  if (isPublicCheckbox) {
    if (document.activeElement !== isPublicCheckbox) {
      isPublicCheckbox.checked = Boolean(room.isPublic);
    }
    isPublicCheckbox.disabled = !isHost || meReady || room.status !== 'lobby';
  }

  const heberekeCheckbox = $('checkbox-hebereke-lobby');
  if (heberekeCheckbox) {
    if (document.activeElement !== heberekeCheckbox) {
      heberekeCheckbox.checked = Boolean(room.heberekeEnabled);
    }
    heberekeCheckbox.disabled = !isHost || meReady || room.status !== 'lobby';
  }

  const setsField = $('field-sets-total-lobby');
  if (setsField) {
    if (room.ruleMode === 'classic') setsField.classList.remove('hidden');
    else setsField.classList.add('hidden');
  }

  const setsLobby = $('input-sets-total-lobby');
  if (setsLobby) {
    setsLobby.value = String(room.classicSetsTotal ?? 3);
    setsLobby.disabled = !isHost || meReady || room.status !== 'lobby' || room.ruleMode !== 'classic';
  }
  const readyBtn = $('btn-ready');
  if (readyBtn) {
    const isReady = Boolean(me?.ready);
    const mark = readyBtn.querySelector?.('.ready-mark') ?? null;
    if (mark) mark.textContent = isReady ? '✓' : '☐';
    readyBtn.setAttribute('aria-pressed', isReady ? 'true' : 'false');
    if (isReady) readyBtn.classList.add('on');
    else readyBtn.classList.remove('on');
    readyBtn.disabled = room.status !== 'lobby';
  }

  if (state.room && room.mode === 'pvp' && room.status !== 'finished' && (room.status === 'lobby' || room.status === 'in_game' || room.game?.status === 'finished')) {
    $('chat-card').classList.remove('hidden');
    $('chat-actions').classList.remove('hidden');
    syncUnifiedPanelUiForRoom(room);
    renderChat(room);
    renderEventLogFromRoom(room);
  } else {
    $('chat-card').classList.add('hidden');
    $('chat-actions').classList.add('hidden');
  }

  const shouldShowPvpResult =
    room.mode === 'pvp' &&
    room.game?.status === 'finished' &&
    (state.pvpShowResult === true || (state.pvpShowResult === null && isParticipant));

  if (shouldShowPvpResult) {
    const back = $('btn-back');
    back.textContent = t('room.back', null, 'ルームへ戻る');
    showScreen('result');
    renderResult(room);
    return;
  }

  if (room.status === 'lobby') {
    showScreen('lobby');
    return;
  }

  if (room.status === 'in_game') {
    showScreen('match');
    renderMatch(room);
    renderRoundResultModal(room);
    return;
  }

  if (room.status === 'finished') {
    const back = $('btn-back');
    back.textContent = t('room.back', null, 'ロビーへ戻る');
    showScreen('result');
    renderResult(room);
    renderRoundResultModal(room);
  }
}

function setUnifiedPanelTab(tab, { persist = true } = {}) {
  const next = tab === 'log' ? 'log' : 'chat';
  if (persist) state.unifiedPanelTab = next;

  const tabChat = $('tab-chat');
  const tabLog = $('tab-log');
  const panelChat = $('panel-chat');
  const panelLog = $('panel-log');

  const isChat = next === 'chat';

  if (tabChat) {
    tabChat.classList.toggle('on', isChat);
    tabChat.setAttribute('aria-selected', isChat ? 'true' : 'false');
  }
  if (tabLog) {
    tabLog.classList.toggle('on', !isChat);
    tabLog.setAttribute('aria-selected', !isChat ? 'true' : 'false');
  }

  if (panelChat) panelChat.classList.toggle('hidden', !isChat);
  if (panelLog) panelLog.classList.toggle('hidden', isChat);
}

function syncUnifiedPanelUiForRoom(room) {
  const isPvp = room?.mode === 'pvp';

  const tabChat = $('tab-chat');
  const panelChat = $('panel-chat');

  if (tabChat) tabChat.classList.toggle('hidden', !isPvp);
  if (panelChat) panelChat.classList.toggle('hidden', !isPvp || state.unifiedPanelTab !== 'chat');

  if (!isPvp) {
    setUnifiedPanelTab('log', { persist: false });
    const input = $('chat-input');
    if (input) input.value = '';
    return;
  }

  setUnifiedPanelTab(state.unifiedPanelTab);
}

function renderChat(room) {
  const log = $('chat-log');
  if (!log) return;
  if (!room || room.mode !== 'pvp') {
    log.textContent = '';
    return;
  }

  const pad2 = (n) => String(n).padStart(2, '0');
  const formatTime = (iso) => {
    const d = new Date(iso ?? Date.now());
    return `${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
  };

  log.innerHTML = '';
  for (const msg of room.chat ?? []) {
    // Skip system messages (they go to the log tab instead)
    if (!msg.playerId) continue;

    const item = document.createElement('div');
    item.className = 'chat-item';

    const left = document.createElement('div');
    left.className = 'chat-left';

    const who = document.createElement('div');
    who.className = 'chat-who';
    who.textContent = playerLabel(room, msg.playerId);
    left.appendChild(who);

    const text = document.createElement('div');
    text.className = 'chat-text';
    text.textContent = String(msg.text ?? '');
    left.appendChild(text);

    const right = document.createElement('div');
    right.className = 'chat-right';

    const time = document.createElement('small');
    time.className = 'chat-time';
    time.textContent = formatTime(msg.createdAt);
    right.appendChild(time);

    item.appendChild(left);
    item.appendChild(right);
    log.appendChild(item);
  }
  log.scrollTop = log.scrollHeight;
}

function renderTurnTimer(room) {
  const svg = $('turn-timer');
  const bar = svg?.querySelector?.('.turn-timer__bar') ?? null;
  const text = $('turn-timer-text');
  if (!svg || !bar || !text) return;

  if (!room || room.status !== 'in_game') {
    text.textContent = '--';
    bar.style.strokeDasharray = String(TURN_TIMER.circumference);
    bar.style.strokeDashoffset = String(0);
    bar.style.stroke = 'rgba(255,255,255,0.30)';
    return;
  }

  // Choose the active deadline.
  // - Round result confirmation timeout (same as turn)
  // - Normally: turn timeout (20s)
  // - After final reroll: auto-keep deadline (1.5s)
  let dueAtMs = null;
  let totalMs = null;

  const autoKeepApplies =
    room.autoKeep?.dueAt &&
    room.autoKeep?.timeoutMs &&
    room.game?.currentTurn?.playerId &&
    room.autoKeep.playerId === room.game.currentTurn.playerId;

  if (room.roundAdvance?.dueAt && room.roundAdvance?.timeoutMs) {
    dueAtMs = Date.parse(room.roundAdvance.dueAt);
    totalMs = Number(room.roundAdvance.timeoutMs);
  } else if (autoKeepApplies) {
    dueAtMs = Date.parse(room.autoKeep.dueAt);
    totalMs = Number(room.autoKeep.timeoutMs);
  } else if (room.turn?.dueAt && room.turn?.timeoutMs) {
    dueAtMs = Date.parse(room.turn.dueAt);
    totalMs = Number(room.turn.timeoutMs);
  }

  if (!Number.isFinite(dueAtMs) || !Number.isFinite(totalMs) || totalMs <= 0) {
    text.textContent = '--';
    bar.style.strokeDasharray = String(TURN_TIMER.circumference);
    bar.style.strokeDashoffset = String(0);
    bar.style.stroke = 'rgba(255,255,255,0.30)';
    return;
  }

  const remainingMs = Math.max(0, dueAtMs - Date.now());
  const ratio = totalMs > 0 ? Math.max(0, Math.min(1, remainingMs / totalMs)) : 0;

  const dashoffset = -TURN_TIMER.circumference * (1 - ratio);
  bar.style.strokeDasharray = String(TURN_TIMER.circumference);
  bar.style.strokeDashoffset = String(dashoffset);

  const sec = Math.ceil(remainingMs / 1000);
  text.textContent = t('turn.timer', { sec }, `残り ${sec}s`);

  // Color shift near timeout.
  if (sec <= 3) bar.style.stroke = 'rgba(255, 107, 107, 0.95)';
  else if (sec <= 7) bar.style.stroke = 'rgba(255, 204, 102, 0.95)';
  else bar.style.stroke = 'rgba(90, 167, 255, 0.90)';
}

function setDieFace(el, value) {
  if (!el) return;
  const v = Number(value);
  const face = Number.isInteger(v) && v >= 1 && v <= 6 ? v : 1;
  el.setAttribute('data-face', String(face));
}

function shuffleInPlace(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function rand(min, max) {
  return min + Math.random() * (max - min);
}

function randInt(min, max) {
  return Math.floor(rand(min, max + 1));
}

function randomizeDiceMotion2d(diceEls) {
  if (!Array.isArray(diceEls)) return;

  // When the dice settle flat, rotate in 90-degree steps so pips stay aligned
  // with the cube edges. Also make them different per die to avoid uniformity.
  const settleAngles = shuffleInPlace([0, 90, 180, 270]);

  for (let i = 0; i < diceEls.length; i++) {
    const el = diceEls[i];
    if (!el) continue;

    // In-plane rotation when settled (top-down yaw). Use 90° increments.
    el.style.setProperty('--settle-rz', `${settleAngles[i % settleAngles.length]}deg`);

    // Animation pacing.
    el.style.setProperty('--move-dur', `${Math.round(rand(650, 920))}ms`);

    // Randomize the "walk" of the die around its base position.
    // Keep within modest ranges so it doesn't collide too much.
    el.style.setProperty('--mx1', `${Math.round(rand(-18, 18))}px`);
    el.style.setProperty('--my1', `${Math.round(rand(8, 30))}px`);
    el.style.setProperty('--mr1', `${Math.round(rand(-18, 18))}deg`);

    el.style.setProperty('--mx2', `${Math.round(rand(-22, 22))}px`);
    el.style.setProperty('--my2', `${Math.round(rand(22, 52))}px`);
    el.style.setProperty('--mr2', `${Math.round(rand(-22, 22))}deg`);

    el.style.setProperty('--mx3', `${Math.round(rand(-18, 18))}px`);
    el.style.setProperty('--my3', `${Math.round(rand(10, 34))}px`);
    el.style.setProperty('--mr3', `${Math.round(rand(-24, 24))}deg`);

    // A little squash/stretch to suggest depth without 3D tumbling.
    el.style.setProperty('--s1', `${rand(0.98, 1.06).toFixed(3)}`);
    el.style.setProperty('--s2', `${rand(0.96, 1.04).toFixed(3)}`);
    el.style.setProperty('--s3', `${rand(0.98, 1.06).toFixed(3)}`);
  }
}

function randomizeDiceMotion3d(diceEls) {
  if (!Array.isArray(diceEls)) return;

  // Settled (non-rolling) orientation: vary in-plane rotation.
  // Requested: 0 <= Z <= 90 degrees.

  for (let i = 0; i < diceEls.length; i++) {
    const el = diceEls[i];
    if (!el) continue;

    el.style.setProperty('--settle-rz', `${Math.round(rand(0, 90))}deg`);

    // Base tilt so 3D reads well (keep it modest to avoid a "warped tile" look).
    el.style.setProperty('--die-rx', `${Math.round(rand(10, 18))}deg`);
    el.style.setProperty('--die-ry', `${Math.round(rand(-22, -10))}deg`);

    // Translation jitter (re-uses the same variables as 2D, but slightly stronger).
    el.style.setProperty('--move-dur', `${Math.round(rand(720, 980))}ms`);
    el.style.setProperty('--mx1', `${Math.round(rand(-22, 22))}px`);
    el.style.setProperty('--my1', `${Math.round(rand(10, 34))}px`);
    el.style.setProperty('--mr1', `${Math.round(rand(-18, 18))}deg`);
    el.style.setProperty('--drx1', `${Math.round(rand(-10, 14))}deg`);
    el.style.setProperty('--dry1', `${Math.round(rand(-14, 14))}deg`);

    el.style.setProperty('--mx2', `${Math.round(rand(-26, 26))}px`);
    el.style.setProperty('--my2', `${Math.round(rand(26, 58))}px`);
    el.style.setProperty('--mr2', `${Math.round(rand(-22, 22))}deg`);
    el.style.setProperty('--drx2', `${Math.round(rand(-14, 10))}deg`);
    el.style.setProperty('--dry2', `${Math.round(rand(-18, 18))}deg`);

    el.style.setProperty('--mx3', `${Math.round(rand(-22, 22))}px`);
    el.style.setProperty('--my3', `${Math.round(rand(12, 40))}px`);
    el.style.setProperty('--mr3', `${Math.round(rand(-22, 22))}deg`);
    el.style.setProperty('--drx3', `${Math.round(rand(-10, 14))}deg`);
    el.style.setProperty('--dry3', `${Math.round(rand(-14, 14))}deg`);

    // Cube tumbling.
    el.style.setProperty('--tumble-dur', `${Math.round(rand(260, 420))}ms`);
    el.style.setProperty('--tumble-rx', `${Math.round(rand(360, 720))}deg`);
    el.style.setProperty('--tumble-ry', `${Math.round(rand(420, 980))}deg`);
    el.style.setProperty('--tumble-rz', `${Math.round(rand(180, 540))}deg`);

    // Randomize starting orientation so rolls don't look identical.
    el.style.setProperty('--cube-rx', `${Math.round(rand(-180, 180))}deg`);
    el.style.setProperty('--cube-ry', `${Math.round(rand(-180, 180))}deg`);
    el.style.setProperty('--cube-rz', `${[0, 90, 180, 270][randInt(0, 3)]}deg`);
  }
}

function orientCubeToResolvedFace(dieEl, value) {
  if (!dieEl) return;
  const v = Number(value);
  const face = Number.isInteger(v) && v >= 1 && v <= 6 ? v : 1;

  // Orient the cube so the resolved face is facing the viewer.
  // (This keeps the 3D math simple and deterministic.)
  let rx = 0;
  let ry = 0;
  if (face === 1) {
    rx = 0;
    ry = 0;
  } else if (face === 2) {
    rx = 0;
    ry = -90;
  } else if (face === 3) {
    // top face -> front
    rx = -90;
    ry = 0;
  } else if (face === 4) {
    // bottom face -> front
    rx = 90;
    ry = 0;
  } else if (face === 5) {
    rx = 0;
    ry = 90;
  } else if (face === 6) {
    rx = 0;
    ry = 180;
  }

  const rz = [0, 90, 180, 270][randInt(0, 3)];
  dieEl.style.setProperty('--cube-rx', `${rx}deg`);
  dieEl.style.setProperty('--cube-ry', `${ry}deg`);
  dieEl.style.setProperty('--cube-rz', `${rz}deg`);
}

function randomizeDicePositions(stageEl, diceEls) {
  if (!stageEl || !Array.isArray(diceEls) || diceEls.length === 0) return;
  const rect = stageEl.getBoundingClientRect();
  const w = rect.width;
  const h = rect.height;
  if (!Number.isFinite(w) || !Number.isFinite(h) || w <= 0 || h <= 0) return;

  const size = Math.max(48, Math.min(90, diceEls[0]?.getBoundingClientRect?.().width || 64));
  const pad = 12;

  const usableW = Math.max(0, w - pad * 2);
  const usableH = Math.max(0, h - pad * 2);
  if (usableW < size || usableH < size) return;

  // Keep a stable left→right ordering so the modal dice order matches
  // the game UI dice order (dice[0], dice[1], dice[2]).
  const baseFractions = [0.22, 0.52, 0.82];
  const minY = pad + 6;
  const maxY = Math.max(minY, pad + usableH - size - 6);

  const minXBound = pad;
  const maxXBound = Math.max(minXBound, pad + usableW - size);

  const targets = diceEls.map((_, i) => {
    const frac = baseFractions[i] ?? (0.22 + 0.3 * (i % 3));
    const centerX = pad + usableW * frac;
    const jitter = Math.min(usableW * 0.06, 18);
    const x = Math.max(minXBound, Math.min(maxXBound, centerX - size / 2 + rand(-jitter, jitter)));
    const y = Math.max(minY, Math.min(maxY, rand(minY, maxY)));
    return { x, y };
  });

  // Ensure they don't overlap too much while preserving order.
  for (let i = 1; i < targets.length; i++) {
    const prev = targets[i - 1];
    const cur = targets[i];
    const minGap = size * 0.75;
    if (cur.x - prev.x < minGap) {
      cur.x = Math.min(maxXBound, prev.x + minGap);
    }
  }

  for (let i = 0; i < diceEls.length; i++) {
    const el = diceEls[i];
    if (!el) continue;
    el.style.left = `${Math.round(targets[i].x)}px`;
    el.style.top = `${Math.round(targets[i].y)}px`;
  }
}

function showDiceModal({ title, dice, mask, playerId, rollSeq, maskDisabled, onClosed }) {
  const modal = $('dice-modal');
  const backdrop = $('dice-modal-backdrop');
  const stage = $('dice-stage');
  const titleEl = $('dice-modal-title');
  const d1 = $('die-1');
  const d2 = $('die-2');
  const d3 = $('die-3');
  if (!modal || !backdrop || !stage || !titleEl || !d1 || !d2 || !d3) return;

  const mode = getDiceModalMode();
  const explicitNoMask = Boolean(maskDisabled);
  let maskArr = Array.isArray(mask) ? mask : null;
  if (!explicitNoMask && playerId) {
    const hasSeq = rollSeq !== null && rollSeq !== undefined;
    const recomputed = hasSeq
      ? getHeberekeMaskForRoll(state.room, playerId, rollSeq)
      : getHeberekeMaskForDice(state.room, playerId, dice);
    if (Array.isArray(recomputed)) maskArr = recomputed;
    else if (!hasSeq) maskArr = getHeberekeMaskFallback(state.room, playerId, dice);
  }
  console.log('[hebereke] showDiceModal', { rollSeq, playerId, dice, mask, maskArr, maskDisabled });
  const is3d = mode === '3d';

  titleEl.textContent = title ?? t('dice.title', null, 'サイコロ');
  document.body.classList.add('modal-open');
  modal.classList.remove('hidden');
  stage.classList.remove('settling');
  stage.classList.toggle('dice-stage--3d', is3d);
  stage.classList.toggle('dice-stage--2d', !is3d);

  ensureAudioUnlockListeners();

  // Randomize base positions each time (avoid overlap by using lanes).
  randomizeDicePositions(stage, [d1, d2, d3]);
  if (is3d) randomizeDiceMotion3d([d1, d2, d3]);
  else randomizeDiceMotion2d([d1, d2, d3]);

  stage.classList.add('rolling');
  applyDieMaskClass(d1, Boolean(maskArr && maskArr[0]));
  applyDieMaskClass(d2, Boolean(maskArr && maskArr[1]));
  applyDieMaskClass(d3, Boolean(maskArr && maskArr[2]));
  if (maskArr) {
    console.log('[hebereke] modal mask apply', {
      mask: maskArr,
      die1: d1.className,
      die2: d2.className,
      die3: d3.className,
    });
  }

  // Continuous roll SFX while the dice are rolling.
  let stopRollSfx = null;
  try {
    stopRollSfx = startDiceRollingSfx();
  } catch {
    stopRollSfx = null;
  }

  // While rolling, randomize faces a bit.
  let raf = null;
  let closed = false;
  let settleTimer = null;
  let closeTimer = null;
  let settlingTimer = null;
  if (!is3d) {
    const spin = () => {
      if (modal.classList.contains('hidden')) return;
      setDieFace(d1, 1 + Math.floor(Math.random() * 6));
      setDieFace(d2, 1 + Math.floor(Math.random() * 6));
      setDieFace(d3, 1 + Math.floor(Math.random() * 6));
      raf = window.requestAnimationFrame(spin);
    };
    raf = window.requestAnimationFrame(spin);
  }

  const close = () => {
    if (closed) return;
    closed = true;
    // If user skips while rolling, snap to the real dice first.
    if (stage.classList.contains('rolling')) settle();
    try {
      stopRollSfx?.();
      stopRollSfx = null;
    } catch {
      // ignore
    }
    if (raf) window.cancelAnimationFrame(raf);
    if (settleTimer) window.clearTimeout(settleTimer);
    if (closeTimer) window.clearTimeout(closeTimer);
    if (settlingTimer) window.clearTimeout(settlingTimer);
    stage.classList.remove('rolling');
    stage.classList.remove('settling');
    modal.classList.add('hidden');
    document.body.classList.remove('modal-open');
    backdrop.removeEventListener('click', close);
    stage.removeEventListener('click', close);

    try {
      onClosed?.();
    } catch {
      // ignore
    }
  };

  backdrop.addEventListener('click', close);
  stage.addEventListener('click', close);

  const settle = () => {
    if (raf) window.cancelAnimationFrame(raf);
    stage.classList.remove('rolling');
    try {
      stopRollSfx?.();
      stopRollSfx = null;
    } catch {
      // ignore
    }
    const [a, b, c] = Array.isArray(dice) && dice.length === 3 ? dice : [1, 1, 1];
    setDieFace(d1, a);
    setDieFace(d2, b);
    setDieFace(d3, c);

    if (is3d) {
      orientCubeToResolvedFace(d1, a);
      orientCubeToResolvedFace(d2, b);
      orientCubeToResolvedFace(d3, c);
    }

    if (!explicitNoMask && playerId) {
      const hasSeq = rollSeq !== null && rollSeq !== undefined;
      const recomputed = hasSeq
        ? getHeberekeMaskForRoll(state.room, playerId, rollSeq)
        : getHeberekeMaskForDice(state.room, playerId, dice);
      if (Array.isArray(recomputed)) maskArr = recomputed;
      else if (!hasSeq) maskArr = getHeberekeMaskFallback(state.room, playerId, dice);
    }
    if (maskArr) {
      applyDieMaskClass(d1, Boolean(maskArr[0]));
      applyDieMaskClass(d2, Boolean(maskArr[1]));
      applyDieMaskClass(d3, Boolean(maskArr[2]));
    }
  };

  // Ensure the user sees the animation briefly.
  const waitMs = Math.min(DICE_ANIM.maxShowMs, Math.max(DICE_ANIM.minShowMs, 750));
  settleTimer = window.setTimeout(() => {
    settle();
    if (!state.debugHoldDiceModal) {
      closeTimer = window.setTimeout(() => close(), DICE_ANIM.postSettleCloseMs);
    }
  }, waitMs);
}

function ensureTurnTimerLoop() {
  if (state.turnTimerRaf) return;
  const tick = () => {
    renderTurnTimer(state.room);
    state.turnTimerRaf = window.requestAnimationFrame(tick);
  };
  state.turnTimerRaf = window.requestAnimationFrame(tick);
}

function renderMatch(room) {
  const g = room.game;
  if (!g) return;

  const freezeDiceUi = document.body.classList.contains('modal-open');
  const modal = $('round-result-modal');
  setRoundResultModalVisible(isBetMode(g.config?.ruleMode));

  ensureTurnTimerLoop();
  renderTurnTimer(room);

  const roundLabel = `${g.roundIndex + 1}/${g.config.roundsTotal}`;

  const setRow = $('row-set');
  const setLabel = $('label-set');
  let showSet = false;
  let setLabelText = '';
  if (g.config?.ruleMode === 'classic') {
    const playersCount = Array.isArray(room.players) ? room.players.length : 0;
    const roundsPerSet = Math.max(1, playersCount);
    const setIndex = Math.floor(g.roundIndex / roundsPerSet) + 1;
    const setsTotalRaw = Number(g.config?.setsTotal ?? room.classicSetsTotal ?? 3);
    const setsTotal = Number.isFinite(setsTotalRaw) && setsTotalRaw > 0 ? Math.floor(setsTotalRaw) : 3;
    setLabelText = `${setIndex}/${setsTotal}`;
    showSet = true;
  }
  const currentPlayer = room.players.find((p) => p.playerId === g.currentTurn.playerId);

  if (!room.roundAdvance) {
    state.cachedMatchStatus = {
      roundLabel,
      setLabel: setLabelText,
      showSet,
    };
  }

  const displayStatus = room.roundAdvance ? state.cachedMatchStatus : {
    roundLabel,
    setLabel: setLabelText,
    showSet,
  };

  $('label-round').textContent = displayStatus.roundLabel;
  if (setRow && setLabel) {
    if (displayStatus.showSet) {
      setLabel.textContent = displayStatus.setLabel;
      setRow.classList.remove('hidden');
    } else {
      setLabel.textContent = '';
      setRow.classList.add('hidden');
    }
  }

  const scoreTitle = $('score-title');
  if (scoreTitle) scoreTitle.textContent = scoreTitleForMode(g.config?.ruleMode);

  if (!freezeDiceUi) {
    const mask = getHeberekeMaskForDice(room, g.currentTurn.playerId, g.currentTurn.lastDice);
    renderDiceAndHand({ dice: g.currentTurn.lastDice, hand: g.currentTurn.lastHand, mask });
  }

  const myTurn = g.currentTurn.playerId === state.playerId;
  const betContext = getBetContext(room);
  const betsComplete = areBetsComplete(room, betContext);
  const waitingForBets =
    betContext &&
    !g.currentTurn.lastDice &&
    !betsComplete;

  const pendingAutoKeep =
    myTurn &&
    room?.autoKeep?.playerId === state.playerId &&
    Date.now() < Date.parse(room.autoKeep.dueAt);

  const hasRolled = Boolean(g.currentTurn.lastDice);
  const canReroll =
    hasRolled &&
    g.currentTurn.rerollsLeft > 0 &&
    g.currentTurn.lastHand?.kind !== '123';

  const rollBtn = $('btn-roll');
  if (rollBtn) {
    rollBtn.textContent = hasRolled
      ? t('button.reroll', { count: g.currentTurn.rerollsLeft ?? 0 }, `振り直す(${g.currentTurn.rerollsLeft ?? 0})`)
      : t('button.roll', null, '振る');
    rollBtn.disabled = !myTurn || (hasRolled && !canReroll) || Boolean(waitingForBets);
  }

  // Keep UI consistent: we use a single button for roll/reroll.
  const rerollBtn = $('btn-reroll');
  if (rerollBtn) {
    rerollBtn.disabled = true;
    rerollBtn.classList.add('hidden');
  }
  const hasNoHand = g.currentTurn.lastHand?.kind === 'none';
  const canStillReroll = g.currentTurn.rerollsLeft > 0;
  const heberekeMask = myTurn
    ? getHeberekeMaskForDice(room, g.currentTurn.playerId, g.currentTurn.lastDice)
    : null;
  const heberekeActive = Array.isArray(heberekeMask) && heberekeMask.some(Boolean);
  $('btn-keep').disabled =
    !myTurn ||
    !g.currentTurn.lastDice ||
    pendingAutoKeep ||
    (g.config?.ruleMode !== 'takeall' && hasNoHand && canStillReroll && !heberekeActive);

  const keepBtn = $('btn-keep');
  if (rollBtn) rollBtn.classList.remove('pulse-border');
  if (keepBtn) keepBtn.classList.remove('pulse-border');

  const waitingForFirstRoll = Boolean(myTurn && !hasRolled && !waitingForBets);
  const waitingForDecision = Boolean(
    myTurn &&
    hasRolled &&
    canReroll &&
    g.currentTurn.lastHand?.kind !== 'none'
  );
  const waitingForRerollOnly = Boolean(
    myTurn &&
    hasRolled &&
    canReroll &&
    g.currentTurn.lastHand?.kind === 'none'
  );
  if (waitingForFirstRoll) {
    if (rollBtn) rollBtn.classList.add('pulse-border');
  } else if (waitingForDecision) {
    if (rollBtn) rollBtn.classList.add('pulse-border');
    if (keepBtn) keepBtn.classList.add('pulse-border');
  } else if (waitingForRerollOnly) {
    if (rollBtn) rollBtn.classList.add('pulse-border');
  }

  if (room.roundAdvance) {
    if (rollBtn) rollBtn.classList.remove('pulse-border');
    if (keepBtn) keepBtn.classList.remove('pulse-border');
  }
  if (!isBetMode(g.config?.ruleMode)) {
    renderRoundAdvanceControls(room);
  }

  // Render match players list (right sidebar)
  renderMatchPlayers(room);
}

function renderMatchPlayers(room, { listId = 'list-match-players', showScoreLabel = true } = {}) {
  const listEl = $(listId);
  if (!listEl) return;

  const g = room.game;
  if (!g) {
    listEl.innerHTML = '';
    return;
  }

  const currentPlayerId = g.currentTurn?.playerId;
  const dealerId = g?.round?.dealerId ?? null;
  if (!room.roundAdvance) {
    state.cachedRoundContext = { currentPlayerId, dealerId };
  }
  const displayPlayerId = room.roundAdvance
    ? state.cachedRoundContext.currentPlayerId
    : currentPlayerId;
  const displayDealerId = room.roundAdvance
    ? state.cachedRoundContext.dealerId
    : dealerId;
  const isClassic = g.config?.ruleMode === 'classic';
  const isChipMode = g.config?.ruleMode === 'classic' || g.config?.ruleMode === 'takeall';
  const hasDealer = displayDealerId !== null && displayDealerId !== undefined;

  // Check if dice modal is showing (hide dice results while rolling)
  const diceModalVisible = document.body.classList.contains('modal-open');

  // Collect each player's last dice roll in this round from recentEvents
  let roundRolls = new Map(); // playerId -> { dice, hand }
  const confirmedPlayerIds = new Set();
  const useCachedRoundRolls =
    (diceModalVisible && state.cachedRoundRolls) ||
    (room.roundAdvance && state.cachedRoundRolls?.size > 0);

  let roundEvents = null;
  if (Array.isArray(room.recentEvents)) {
    // Find ROLL_RESOLVED events in the current round.
    // If roundAdvance is active, keep the *previous* round's rolls (before the next ROUND_STARTED).
    let lastRoundStartIndex = -1;
    let lastRoundEndIndex = -1;
    for (let i = room.recentEvents.length - 1; i >= 0; i--) {
      const type = room.recentEvents[i]?.type;
      if (lastRoundEndIndex < 0 && type === 'ROUND_ENDED') {
        lastRoundEndIndex = i;
      }
      if (type === 'ROUND_STARTED') {
        lastRoundStartIndex = i;
        if (lastRoundEndIndex < 0) break;
      }
    }

    roundEvents = room.recentEvents;
    if (room.roundAdvance && lastRoundEndIndex >= 0) {
      // previous round: use ROUND_STARTED immediately before the last ROUND_ENDED
      let prevRoundStartIndex = -1;
      for (let i = lastRoundEndIndex; i >= 0; i--) {
        if (room.recentEvents[i]?.type === 'ROUND_STARTED') {
          prevRoundStartIndex = i;
          break;
        }
      }
      if (prevRoundStartIndex >= 0) {
        roundEvents = room.recentEvents.slice(prevRoundStartIndex, lastRoundEndIndex + 1);
      } else {
        roundEvents = room.recentEvents.slice(0, lastRoundEndIndex + 1);
      }
    } else if (lastRoundStartIndex >= 0) {
      roundEvents = room.recentEvents.slice(lastRoundStartIndex);
    }

    for (const ev of roundEvents) {
      if (ev?.type === 'TURN_ENDED') {
        const pid = ev?.payload?.playerId;
        if (pid) confirmedPlayerIds.add(pid);
      }
    }
  }

  // TURN_ENDED is not broadcasted in recentEvents, so infer confirmation.
  if (room.roundAdvance) {
    for (const p of room.players) confirmedPlayerIds.add(p.playerId);
  } else if (currentPlayerId) {
    for (const p of room.players) {
      if (p.playerId !== currentPlayerId) confirmedPlayerIds.add(p.playerId);
    }
  }

  if (useCachedRoundRolls) {
    roundRolls = new Map(state.cachedRoundRolls);
  } else if (Array.isArray(roundEvents)) {
    for (const ev of roundEvents) {
      if (ev?.type === 'ROLL_RESOLVED') {
        const pid = ev?.payload?.playerId;
        const dice = ev?.payload?.dice;
        const hand = ev?.payload?.hand;
        if (pid && Array.isArray(dice)) {
          roundRolls.set(pid, { dice, hand, seq: ev?.seq ?? null });
        }
      }
    }
    if (!room.roundAdvance && !diceModalVisible) {
      if (roundRolls.size > 0) {
        state.cachedRoundRolls = new Map(roundRolls);
        state.cachedRoundRollsRoundIndex = g.roundIndex ?? null;
      } else {
        state.cachedRoundRolls = new Map();
        state.cachedRoundRollsRoundIndex = g.roundIndex ?? null;
      }
    }
  }

  if (roundRolls.size === 0 && state.cachedRoundRolls?.size > 0) {
    roundRolls = new Map(state.cachedRoundRolls);
  }

  // If modal is visible, keep previous rolls and avoid updating until it closes
  if (diceModalVisible) {
    roundRolls = new Map(state.cachedRoundRolls);
  } else {
    // When modal is hidden, include current turn's unconfirmed dice (lastDice)
    if (currentPlayerId && g.currentTurn?.lastDice && !roundRolls.has(currentPlayerId)) {
      const latest = findLatestRollResolvedEventForPlayer(room, currentPlayerId);
      const seq = latest && diceEqual(latest?.payload?.dice, g.currentTurn.lastDice) ? latest.seq : null;
      roundRolls.set(currentPlayerId, { dice: g.currentTurn.lastDice, hand: g.currentTurn.lastHand, seq });
    }
  }

  listEl.innerHTML = '';
  for (const p of room.players) {
    if (p.playerType === 'human' && !p.connected) continue;
    const li = document.createElement('li');
    li.className = 'match-player-item';

    const isTurn = p.playerId === displayPlayerId;
    const isDealer = hasDealer && p.playerId === displayDealerId;

    if (isTurn) li.classList.add('is-turn');
    if (isDealer) li.classList.add('is-dealer');

    const nameDiv = document.createElement('div');
    nameDiv.className = 'match-player-name';

    const waitStatus = getPlayerWaitStatus(room, p);
    const waitSpan = document.createElement('span');
    waitSpan.className = 'player-wait-indicator';
    if (!waitStatus.show) {
      waitSpan.classList.add('is-hidden');
    } else if (waitStatus.waiting) {
      waitSpan.classList.add('is-waiting');
    } else {
      waitSpan.textContent = '✓';
    }
    nameDiv.appendChild(waitSpan);

    const nameText = document.createElement('span');
    nameText.textContent = p.displayName;
    nameDiv.appendChild(nameText);

    // Dealer badge (right side of name)
    const badgesLeft = document.createElement('div');
    badgesLeft.className = 'match-player-badges-left';

    if (isDealer && isClassic) {
      const dealerBadge = document.createElement('span');
      dealerBadge.className = 'match-player-badge dealer';
      dealerBadge.textContent = t('badge.dealer', null, '親');
      badgesLeft.appendChild(dealerBadge);
    }

    if (isTurn) {
      const turnBadge = document.createElement('span');
      turnBadge.className = 'match-player-badge turn';
      turnBadge.textContent = t('badge.turn', null, '手番');
      badgesLeft.appendChild(turnBadge);
    }

    nameDiv.appendChild(badgesLeft);

    const scoreSpan = document.createElement('span');
    scoreSpan.className = 'match-player-score';
    const scoreLabel = isChipMode ? t('score.chip', null, 'コマ') : t('score.score', null, 'スコア');
    scoreSpan.textContent = showScoreLabel
      ? `${scoreLabel}: ${g.scores[p.playerId] ?? 0}`
      : String(g.scores[p.playerId] ?? 0);
    nameDiv.appendChild(scoreSpan);

    li.appendChild(nameDiv);

    // Show dice roll for this player in current round
    const rollData = roundRolls.get(p.playerId);
    const diceContainer = document.createElement('div');
    diceContainer.className = 'match-player-dice-container';

    // Visual dice
    const diceVisual = document.createElement('div');
    diceVisual.className = 'match-player-dice-visual';
    const rollMask = rollData?.seq && rollData?.hand?.kind !== '123' && !confirmedPlayerIds.has(p.playerId)
      ? getHeberekeMaskForRoll(room, p.playerId, rollData.seq)
      : null;
    if (rollData && rollData.dice) {
      for (let i = 0; i < rollData.dice.length; i++) {
        const face = rollData.dice[i];
        const dieEl = document.createElement('div');
        dieEl.className = 'die die--small';
        dieEl.setAttribute('data-face', String(face));
        if (Array.isArray(rollMask) && rollMask[i]) applyDieMaskClass(dieEl, true);
        // Add pips
        for (let pipIndex = 1; pipIndex <= 9; pipIndex++) {
          const pip = document.createElement('span');
          pip.className = `pip p${pipIndex}`;
          dieEl.appendChild(pip);
        }
        diceVisual.appendChild(dieEl);
      }
    } else {
      // Player hasn't rolled yet
      const dash = document.createElement('span');
      dash.className = 'match-player-no-roll';
      dash.textContent = '\u2212';
      diceVisual.appendChild(dash);
    }
    diceContainer.appendChild(diceVisual);

    // Text info
    const diceInfo = document.createElement('div');
    diceInfo.className = 'match-player-dice-info';
    if (rollData && rollData.dice) {
      const diceStr = maskDiceString(rollData.dice, rollMask);
      const rawLabel = rollData.hand?.label ?? '';
      const handLabel = Array.isArray(rollMask) && rollMask.some(Boolean) ? '???' : rawLabel;
      diceInfo.textContent = handLabel ? `${diceStr} (${handLabel})` : diceStr;
    } else {
      diceInfo.textContent = '\u2212';
    }
    diceContainer.appendChild(diceInfo);

    li.appendChild(diceContainer);

    if (room?.heberekeEnabled) {
      const heberekeLevel = getHeberekeLevel(room, p.playerId);
      const heberekeBadge = document.createElement('div');
      heberekeBadge.className = 'match-player-hebereke';
      heberekeBadge.innerHTML = `
        <svg class="match-player-hebereke-icon" viewBox="0 0 650 1280" preserveAspectRatio="xMidYMid meet" aria-hidden="true">
          <g transform="translate(0 1280) scale(0.1 -0.1)">
            <path d="M3185 12014 c-22 -2 -101 -8 -176 -14 -152 -12 -286 -37 -371 -69 -69 -27 -167 -92 -185 -123 -10 -18 -13 -164 -13 -708 -1 -806 -2 -711 8 -787 4 -36 15 -70 26 -82 18 -20 18 -21 -3 -57 -20 -34 -22 -48 -22 -297 0 -290 -38 -873 -65 -986 -17 -72 -61 -162 -101 -207 -50 -56 -96 -81 -223 -124 -147 -49 -309 -126 -435 -205 -218 -138 -445 -331 -545 -464 -98 -129 -188 -336 -237 -541 -16 -68 -18 -125 -16 -575 2 -275 9 -853 18 -1285 15 -772 49 -2786 63 -3721 l7 -476 35 -69 c29 -57 48 -78 105 -122 96 -73 253 -149 345 -167 65 -13 301 -15 1850 -13 l1775 3 130 44 c272 91 355 162 384 327 12 68 35 4458 29 5399 -4 500 -7 604 -22 685 -26 149 -55 247 -104 355 -132 294 -269 451 -567 650 -142 94 -236 140 -494 240 -81 31 -137 60 -161 81 -41 37 -92 127 -109 190 -17 62 -91 712 -89 775 1 30 -1 151 -4 271 -6 194 -9 220 -28 258 -19 36 -20 44 -7 58 7 10 19 52 25 94 9 61 9 85 -2 121 -8 27 -10 51 -5 58 5 8 6 41 3 74 -3 33 -9 312 -13 621 -10 616 -7 594 -72 648 -68 57 -174 92 -364 120 -106 15 -303 26 -370 20z"></path>
          </g>
        </svg>
        <span class="match-player-hebereke-level">${heberekeLevel}</span>
      `;
      li.appendChild(heberekeBadge);
    }

    listEl.appendChild(li);
  }
}

function renderResult(room) {
  const g = room.game;
  if (!g) return;
  const entries = Object.entries(g.scores);
  entries.sort((a, b) => b[1] - a[1]);

  const winnerId = entries[0]?.[0] ?? null;
  const winner = winnerId ? room.players.find((p) => p.playerId === winnerId) : null;
  const winnerName = winnerId
    ? (winner?.displayName ?? g.playerNames?.[winnerId]) ?? winnerId
    : null;

  const resultEl = $('result');
  if (resultEl) {
    const winnerText = winnerName
      ? t('result.winner', { name: winnerName }, `勝者: <b>${winnerName}</b>`)
      : t('result.draw', null, '引き分け');
    resultEl.innerHTML = winnerText;
  }

  renderMatchPlayers(room, { listId: 'list-result-players', showScoreLabel: true });
}

function playerLabel(room, playerId) {
  if (!room || !playerId) return 'SYSTEM';
  const p = room.players.find((x) => x.playerId === playerId);
  if (!p) return 'SYSTEM';
  if (p.playerType === 'bot') return p.displayName || 'CPU';
  return p.displayName || 'GUEST';
}

function formatEventDetail(room, ev) {
  if (!ev) return 'EVENT';

  if (ev?.type === 'ROLL_RESOLVED') {
    const dice = ev?.payload?.dice;
    const hand = ev?.payload?.hand;
    const pid = ev?.payload?.playerId ?? null;
    const mask = getHeberekeMaskForRoll(room, pid, ev?.seq ?? null);
    const diceStr = Array.isArray(dice) ? maskDiceString(dice, mask) : '';
    const handStr = hand?.label ? t('log.handDetail', { label: hand.label }, ` / 役: ${hand.label}`) : '';
    return t('log.roll', { dice: diceStr, hand: handStr }, `出目: ${diceStr}${handStr}`);
  }

  if (ev?.type === 'ROUND_STARTED') {
    const roundIndexRaw = ev?.payload?.roundIndex;
    const roundIndex = Number.isInteger(roundIndexRaw) ? roundIndexRaw : null;
    const roundLabel = roundIndex !== null ? `（${roundIndex + 1}）` : '';

    if (room?.game?.config?.ruleMode !== 'classic') {
      return t('log.roundStart', { round: roundLabel }, `ラウンド開始${roundLabel}`);
    }

    const dealerId = ev?.payload?.dealerId ?? null;
    const dealerName = playerLabel(room, dealerId);
    return t(
      'log.roundStartDealer',
      { round: roundLabel, dealer: dealerName },
      `ラウンド開始${roundLabel}（親: ${dealerName}）`
    );
  }

  if (ev?.type === 'ROUND_RESULT') {
    const dealerId = ev?.payload?.dealerId ?? null;
    const winnerIds = Array.isArray(ev?.payload?.winnerIds) ? ev.payload.winnerIds : [];
    if (winnerIds.length <= 0) return t('log.draw', null, '引き分け');

    const names = winnerIds.map((pid) => {
      const n = playerLabel(room, pid);
      return pid && dealerId && pid === dealerId ? `${n}(${t('badge.dealer', null, '親')})` : n;
    });
    return t('log.win', { names: names.join(', ') }, `${names.join(', ')} の勝ち`);
  }

  if (ev?.type === 'BET_PLACED') {
    const amount = Number(ev?.payload?.amount ?? 0);
    return t('log.bet', { amount }, `${amount}コマ ベット`);
  }

  if (ev?.type === 'BET_TRANSFER') {
    const fromId = ev?.payload?.fromPlayerId ?? null;
    const toId = ev?.payload?.toPlayerId ?? null;
    const amount = Number(ev?.payload?.amount ?? 0);
    const fromName = fromId ? playerLabel(room, fromId) : t('match.pot', null, '場');
    const toName = toId ? playerLabel(room, toId) : t('log.unknown', null, '不明');
    return t(
      'log.transfer.from',
      { from: fromName, to: toName, amount },
      `${fromName} → ${toName} : ${amount}コマ`
    );
  }

  if (ev?.type === 'GAME_STARTED') {
    return t('log.gameStart', null, 'ゲーム開始');
  }

  if (ev?.type === 'GAME_ENDED') {
    return t('log.gameEnd', null, 'ゲーム終了');
  }

  return String(ev.type ?? 'EVENT');
}

function formatEventLine(room, ev) {
  const time = new Date(ev?.at ?? Date.now()).toLocaleTimeString();

  if (ev?.type === 'ROUND_STARTED' || ev?.type === 'ROUND_RESULT') {
    return `[${time}] [SYSTEM] ${formatEventDetail(room, ev)}`;
  }

  const pid = ev?.payload?.playerId ?? ev?.payload?.actorPlayerId ?? ev?.playerId ?? null;
  const who = playerLabel(room, pid);
  return `[${time}] [${who}] ${formatEventDetail(room, ev)}`;
}

function renderEventLogFromRoom(room) {
  const log = $('event-log');
  if (!log) return;

  const pad2 = (n) => String(n).padStart(2, '0');
  const formatTime = (iso) => {
    const d = new Date(iso ?? Date.now());
    return `${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
  };

  const showTypes = new Set([
    'GAME_STARTED',
    'ROUND_STARTED',
    'ROUND_RESULT',
    'ROLL_RESOLVED',
    'BET_PLACED',
    'BET_TRANSFER',
    'GAME_ENDED',
  ]);
  if (room?.game?.config?.ruleMode === 'classic') {
    showTypes.delete('ROUND_RESULT');
  }
  if (room?.roundAdvance || state.deferRoundStartedLogs) {
    showTypes.delete('ROUND_STARTED');
  }
  const events = Array.isArray(room?.recentEvents)
    ? room.recentEvents.filter((ev) => showTypes.has(ev?.type))
    : [];

  // Get system chat messages (playerId is null) to display in log
  const systemMessages = Array.isArray(room?.chat)
    ? room.chat.filter((msg) => !msg.playerId)
    : [];

  // Combine events and system messages, sorted by timestamp
  const allItems = [
    ...events.map((ev) => ({ type: 'event', data: ev, timestamp: new Date(ev?.at ?? Date.now()).getTime() })),
    ...systemMessages.map((msg) => ({ type: 'message', data: msg, timestamp: new Date(msg?.createdAt ?? Date.now()).getTime() })),
  ].sort((a, b) => a.timestamp - b.timestamp);

  log.innerHTML = '';
  for (const entry of allItems) {
    if (entry.type === 'event') {
      const ev = entry.data;
      const item = document.createElement('div');
      item.className = 'chat-item';

      const left = document.createElement('div');
      left.className = 'chat-left';

      const text = document.createElement('div');
      text.className = 'chat-text';
      text.textContent = formatEventDetail(room, ev);

      // Check if event is system-level (ROUND_STARTED, ROUND_RESULT, etc) or player action
      const isSystemEvent = ev?.type === 'ROUND_STARTED' || ev?.type === 'ROUND_RESULT' || ev?.type === 'GAME_STARTED' || ev?.type === 'GAME_ENDED';

      if (isSystemEvent) {
        item.classList.add('system');
      } else {
        const pid = ev?.payload?.playerId ?? ev?.payload?.actorPlayerId ?? ev?.playerId ?? null;
        if (pid) {
          const who = document.createElement('div');
          who.className = 'chat-who';
          who.textContent = playerLabel(room, pid);
          left.appendChild(who);
        } else {
          item.classList.add('system');
        }
      }
      left.appendChild(text);

      const right = document.createElement('div');
      right.className = 'chat-right';

      const time = document.createElement('small');
      time.className = 'chat-time';
      time.textContent = formatTime(ev?.at ?? ev?.createdAt);
      right.appendChild(time);

      item.appendChild(left);
      item.appendChild(right);
      log.appendChild(item);
    } else {
      // System message from chat
      const msg = entry.data;
      const item = document.createElement('div');
      item.className = 'chat-item system';

      const left = document.createElement('div');
      left.className = 'chat-left';

      const text = document.createElement('div');
      text.className = 'chat-text';
      text.textContent = String(msg.text ?? '');
      left.appendChild(text);

      const right = document.createElement('div');
      right.className = 'chat-right';

      const time = document.createElement('small');
      time.className = 'chat-time';
      time.textContent = formatTime(msg.createdAt);
      right.appendChild(time);

      item.appendChild(left);
      item.appendChild(right);
      log.appendChild(item);
    }
  }
  log.scrollTop = log.scrollHeight;
}

function renderRoomsList(rooms) {
  const container = $('rooms-list-container');
  const list = $('rooms-list');
  
  container.classList.remove('hidden');
  list.innerHTML = '';
  
  if (!rooms || rooms.length === 0) {
    const emptyMsg = document.createElement('li');
    emptyMsg.className = 'rooms-list-empty';
    emptyMsg.textContent = t('rooms.empty', null, '現在ルームはありません');
    list.appendChild(emptyMsg);
    return;
  }
  
  rooms.forEach(room => {
    const li = document.createElement('li');
    
    const info = document.createElement('div');
    info.className = 'room-info';
    
    const code = document.createElement('span');
    code.className = 'room-code';
    code.textContent = room.inviteCode;
    
    const name = document.createElement('span');
    name.className = 'room-name';
    name.textContent = room.roomName || t('room.defaultName', null, 'ルーム');
    
    const details = document.createElement('div');
    details.className = 'room-details';
    
    const host = document.createElement('span');
    host.textContent = t('room.hostLabel', { name: room.hostName }, `ホスト: ${room.hostName}`);
    
    const players = document.createElement('span');
    const maxPlayers = room.maxPlayers || 4;
    players.textContent = t(
      'room.playersLabel',
      { count: room.playerCount, max: maxPlayers },
      `${room.playerCount}/${maxPlayers}人`
    );
    
    const mode = document.createElement('span');
    mode.textContent =
      room.ruleMode === 'classic' ? t('lobby.mode.classic', null, 'クラシック') :
      room.ruleMode === 'takeall' ? t('lobby.mode.takeall', null, '総取り') :
      t('lobby.mode.score', null, 'スコア制');
    
    details.appendChild(host);
    details.appendChild(players);
    details.appendChild(mode);
    
    info.appendChild(code);
    info.appendChild(name);
    info.appendChild(details);
    
    const joinBtn = document.createElement('button');
    joinBtn.className = 'room-join-btn';
    joinBtn.textContent = t('rooms.join', null, '参加');
    joinBtn.addEventListener('click', () => {
      const name = displayName();
      if (!name) return toast(t('toast.nameRequired', null, '名前を入力してください'));
      $('input-code').value = room.inviteCode;
      socket.emit('room:join', { inviteCode: room.inviteCode, displayName: name });
    });
    
    li.appendChild(info);
    li.appendChild(joinBtn);
    list.appendChild(li);
  });
}

function requestRoomsList() {
  socket.emit('rooms:list');
}

$('btn-create').addEventListener('click', () => {
  const name = displayName();
  if (!name) return toast(t('toast.nameRequired', null, '名前を入力してください'));
  socket.emit('room:create', {
    displayName: name,
    mode: 'pvp',
  });
});

$('btn-join').addEventListener('click', () => {
  const name = displayName();
  const code = String($('input-code').value ?? '').trim().toUpperCase();
  if (!name) return toast(t('toast.nameRequired', null, '名前を入力してください'));
  if (!code) return toast(t('toast.codeRequired', null, '招待コードを入力してください'));
  socket.emit('room:join', { inviteCode: code, displayName: name });
});

$('btn-ready')?.addEventListener('click', () => {
  const room = state.room;
  if (!room) return;
  const me = room.players.find((p) => p.playerId === state.playerId);
  const next = !me?.ready;
  socket.emit('room:ready', { ready: next });
});

$('input-room-name-lobby')?.addEventListener('change', (e) => {
  const v = String(e.target?.value ?? '').trim();
  if (v) socket.emit('room:set_name', { roomName: v });
});

$('input-max-players-lobby')?.addEventListener('change', (e) => {
  const n = Number(e.target?.value ?? 4);
  const room = state.room;
  if (room?.players) {
    const activeCount = room.players.filter((p) => (p.playerType === 'bot' ? true : p.connected)).length;
    if (Number.isFinite(n) && activeCount > n) {
      toast(
        t(
          'toast.maxPlayers',
          { count: activeCount, max: n },
          `現在${activeCount}人が参加しているため、${n}人以下に減らせません`
        )
      );
      e.target.value = String(room.maxPlayers ?? 4);
      return;
    }
  }
  socket.emit('room:set_max_players', { maxPlayers: n });
});

$('checkbox-is-public-lobby')?.addEventListener('change', (e) => {
  const isPublic = Boolean(e.target?.checked);
  socket.emit('room:set_is_public', { isPublic });
});

$('checkbox-hebereke-lobby')?.addEventListener('change', (e) => {
  const enabled = Boolean(e.target?.checked);
  socket.emit('room:set_hebereke', { enabled });
});

$('select-rule-mode-lobby')?.addEventListener('change', (e) => {
  const v = String(e.target?.value ?? '').trim().toLowerCase();
  const setsField = $('field-sets-total-lobby');
  if (setsField) {
    if (v === 'classic') setsField.classList.remove('hidden');
    else setsField.classList.add('hidden');
  }
  const ruleMode = v === 'classic' || v === 'score' || v === 'takeall' ? v : 'classic';
  socket.emit('room:set_rule_mode', { ruleMode });
});

$('input-sets-total-lobby')?.addEventListener('change', (e) => {
  const n = Number(e.target?.value ?? 3);
  socket.emit('room:set_classic_sets_total', { setsTotal: n });
});

$('btn-start').addEventListener('click', () => socket.emit('game:start'));
$('btn-add-bot')?.addEventListener('click', () => {
  socket.emit('room:add_bot', { botDifficulty: 'normal' });
});
$('btn-roll').addEventListener('click', () => {
  const g = state.room?.game;
  const hasRolled = Boolean(g?.currentTurn?.lastDice);
  const debugDice = state.debugDicePending;
  if (hasRolled) socket.emit('turn:reroll', debugDice ? { debugDice } : undefined);
  else socket.emit('turn:roll', debugDice ? { debugDice } : undefined);
});
$('btn-reroll').addEventListener('click', () => {
  const debugDice = state.debugDicePending;
  socket.emit('turn:reroll', debugDice ? { debugDice } : undefined);
});
$('btn-keep').addEventListener('click', () => {
  const room = state.room;
  const g = room?.game;
  let heberekeForceKeep = false;
  if (room && g && g.currentTurn?.playerId === state.playerId) {
    const mask = getHeberekeMaskForDice(room, g.currentTurn.playerId, g.currentTurn.lastDice);
    heberekeForceKeep = Array.isArray(mask) && mask.some(Boolean);
  }
  socket.emit('turn:keep', heberekeForceKeep ? { heberekeForceKeep: true } : undefined);
});

$('btn-bet-minus')?.addEventListener('click', () => {
  if (!state.room) return;
  state.betDraft = clampBetAmount((state.betDraft ?? 0) - 10);
  renderRoundResultModal(state.room);
});

$('btn-bet-plus')?.addEventListener('click', () => {
  if (!state.room) return;
  state.betDraft = clampBetAmount((state.betDraft ?? 0) + 10);
  renderRoundResultModal(state.room);
});

$('btn-bet-confirm')?.addEventListener('click', () => {
  if (!state.room) return;
  const g = state.room?.game;
  if (!g || (g?.config?.ruleMode !== 'classic' && g?.config?.ruleMode !== 'takeall')) return;
  const betContext = getBetContext(state.room);
  if (!betContext) return;
  const bets = betContext.bets ?? {};
  const myBet = Number(bets[state.playerId] ?? 0);
  const hasMyBet = Object.prototype.hasOwnProperty.call(bets, state.playerId);
  const amount = clampBetAmount(state.betDraft ?? 0);
  if (amount === myBet && hasMyBet) return;
  socket.emit('round:bet', { amount });
});

$('btn-copy-code')?.addEventListener('click', async () => {
  const code = $('label-code').textContent;
  try {
    await navigator.clipboard.writeText(code);
    toast(t('toast.copySuccess', null, 'コピーしました'));
  } catch {
    toast(t('toast.copyFail', null, 'コピーに失敗しました'));
  }
});

$('btn-leave').addEventListener('click', () => {
  clearReconnectStorage();
  location.reload();
});
$('btn-back').addEventListener('click', () => {
  const room = state.room;
  if (room && room.mode === 'pvp' && room.game?.status === 'finished') {
    state.pvpShowResult = false;
    showScreen('lobby');
    renderRoom(room);
    return;
  }
  clearReconnectStorage();
  location.reload();
});

$('tab-chat')?.addEventListener('click', () => setUnifiedPanelTab('chat'));
$('tab-log')?.addEventListener('click', () => setUnifiedPanelTab('log'));

function sendChatIfAny() {
  const input = $('chat-input');
  const v = String(input.value ?? '').trim();
  if (!v) return;
  input.value = '';
  input.focus();
  socket.emit('chat:send', { text: v });
}

$('chat-send').addEventListener('click', () => sendChatIfAny());

$('chat-input').addEventListener('keydown', (e) => {
  if (e.key !== 'Enter') return;
  if (e.isComposing) return;
  e.preventDefault();
  sendChatIfAny();
});

// Help tooltip logic
function initHelpTooltips() {
  const buttons = document.querySelectorAll('.help-toggle');
  for (const btn of buttons) {
    const id = btn.getAttribute('aria-controls');
    const bubble = id ? document.getElementById(id) : null;
    btn.addEventListener('click', (ev) => {
      ev.stopPropagation();
      const isOpen = btn.getAttribute('aria-expanded') === 'true';
      // close any other open bubbles
      document.querySelectorAll('.help-bubble').forEach((b) => {
        if (b !== bubble) b.classList.add('hidden');
      });
      document.querySelectorAll('.help-toggle').forEach((t) => t.setAttribute('aria-expanded', 'false'));

      if (!bubble) return;
      if (isOpen) {
        bubble.classList.add('hidden');
        btn.setAttribute('aria-expanded', 'false');
        bubble.setAttribute('aria-hidden', 'true');
      } else {
        // show bubble (absolute positioned) then compute placement
        bubble.classList.remove('hidden');
        btn.setAttribute('aria-expanded', 'true');
        bubble.setAttribute('aria-hidden', 'false');

        // compute positioning so bubble overlays existing elements and arrow points to icon
        const parent = btn.closest('label') || document.body;
        const parentRect = parent.getBoundingClientRect();
        // ensure bubble layout is measurable
        const bubbleRect = bubble.getBoundingClientRect();
        const btnRect = btn.getBoundingClientRect();

        // ideal left for bubble: center bubble near the button
        const idealLeft = btnRect.left + btnRect.width / 2 - bubbleRect.width / 2 - parentRect.left;
        const minLeft = 8;
        const maxLeft = Math.max(minLeft, parentRect.width - bubbleRect.width - 8);
        const left = Math.min(maxLeft, Math.max(minLeft, idealLeft));

        bubble.style.left = `${left}px`;
        bubble.style.top = `${btnRect.bottom - parentRect.top + 8}px`;

        const arrowLeft = btnRect.left + btnRect.width / 2 - (parentRect.left + left);
        bubble.style.setProperty('--arrow-left', `${Math.max(8, Math.min(bubbleRect.width - 8, arrowLeft))}px`);
      }
    });
  }

  // clicking outside closes bubbles
  document.addEventListener('click', (ev) => {
    const target = ev.target;
    if (target.closest && target.closest('.help-bubble')) return;
    if (target.closest && target.closest('.help-toggle')) return;
    document.querySelectorAll('.help-bubble').forEach((b) => b.classList.add('hidden'));
    document.querySelectorAll('.help-toggle').forEach((t) => t.setAttribute('aria-expanded', 'false'));
    document.querySelectorAll('.help-bubble').forEach((b) => b.setAttribute('aria-hidden', 'true'));
  });
}

initHelpTooltips();

$('input-name').addEventListener('input', (e) => {
  const v = String(e.target?.value ?? '').trim();
  if (v) localStorage.setItem(STORAGE_KEYS.guestName, v);
});

socket.on('room:created', ({ roomId, playerId, reconnectToken }) => {
  state.playerId = playerId;
  state.reconnectToken = reconnectToken;
  if (roomId) localStorage.setItem(STORAGE_KEYS.roomId, roomId);
  if (reconnectToken) localStorage.setItem(STORAGE_KEYS.reconnectToken, reconnectToken);
  if (state.room) renderRoom(state.room);
});

socket.on('room:joined', ({ roomId, playerId, reconnectToken }) => {
  state.playerId = playerId;
  state.reconnectToken = reconnectToken;
  if (roomId) localStorage.setItem(STORAGE_KEYS.roomId, roomId);
  if (reconnectToken) localStorage.setItem(STORAGE_KEYS.reconnectToken, reconnectToken);
  if (state.room) renderRoom(state.room);
});

socket.on('room:reconnected', ({ roomId, playerId, reconnectToken }) => {
  if (playerId) state.playerId = playerId;
  if (reconnectToken) state.reconnectToken = reconnectToken;
  if (roomId) localStorage.setItem(STORAGE_KEYS.roomId, roomId);
  if (reconnectToken) localStorage.setItem(STORAGE_KEYS.reconnectToken, reconnectToken);
});

socket.on('room:state', ({ room }) => {
  /* console.log('[round-result] room:state', {
    status: room?.status,
    hasRoundAdvance: Boolean(room?.roundAdvance),
    roundAdvance: room?.roundAdvance ?? null,
    recentEventsLen: room?.recentEvents?.length ?? 0,
  }); */
  if (room?.roomId) localStorage.setItem(STORAGE_KEYS.roomId, room.roomId);
  // Show dice animation before rendering, to avoid a 1-frame spoiler flash.
  maybeShowDiceModalFromState(room);
  renderRoom(room);
});

socket.on('round:result', ({ roundIndex, winnerIds } = {}) => {
  // console.log('[round-result] round:result event', { roundIndex, winnerIds });
  if (!state.room) {
    // console.log('[round-result] no state.room yet, buffering');
    state.pendingRoundResult = { roundIndex, winnerIds };
    return;
  }
  state.room.roundAdvance = {
    roundIndex: Number(roundIndex ?? 0),
    winnerIds: Array.isArray(winnerIds) ? winnerIds : [],
    ackedPlayerIds: state.room.roundAdvance?.ackedPlayerIds ?? [],
  };
  state.roundAdvanceHold = state.room.roundAdvance;
  state.roundAdvanceHoldAcked = false;
  renderRoundResultModal(state.room);
});

socket.on('game:event', (ev) => {
  const log = $('event-log');
  if (!log) return;
  if (ev?.type === 'ROLL_RESOLVED') {
    const pid = ev?.payload?.playerId ?? null;
    const dice = ev?.payload?.dice ?? null;
    const hand = ev?.payload?.hand ?? null;
    const roundIndex = ev?.payload?.roundIndex ?? null;
    if (pid && pid === state.playerId) {
      state.debugDicePending = null;
    }
    if (pid && Array.isArray(dice)) {
      state.cachedRoundRolls.set(pid, { dice, hand, seq: ev?.seq ?? null });
      if (Number.isInteger(roundIndex)) state.cachedRoundRollsRoundIndex = roundIndex;
    }
  }
  if (ev?.type === 'ROUND_RESULT' || ev?.type === 'ROUND_ENDED') {
    // console.log('[round-result] game:event', { type: ev?.type, payload: ev?.payload });
  }
  if (ev?.type === 'ROUND_RESULT' || ev?.type === 'ROUND_ENDED') {
    const roundIndex = ev?.payload?.roundIndex ?? 0;
    const winnerIds = ev?.payload?.winnerIds ?? [];
    state.deferRoundStartedLogs = true;
    if (!state.room) {
      state.pendingRoundResult = { roundIndex, winnerIds };
    } else {
      state.room.roundAdvance = {
        roundIndex: Number(roundIndex ?? 0),
        winnerIds: Array.isArray(winnerIds) ? winnerIds : [],
        ackedPlayerIds: state.room.roundAdvance?.ackedPlayerIds ?? [],
      };
      state.roundAdvanceHold = state.room.roundAdvance;
      state.roundAdvanceHoldAcked = false;
      renderRoundResultModal(state.room);
    }
  }
  if (ev?.type === 'TURN_STARTED' || ev?.type === 'TURN_ENDED' || ev?.type === 'ROUND_ENDED') return;
  if (ev?.type === 'ROUND_STARTED' && state.deferRoundStartedLogs) {
    state.pendingRoundStartEvents.push(ev);
    return;
  }
  if (ev?.type === 'GAME_ENDED' && state.room?.mode === 'pvp') {
    const scores = state.room?.game?.scores;
    const isParticipant = Boolean(state.playerId) && scores && Object.prototype.hasOwnProperty.call(scores, state.playerId);
    if (isParticipant && state.pvpShowResult !== false) state.pvpShowResult = true;
  }
  const line = formatEventLine(state.room, ev);
  log.textContent += (log.textContent ? '\n' : '') + line;
  log.scrollTop = log.scrollHeight;
});

socket.on('chat:message', (msg) => {
  if (state.room && state.room.mode === 'pvp') {
    state.room.chat = state.room.chat ?? [];
    state.room.chat.push(msg);
    if (state.room.chat.length > 200) state.room.chat.splice(0, state.room.chat.length - 200);
  }
  renderChat(state.room);
});

socket.on('error:message', ({ message }) => {
  const msg = String(message ?? '');
  if (msg.includes('再接続') || msg.includes('ルームが見つかりません')) {
    clearReconnectStorage();
  }
  if (msg.includes('最大人数') || msg.includes('減らせません') || msg.includes('参加しているため')) {
    const maxPlayersInput = $('input-max-players-lobby');
    if (maxPlayersInput && state.room) {
      maxPlayersInput.value = String(state.room.maxPlayers ?? 4);
    }
  }
  toast(msg);
});

socket.on('rooms:list', ({ rooms }) => {
  renderRoomsList(rooms);
});

const initialLang = detectLanguage();
I18N.current = initialLang;
initLanguageSwitcher();
applyI18n(initialLang);

restoreGuestName();
showScreen('top');
$('chat-card').classList.add('hidden');
$('chat-actions').classList.add('hidden');
requestRoomsList();

// トップ画面で定期的にルーム一覧を更新
setInterval(() => {
  if (document.getElementById('screen-top').classList.contains('hidden') === false) {
    requestRoomsList();
  }
}, 5000);

socket.on('connect', () => {
  const roomId = String(localStorage.getItem(STORAGE_KEYS.roomId) ?? '').trim();
  const reconnectToken = String(localStorage.getItem(STORAGE_KEYS.reconnectToken) ?? '').trim();
  if (roomId && reconnectToken) {
    socket.emit('reconnect', { roomId, reconnectToken });
  }
});
